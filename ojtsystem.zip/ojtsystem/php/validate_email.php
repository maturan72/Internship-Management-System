<?php

include 'db_con.php';

$email = $_GET['email'];

$admin = mysqli_query($conn,"SELECT * FROM admin WHERE email = '$email'");
$company = mysqli_query($conn,"SELECT * FROM company WHERE email = '$email'");
$instructor = mysqli_query($conn,"SELECT * FROM instructor WHERE email = '$email'");
$interns = mysqli_query($conn,"SELECT * FROM interns WHERE email = '$email'");

// do check
if ( mysqli_num_rows($admin) > 0 ) {
    $response = true;
}
elseif(mysqli_num_rows($company) > 0){
    $response = true;
}
elseif(mysqli_num_rows($instructor) > 0){
    $response = true;
}
elseif(mysqli_num_rows($interns) > 0){
    $response = true;
}
else {
    $response = false;
}
echo json_encode($response);

?>