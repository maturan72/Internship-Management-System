<?php

    session_start();
    include 'db_con.php';

    if(isset($_POST['submit_message'])){
        $fn = $_POST['fullname'];
        $email = $_POST['email'];
        $contact = $_POST['contact'];
        $message = $_POST['message'];
        $date = date('m-d-y');

        $send = "INSERT INTO messages VALUE(NULL, '$fn', '$email', '$contact','$message', '$date')";

        if(mysqli_query($conn, $send)){
            header('location: ../index.php');
        }

    }

?>