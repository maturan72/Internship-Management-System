<?php
    include 'db_con.php';

    $archive_id = $_GET['id'];
    $type = $_GET['type'];

    if($type == "company"){
        $select_data = mysqli_query($conn, "SELECT * FROM company WHERE id = '$archive_id' ");
        $rows = mysqli_fetch_array($select_data);
        $id = $rows['id'];
        $fn = $rows['firstname'];
        $mn = $rows['middlename'];
        $ln = $rows['lastname'];
        $email = $rows['email'];
        $pass = $rows['password'];
        $companyname = $rows['companyname'];
        $address = $rows['address'];
        $contact = $rows['contact'];

        $data = new stdClass();
        $data->type = $type;
        $data->id = $id;
        $data->firstname = $fn;
        $data->middlename = $mn;
        $data->lastname = $ln;
        $data->company = $companyname;
        $data->address = $address;
        $data->email = $email;
        $data->password = $pass;
        $data->contact = $contact;

        $mydata = json_encode($data);

        $insert = mysqli_query($conn, "INSERT INTO archive VALUES (NULL,'$mydata')");

        if($insert){
            $delete_data = "DELETE FROM `company` WHERE `company`.`id` = '$archive_id' ";
            if(mysqli_query($conn, $delete_data)){
                header('location: ../pages/admin.php?inc=company');
            }
        }
    }elseif($type == "instructor"){
        $select_data = mysqli_query($conn, "SELECT * FROM instructor WHERE id = '$archive_id' ");
        $rows = mysqli_fetch_array($select_data);
        $id = $rows['id'];
        $fn = $rows['firstname'];
        $mn = $rows['middlename'];
        $ln = $rows['lastname'];
        $email = $rows['email'];
        $pass = $rows['password'];
        $address = $rows['address'];
        $contact = $rows['contact'];

        $data = new stdClass();
        $data->type = $type;
        $data->id = $id;
        $data->firstname = $fn;
        $data->middlename = $mn;
        $data->lastname = $ln;
        $data->address = $address;
        $data->email = $email;
        $data->password = $pass;
        $data->contact = $contact;

        $mydata = json_encode($data);

        $insert = mysqli_query($conn, "INSERT INTO archive VALUES (NULL,'$mydata')");

        if($insert){
            $delete_data = "DELETE FROM `instructor` WHERE `instructor`.`id` = '$archive_id' ";
            if(mysqli_query($conn, $delete_data)){
                header('location: ../pages/admin.php?inc=head');
            }
        }
    }elseif($type == "interns"){
        $select_data = mysqli_query($conn, "SELECT * FROM interns WHERE id = '$archive_id' ");
        $rows = mysqli_fetch_array($select_data);
        $id = $rows['id'];
        $studentid = $rows['student_id'];
        $fn = $rows['firstname'];
        $mn = $rows['middlename'];
        $ln = $rows['lastname'];
        $age = $rows['age'];
        $gender = $rows['gender'];
        $contact = $rows['contact'];
        $address = $rows['address'];
        $course = $rows['course'];
        $section = $rows['section'];
        $skills = $rows['skills'];
        $hours = $rows['hours'];
        $company = $rows['company'];
        $job = $rows['job_id'];
        $instructor = $rows['instructor'];
        $email = $rows['email'];
		$password = $rows['password'];

        $data = new stdClass();
        $data->type = $type;
        $data->id = $id;
        $data->student_id = $studentid;
        $data->firstname = $fn;
        $data->middlename = $mn;
        $data->lastname = $ln;
        $data->age = $age;
        $data->gender = $gender;
        $data->contact = $contact;
        $data->address = $address;
        $data->course = $course;
        $data->section = $section;
        $data->skills = $skills;
        $data->hours = $hours;
        $data->company = $company;
        $data->job = $job;
        $data->instructor = $instructor;
        $data->email = $email;
        $data->password = $password;

        $mydata = json_encode($data);

        $insert = mysqli_query($conn, "INSERT INTO archive VALUES (NULL,'$mydata')");
        if($insert){
            $delete_data = "DELETE FROM `interns` WHERE `interns`.`id` = '$archive_id' ";
            if(mysqli_query($conn, $delete_data)){
                header('location: ../pages/admin.php?inc=interns');
            }
        }
    }else{
        header('location: javascript://history.go(-1)');
    }
    
?>