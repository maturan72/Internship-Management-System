<?php

    session_start();
    include 'db_con.php';

    if(isset($_GET['del'])){
        $id = $_GET['del'];
        $delete = "DELETE FROM pending_registration WHERE id = '$id'";
        if(mysqli_query($conn, $delete)){
            $_SESSION['del_request'] = "Deleted!";
            header('location: ../pages/admin.php');
        }                
    }

    if(isset($_GET['instructor_del_req'])){
        $id = $_GET['instructor_del_req'];
        $delete = "DELETE FROM pending_registration WHERE id = '$id'";
        if(mysqli_query($conn, $delete)){
            $_SESSION['del_request'] = "Deleted!";
            header('location: ../pages/instructor.php');
        }                
    }
?>


