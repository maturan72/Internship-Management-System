<?php
    session_start();
    include 'db_con.php';

    if(isset($_POST['create-application'])){
        $studentid = $_POST['studentid'];
        // $comp_id = $_POST['comp_id'];
        $hours = $_POST['hours'];

        $select = mysqli_query($conn, "SELECT * FROM `application` WHERE studentid = '$studentid' ");

        if(mysqli_num_rows($select) > 0){
            $update_data = "UPDATE `application` SET hours_spent = '$hours' WHERE studentid = '$studentid' ";
                if(mysqli_query($conn, $update_data)){
                    $_SESSION['application_succ'] = "Application Succesfully Sent";
                    header('location: ../pages/student.php?inc=documents');
                }
        }else{
            $insert_data = "INSERT INTO `application` VALUE (NULL,'$studentid','','$hours')";
            if(mysqli_query($conn, $insert_data)){
                $_SESSION['application_succ'] = "Application Succesfully Sent";
                header('location: ../pages/student.php?inc=documents');
            }
        }
    }

    if(isset($_POST['create-waiver'])){
        $studentid = $_POST['studentid'];
        $comp_id = $_POST['comp_id'];
        $w1 = $_POST['w1'];
        $w2 = $_POST['w2'];
        $confirmname = $_POST['confirmname'];
        $confirmaddress = $_POST['confirmaddress'];

        $select = mysqli_query($conn, "SELECT * FROM `waiver` WHERE studentid = '$studentid' ");

        if(mysqli_num_rows($select) > 0){
            $update_data = "UPDATE `waiver` SET witness1 = '$w1', witness2 = '$w2', confirmedby = '$confirmname', confirmeraddress = '$confirmaddress' WHERE studentid = '$studentid' ";
                if(mysqli_query($conn, $update_data)){
                    $_SESSION['application_succ'] = "Application Succesfully Sent";
                    header('location: ../pages/student.php?inc=documents');
                }
        }else{
            $insert_data = "INSERT INTO `waiver` VALUE (NULL,'$studentid','$comp_id','$w1','$w2','$confirmname','$confirmaddress')";
            if(mysqli_query($conn, $insert_data)){
                $_SESSION['application_succ'] = "Application Succesfully Sent";
                header('location: ../pages/student.php?inc=documents');
            }
        }
        
    }

    if(isset($_POST['create-evaluation'])){
        $studentid = $_POST['studentid'];
        $comp_id = $_POST['comp_id'];
        $hours = $_POST['hours'];
       
        $select = mysqli_query($conn, "SELECT * FROM `evaluation` WHERE studentid = '$studentid' ");

        if(mysqli_num_rows($select) > 0){
            $update_data = "UPDATE `evaluation` SET hours_required = '$hours' WHERE studentid = '$studentid' ";
                if(mysqli_query($conn, $update_data)){
                    $_SESSION['application_succ'] = "Application Succesfully Sent";
                    header('location: ../pages/student.php?inc=documents');
                }
        }else{
            $insert_data = "INSERT INTO `evaluation` VALUE (NULL,'$studentid','$comp_id','$hours')";
            if(mysqli_query($conn, $insert_data)){
                $_SESSION['application_succ'] = "Application Succesfully Sent";
                header('location: ../pages/student.php?inc=documents');
            }
        }
    }

    if(isset($_POST['create-information'])){
        $studentid = $_POST['studentid'];
        $status = $_POST['status'];
        $nationality = $_POST['nationality'];
        $bod = $_POST['bod'];
        $bop = $_POST['bop'];
        $height = $_POST['height'];
        $weight = $_POST['weight'];
        $father = $_POST['father'];
        $foccupation = $_POST['f-occupation'];
        $mother = $_POST['mother'];
        $moccupation = $_POST['m-occupation'];
        $paddress = $_POST['p-address'];
        $ptel = $_POST['p-tel'];
        $nos = $_POST['nos'];
        $saddress = $_POST['s-address'];
        $coordinator = $_POST['coordinator'];
        $vpaa = $_POST['vpaa'];
        $ename = $_POST['e-name'];
        $eaddress = $_POST['e-address'];
        $erelation = $_POST['e-relation'];
        $etel = $_POST['e-tel'];
       
        $select = mysqli_query($conn, "SELECT * FROM `information` WHERE studentid = '$studentid' ");

        if(mysqli_num_rows($select) > 0){
            $update_data = "UPDATE `information` SET `status` = '$status', `nationality` = '$nationality', `dob` = '$bod', `pob` = '$bop', `height` = '$height', `weight` = '$weight', `fathersname` = '$father',`fathersoccupation` = '$foccupation',`mothersname` = '$mother',`mothersoccupation` = '$moccupation',`parentsaddress` = '$paddress',`telno` = '$ptel',`nameofschool` = '$nos',`schooladdress` = '$saddress',`coordinator` = '$coordinator',`vpaa` = '$vpaa',`ename` = '$ename',`eaddress` = '$eaddress',`erelationship` = '$erelation',`etelno` = '$etel' WHERE studentid = '$studentid' ";
                if(mysqli_query($conn, $update_data)){
                    $_SESSION['application_succ'] = "Application Succesfully Sent";
                    header('location: ../pages/student.php?inc=documents');
                }
        }else{
            $insert_data = "INSERT INTO `information` VALUE (NULL,'$studentid','$status','$nationality','$bod','$bop','$height','$weight','$father','$foccupation','$mother','$moccupation','$paddress','$ptel','$nos','$saddress','$coordinator','$vpaa','$ename','$eaddress','$erelation','$etel')";
            if(mysqli_query($conn, $insert_data)){
                $_SESSION['application_succ'] = "Application Succesfully Sent";
                header('location: ../pages/student.php?inc=documents');
            }
        }
    }
?>