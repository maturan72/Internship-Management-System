<?php

    session_start();
    include 'db_con.php';

    if(isset($_GET['data'])){
        $id = $_GET['data'];
        $data = mysqli_query($conn, "SELECT * FROM archive WHERE id = '$id'");
        while($rows = mysqli_fetch_array($data)){
            $mydata = json_decode($rows['data']);
            if($mydata->type == 'instructor'){
                $insert = "INSERT INTO instructor VALUES('$mydata->id','$mydata->firstname','$mydata->middlename','$mydata->lastname','$mydata->address','$mydata->email','$mydata->password','$mydata->contact')";
                if(mysqli_query($conn, $insert)){
                    $delete = "DELETE FROM archive WHERE id = '$id'";
                    if(mysqli_query($conn, $delete)){
                        $_SESSION['approved'] = "success";
                        header('location: ../pages/admin.php?inc=archive');
                    }                
                }
            }elseif($mydata->type == 'company'){
                echo"asd";
                $insert = "INSERT INTO company VALUES('$mydata->id','$mydata->firstname','$mydata->middlename','$mydata->lastname','$mydata->email','$mydata->password','$mydata->company','$mydata->address','$mydata->contact')";
                if(mysqli_query($conn, $insert)){
                    $delete = "DELETE FROM archive WHERE id = '$id'";
                    if(mysqli_query($conn, $delete)){
                        $_SESSION['approved'] = "success";
                        header('location: ../pages/admin.php?inc=archive');
                    }                
                }
            }else{
                $insert = "INSERT INTO interns VALUES('$mydata->id','$mydata->student_id','$mydata->firstname','$mydata->middlename','$mydata->lastname','$mydata->age','$mydata->gender','$mydata->contact','$mydata->address','$mydata->course','$mydata->section','$mydata->skills','$mydata->hours','$mydata->company','$mydata->job','$mydata->instructor','$mydata->email','$mydata->password')";
                echo $insert;
                if(mysqli_query($conn, $insert)){
                    $delete = "DELETE FROM archive WHERE id = '$id'";
                    if(mysqli_query($conn, $delete)){
                        $_SESSION['approved'] = "success";
                        header('location: ../pages/admin.php?inc=archive');
                    }                
                }
            }
        }
    }
?>


