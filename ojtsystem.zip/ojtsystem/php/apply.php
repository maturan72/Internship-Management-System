<?php
    session_start();
    include 'db_con.php';

    if(isset($_POST['apply'])){
        $comp_id = $_POST['comp_id'];
        $int_id = $_SESSION['log'];
        $job_title = $_POST['job_title'];
        
        $select = mysqli_query($conn,"SELECT * FROM jobs WHERE job_title = '$job_title' ");
        $row = mysqli_fetch_assoc($select);

        $job_id = $row['id'];


        $insert_data = "INSERT INTO applicants VALUE (NULL,'$int_id','$comp_id','$job_id')";
        if(mysqli_query($conn, $insert_data)){
            $_SESSION['apply_succ'] = "Application Succesfully Sent";
            header('location: ../pages/student.php?inc=company');
        }
    }
?>