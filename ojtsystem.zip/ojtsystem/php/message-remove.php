<?php
    include 'db_con.php';

    $remove_id = $_GET['id'];
    $delete_data = "DELETE FROM `messages` WHERE `messages`.`id` = '$remove_id' ";
    if(mysqli_query($conn, $delete_data)){
        header('location: ../pages/admin.php?inc=messages');
    }
?>