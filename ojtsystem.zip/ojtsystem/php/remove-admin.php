<?php
    include 'db_con.php';

    $remove_id = $_GET['admin_id'];
    $delete_data = "DELETE FROM `admin` WHERE `admin`.`id` = '$remove_id' ";
    if(mysqli_query($conn, $delete_data)){
        header('location: ../pages/admin.php?inc=admin');
    }
?>