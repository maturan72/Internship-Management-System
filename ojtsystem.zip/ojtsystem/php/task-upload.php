<?php
    session_start();
    include 'db_con.php';

    $intern_id = $_POST['intern_id'];
    $comp_id = $_POST['comp_id'];
    $task_desc = $_POST['desc'];
    $progress = $_POST['progress'];
    $taskfile = $_FILES['fileToUpload']['name'];
    $duedate = $_POST['duedate'];
    $status = $_POST['status'];
    $date_submitted = date('m-d-y');
    

    if(isset($_POST['task'])){
        $target_path = "../assets/tasks/";  
        $target_path = $target_path.basename( $_FILES['fileToUpload']['name']);   
       
        if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target_path)) {  
            $insert_data = "INSERT INTO task VALUES (NULL,'$intern_id','$comp_id','$task_desc','$progress','$taskfile','$duedate','$date_submitted','$status')";
                if(mysqli_query($conn, $insert_data)){
                    $_SESSION['task_succ'] = "Application Succesfully Sent";
                    header('location: ../pages/student.php?inc=task');
            } 
        } else{  
            echo "Sorry, file not uploaded, please try again!";  
        }  
    }

?>