<?php
     session_start();
     include 'db_con.php';
     date_default_timezone_set('Asia/Manila');
     include "total_time.php";
    if(isset($_POST['time'])){
        $id = $_POST['id'];
        $date = date('m-d-y');
        $time = date('h:i:s');
       
        $select = mysqli_query($conn, "SELECT * FROM time_in WHERE intern_id = '$id' ");
        
        if(mysqli_num_rows($select) > 0){
            $timeout = mysqli_query($conn, "SELECT * FROM time_in WHERE intern_id = '$id' AND `timeout` = '' ");
            if($row = mysqli_fetch_array($timeout)){
                $data_id = $row['id'];
                $update = "UPDATE `time_in` SET `timeout` = '$time' WHERE `id` = '$data_id' ";
                if(mysqli_query($conn, $update)){
                    $update_hours =  "UPDATE interns SET `hours` = '$total_hours' WHERE `id` = '$user_id'";
                    if(mysqli_query($conn, $update_hours)){
                        $_SESSION['timeout'] = 'Time out Succesfully';
                        header('location: ../pages/student.php?inc=time');
                    }
                }
            }else{
                $insert = "INSERT  INTO`time_in` VALUES (NULL,'$id','$date','$time','')";
                if(mysqli_query($conn, $insert)){
                    $_SESSION['timein'] = 'Time In Succesfully';
                    header('location: ../pages/student.php?inc=time');
                }
            }
           
        }
        else{
            
            $insert = "INSERT INTO time_in VALUES (NULL,'$id','$date','$time','')";
            if(mysqli_query($conn, $insert)){
                $_SESSION['timein'] = 'Time In Succesfully';
                header('location: ../pages/student.php?inc=time');
            }
        }
       
    }

?>