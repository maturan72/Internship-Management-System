<script src="../includes/bootstrap/js/jquery.min.js"></script>
<script src="../includes/bootstrap/js/bootstrap.min.js"></script>
<script>
    window.print();
</script>
</body>
</html>