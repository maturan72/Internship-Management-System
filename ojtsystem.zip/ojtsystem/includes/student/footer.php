<script src="../includes/bootstrap/js/jquery.min.js"></script>
<script src="../includes/bootstrap/js/bootstrap.min.js"></script>
<script src="../js/drop_upload_file.js"></script>
<script src="../js/filter_table.js"></script>
<!-- <script src="../js/multipleform.js"></script> -->
<script src="../js/sweetalert.min.js"></script>
<script src="../js/html2pdf.min.js"></script>
<script>
    jQuery(function ($) {

        $(".sidebar-dropdown > a").click(function() {
        $(".sidebar-submenu").slideUp(200);
        if (
        $(this)
        .parent()
        .hasClass("active")
        ) {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
        .parent()
        .removeClass("active");
        } else {
        $(".sidebar-dropdown").removeClass("active");
        $(this)
        .next(".sidebar-submenu")
        .slideDown(200);
        $(this)
        .parent()
        .addClass("active");
        }
        });

        $("#close-sidebar").click(function() {
        $(".page-wrapper").removeClass("toggled");
        });
        $("#show-sidebar").click(function() {
        $(".page-wrapper").addClass("toggled");
        });

    });
</script>

<!-- ALERT SECTION -->
<?php
    if($_SESSION['task_succ']){?>
    <script>
      swal({
        title: "Successfully Uploaded!",
        icon: "success",
        button: "Ok",
      });
    </script>
  <?php
        unset($_SESSION['task_succ']);
    }elseif($_SESSION['upd_succ']){?>
      <script>
        swal({
          title: "Successfully Updated!",
          icon: "success",
          button: "Ok",
        });
      </script>
  <?php
    unset($_SESSION['upd_succ']);
    }elseif($_SESSION['timein']){?>
      <script>
        swal({
          title: "Successfully Timed In!",
          icon: "success",
          button: "Ok",
        });
      </script>
  <?php
    unset($_SESSION['timein']);
    }elseif($_SESSION['timeout']){?>
        <script>
          swal({
            title: "Successfully Timed Out!",
            icon: "success",
            button: "Ok",
          });
        </script>
    <?php
      unset($_SESSION['timeout']);
    }elseif($_SESSION['apply_succ']){?>
        <script>
          swal({
            title: "Application Successfully Sent!",
            icon: "success",
            button: "Ok",
          });
        </script>
    <?php
      unset($_SESSION['apply_succ']);
      }elseif($_SESSION['application_succ']){?>
        <script>
          swal({
            title: "Application Successfully Created",
            icon: "success",
            button: "Ok",
          });
        </script>
    <?php
      unset($_SESSION['application_succ']);
      }
?>
</body>
</html>