<script src="../includes/bootstrap/js/jquery.min.js"></script>
<script src="../includes/bootstrap/js/bootstrap.min.js"></script>
<script src="../js/filter_table.js"></script>
<script src="../js/sweetalert.min.js"></script>

<script>
    jQuery(function ($) {

$(".sidebar-dropdown > a").click(function() {
$(".sidebar-submenu").slideUp(200);
if (
$(this)
  .parent()
  .hasClass("active")
) {
$(".sidebar-dropdown").removeClass("active");
$(this)
  .parent()
  .removeClass("active");
} else {
$(".sidebar-dropdown").removeClass("active");
$(this)
  .next(".sidebar-submenu")
  .slideDown(200);
$(this)
  .parent()
  .addClass("active");
}
});

$("#close-sidebar").click(function() {
$(".page-wrapper").removeClass("toggled");
});
$("#show-sidebar").click(function() {
$(".page-wrapper").addClass("toggled");
});

});
</script>


<!-- ALERT SECTION -->
<?php
    if($_SESSION['remove_applicants']){?>
    <script>
      swal({
        title: "Successfully Remove!",
        icon: "success",
        button: "Ok",
      });
    </script>
  <?php
        unset($_SESSION['remove_applicants']);
    }elseif($_SESSION['upd_succ']){?>
      <script>
        swal({
          title: "Successfully Updated!",
          icon: "success",
          button: "Ok",
        });
      </script>
  <?php
    unset($_SESSION['upd_succ']);
    }elseif($_SESSION['accept_succ']){?>
      <script>
        swal({
          title: "Applicants Successfully Accepted!",
          icon: "success",
          button: "Ok",
        });
      </script>
  <?php
    unset($_SESSION['accept_succ']);
    }
    elseif($_SESSION['job_suc']){?>
      <script>
        swal({
          title: "Jobs Successfully Created!",
          icon: "success",
          button: "Ok",
        });
      </script>
  <?php
    unset($_SESSION['job_suc']);
    }
?>


</body>
</html>