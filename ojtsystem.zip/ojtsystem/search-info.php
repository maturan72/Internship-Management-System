<div class="register">
    <div class="register-content">
        <div class="row">
            <div class="col-md-4 left-col">
                <div class="image text-center">
                    <img src="assets/images/bpclogo.png" alt="">
                    <h3>Bulacan</h3>
                    <h4>Polytechnic College</h4>
                </div>
                <div class="mission-vission text-center">
                    <h5>VISSION</h5>
                    <p>Bulacan Polytechnic College envisions to become a lead provider of the quality and affordable technical-vocational, entrepreneurial and technological education, and a producer of highly competent and productive human resource.
                    </p>
                </div>
            </div>
            <div class="col-md-8">
                <div class="right-col row">
                    <div class="col-md-12">
                        <div class="admin-info">
                            <div class="admin-update">
                                <div class="box-header">
                                    <h4 class="text-primary f-bold">Company Information</h4>
                                </div>
                                <?php
                                    $com_id = $_GET['id'];
                                    $select_comp = mysqli_query($conn, "SELECT * FROM company WHERE id = '$com_id'");
                                    while($row = mysqli_fetch_array($select_comp)){?>
                                        <div class="box-content">
                                            <div class="row">
                                                <div class="email">
                                                    <label for=""><strong>Company Name:</strong></label>
                                                    <input class="form-control" type="text" name="" value="<?php echo $row['companyname']  ?>" readonly>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="email mt-4">
                                                    <label for=""><strong>Company Address:</strong></label>
                                                    <input class="form-control" type="text" name="" value="<?php echo $row['address'] ?>" readonly>
                                                </div>
                                            </div>
                                            <div class="row mt-4">
                                                <h4 class="f-bold text-primary">Supervisor Info:</h4>
                                                <div class="col-md-5">
                                                    <label for=""><strong>Full Name:</strong></label>
                                                    <input class="form-control" type="text" name="" value="<?php echo $row['firstname'] .' '. $row['middlename'] .' '. $row['lastname'] ?>" readonly>
                                                </div>
                                                <div class="col-md-7">
                                                        <label for=""><strong>Email Address:</strong></label>
                                                        <input class="form-control" type="email" name="" value="Supervisor@gmail.com" readonly>
                                                </div>
                                            </div>
                                            <div class="button mt-4 text-end">
                                            <a class="btn btn-danger" href="login.php?inc=search">Go Back</a> | <a class="btn btn-success" href="login.php?inc=application&id=<?php echo $com_id ?>">Send Application</a>
                                            </div>
                                        </div>
                                <?php
                                    }
                                ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>