$( document ).ready(function() {
    $('#email').on('change', function() {
        //ajax request
        $.ajax({
            url: "php/validate_email.php",
            data: {
                'email' : $('#email').val()
            },
            dataType: 'json',
            success: function(data) {
                if(data == true) {
                    document.getElementById('email_message').innerHTML = 'Email Already Exist';
                    document.getElementById('email_message').classList = 'text-danger';
                    document.getElementById('submit').type = "button";
                    document.getElementById('submit').value = "Change Email!";
                }
                else {
                    document.getElementById('email_message').innerHTML = 'Email Available';
                    document.getElementById('email_message').classList = 'text-success';
                    document.getElementById('submit').type = "submit";
                    document.getElementById('submit').value = "Register Now..";
                }
            },
            error: function(data){
                //error
            }
        });
    });
});