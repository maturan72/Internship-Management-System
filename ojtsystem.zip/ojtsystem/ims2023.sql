-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 29, 2023 at 09:47 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ims2023`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `firstname`, `middlename`, `lastname`, `email`, `password`) VALUES
(1, 'john', 'sure', 'doe', 'john@gmail.com', 'johndoe');

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE `applicants` (
  `id` int(11) NOT NULL,
  `intern_id` varchar(255) NOT NULL,
  `company_id` varchar(255) NOT NULL,
  `job_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `id` int(11) NOT NULL,
  `studentid` varchar(255) NOT NULL,
  `comp_id` varchar(255) NOT NULL,
  `hours_spent` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`id`, `studentid`, `comp_id`, `hours_spent`) VALUES
(5, '10-44321', '2', '8');

-- --------------------------------------------------------

--
-- Table structure for table `archive`
--

CREATE TABLE `archive` (
  `id` int(11) NOT NULL,
  `data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `firstname`, `middlename`, `lastname`, `email`, `password`, `companyname`, `address`, `contact`) VALUES
(1, 'Jason', 'Calimbo', 'Cubijano', 'Jason@gmail.com', 'jason', 'Jason Company', 'Brgy, Matapay  Hilongos, Leyte', '09123456789'),
(2, 'Mark', 'Dag', 'Dagohoy', 'mark@gmail.com', 'mark', 'Mark Company', 'Brgy, western Hilongos Leyte', '09876543211');

-- --------------------------------------------------------

--
-- Table structure for table `evaluation`
--

CREATE TABLE `evaluation` (
  `id` int(11) NOT NULL,
  `studentid` varchar(255) NOT NULL,
  `comp_id` varchar(255) NOT NULL,
  `hours_required` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `evaluation`
--

INSERT INTO `evaluation` (`id`, `studentid`, `comp_id`, `hours_required`) VALUES
(2, '10-44321', '2', '500');

-- --------------------------------------------------------

--
-- Table structure for table `information`
--

CREATE TABLE `information` (
  `id` int(11) NOT NULL,
  `studentid` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `pob` varchar(255) NOT NULL,
  `height` varchar(255) NOT NULL,
  `weight` varchar(255) NOT NULL,
  `fathersname` varchar(255) NOT NULL,
  `fathersoccupation` varchar(255) NOT NULL,
  `mothersname` varchar(255) NOT NULL,
  `mothersoccupation` varchar(255) NOT NULL,
  `parentsaddress` varchar(255) NOT NULL,
  `telno` varchar(255) NOT NULL,
  `nameofschool` varchar(255) NOT NULL,
  `schooladdress` varchar(255) NOT NULL,
  `coordinator` varchar(255) NOT NULL,
  `vpaa` varchar(255) NOT NULL,
  `ename` varchar(255) NOT NULL,
  `eaddress` varchar(255) NOT NULL,
  `erelationship` varchar(255) NOT NULL,
  `etelno` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `instructor`
--

CREATE TABLE `instructor` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructor`
--

INSERT INTO `instructor` (`id`, `firstname`, `middlename`, `lastname`, `address`, `email`, `password`, `contact`) VALUES
(1, 'Jolly', 'Calimbo', 'Cubijano', 'Brgy, western Hilongos Leyte', 'jolly@gmail.com', 'jolly', '09876543211'),
(2, 'James', 'john', 'Mayao', 'Brgy, Matapay  Hilongos, Leyte', 'james@gmail.com', 'james', '09123456789');

-- --------------------------------------------------------

--
-- Table structure for table `interns`
--

CREATE TABLE `interns` (
  `id` int(11) NOT NULL,
  `student_id` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `skills` varchar(255) NOT NULL,
  `hours` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `job_id` varchar(255) NOT NULL,
  `instructor` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `interns`
--

INSERT INTO `interns` (`id`, `student_id`, `firstname`, `middlename`, `lastname`, `age`, `gender`, `contact`, `address`, `course`, `section`, `skills`, `hours`, `company`, `job_id`, `instructor`, `email`, `password`) VALUES
(2, '10-44321', 'Iderf', 'Lor', 'Neor', '24', 'female', '0987123476', 'Brgy, Matapay  Hilongos, Leyte', 'BSIT', '1-C', 'Encoding', '00:00:02', '2', '2', '1', 'iderf@gmail.com', 'iderf');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `comp_id` varchar(255) NOT NULL,
  `job_desc` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `total_intern` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `job_title`, `comp_id`, `job_desc`, `position`, `total_intern`) VALUES
(1, 'Web Development', '1', 'Need of web developer who have knowledge of html, css, javascript, and php', '20', '1'),
(2, 'Encoder', '2', 'Need student that are fast in ecncoding', '20', '1');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contactno` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `message_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pending_registration`
--

CREATE TABLE `pending_registration` (
  `id` int(11) NOT NULL,
  `data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `id` int(11) NOT NULL,
  `intern_id` varchar(255) NOT NULL,
  `comp_id` varchar(255) NOT NULL,
  `task_title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `documents` varchar(255) NOT NULL,
  `due_date` varchar(255) NOT NULL,
  `date_submitted` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`id`, `intern_id`, `comp_id`, `task_title`, `description`, `documents`, `due_date`, `date_submitted`, `status`) VALUES
(1, '2', '2', 'Encoding', 'Encoding of application for something', 'Screenshot from 2023-01-02 14-22-28.png', '2023-01-31', '01-29-23', 'ongoing'),
(2, '2', '2', 'programming', 'working on a website', 'starlogo.png', '2023-02-02', '01-29-23', 'ongoing'),
(3, '2', '2', 'programming', 'Still working on this task.', 'logo2.jpg', '2023-02-02', '01-29-23', 'ongoing'),
(4, '2', '2', 'Encoding of Word Documents', 'Still Working', 'logo.png', '2023-01-30', '01-29-23', 'done'),
(5, '2', '2', 'Encoding of Word Documents', 'Encoding of application for something', 'logo2.jpg', '2023-01-29', '01-29-23', 'done'),
(6, '2', '2', 'programming', 'Still working on this task.', 'logo.png', '2023-02-01', '01-29-23', 'ongoing'),
(7, '2', '2', 'Encoding', 'Still working on this task.', 'logo2.jpg', '2023-01-31', '01-29-23', 'ongoing'),
(8, '2', '2', 'programming', 'working on a website', 'logo.png', '2023-01-29', '01-29-23', 'done');

-- --------------------------------------------------------

--
-- Table structure for table `time_in`
--

CREATE TABLE `time_in` (
  `id` int(11) NOT NULL,
  `intern_id` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `timein` varchar(255) NOT NULL,
  `timeout` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `time_in`
--

INSERT INTO `time_in` (`id`, `intern_id`, `date`, `timein`, `timeout`) VALUES
(1, '2', '01-29-23', '04:14:39', '04:14:41'),
(2, '2', '01-29-23', '04:14:49', '04:14:51');

-- --------------------------------------------------------

--
-- Table structure for table `waiver`
--

CREATE TABLE `waiver` (
  `id` int(11) NOT NULL,
  `studentid` varchar(255) NOT NULL,
  `comp_id` varchar(255) NOT NULL,
  `witness1` varchar(255) NOT NULL,
  `witness2` varchar(255) NOT NULL,
  `confirmedby` varchar(255) NOT NULL,
  `confirmeraddress` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `waiver`
--

INSERT INTO `waiver` (`id`, `studentid`, `comp_id`, `witness1`, `witness2`, `confirmedby`, `confirmeraddress`) VALUES
(8, '10-44321', '2', 'Morgan S. Dagano', 'Jolly C. Cubjijano', 'Morgan S. Dagano', 'Brgy, Western Hilongos Leyte');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `applicants`
--
ALTER TABLE `applicants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `archive`
--
ALTER TABLE `archive`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `evaluation`
--
ALTER TABLE `evaluation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `information`
--
ALTER TABLE `information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `interns`
--
ALTER TABLE `interns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pending_registration`
--
ALTER TABLE `pending_registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `time_in`
--
ALTER TABLE `time_in`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `waiver`
--
ALTER TABLE `waiver`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `applicants`
--
ALTER TABLE `applicants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `archive`
--
ALTER TABLE `archive`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `evaluation`
--
ALTER TABLE `evaluation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `information`
--
ALTER TABLE `information`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `instructor`
--
ALTER TABLE `instructor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `interns`
--
ALTER TABLE `interns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pending_registration`
--
ALTER TABLE `pending_registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `time_in`
--
ALTER TABLE `time_in`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `waiver`
--
ALTER TABLE `waiver`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
