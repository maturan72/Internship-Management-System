<div class="page-title">
    <h4>My Task</h4>
    <div class="task-list d-flex">
        <a href="?inc=task">All Task</a>
        <a href="?inc=finish-task">Finished Task</a>
        <a class="text-success"  href="?inc=ongoing-task">Ongoing Task</a>
        <!-- <a href="">Pending Task</a> -->
    </div>
</div>

<div class="row ">
    <div class="col-md-12">
            <div class="upload-task text-end">
                <input class="w-50 form-control input-search" type="text" id="myInput" placeholder="Search for names..">
                <a href="student.php?inc=upload-task" class="btn btn-info">Upload Task</a>
            </div>
        <hr>
        <table class="table table-hover table-sm">
            <thead class="text-secondary">
                <tr>
                <th scope="col">Task Name</th>
                <th scope="col">progress</th>
                <th scope="col">Due Date</th>
                <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody id="myTable">
            <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM task WHERE intern_id = '$id' AND status = 'ongoing' ";
                    $result = mysqli_query($conn, $select);
                    while($rows = mysqli_fetch_array($result)){?>
                    
                        <tr>
                        <td><?php echo $rows['task_title'] ?></td>
                        <td><?php echo $rows['description'] ?></td>
                        <td><?php echo $rows['due_date'] ?></td>
                        <td><?php echo $rows['status'] ?></td>
                        </tr>
                    
                <?php
                    }
                ?>
            </tbody>
        </table>
    </div>
</div>