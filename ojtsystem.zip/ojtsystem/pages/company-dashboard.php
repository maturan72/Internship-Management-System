<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-home" aria-hidden="true"></i> Home</h4>
</div>
<div class="row total-count">
    <div class="cards col-md-3">
        <div class="card-body cb-1 d-flex align-items-center">
            <div class="count">
                <h6 class="">Interns</h6>
                <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM interns WHERE company = '$id'";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo "<h5 class='f-bold'>$row</h5>"
                ?>
            </div>
        </div>
    </div>
    
    <div class="cards col-md-3">
        <div class="card-body cb-2 d-flex align-items-center">
            <div class="count">
                <h6 class="">Task Uploaded Today</h6>
                <?php 
                    $id = $_SESSION['log'];
                    $date_submitted = date("jS \of F Y");
                    $select = "SELECT * FROM task WHERE comp_id = '$id' AND date_submitted = '$date_submitted' ";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo "<h5 class='f-bold'>$row</h5>"
                ?>
            </div>
        </div>
    </div>
    <hr>
</div>
<div class="recent-task">
    <div class="row comp-table">
        <div class="col-md-12 overflow-5">
            <div class="row">
                <h5 class="f-bold text-secondary uppercase">Recent Task Updates</h5>
            </div>
            <div class="upload-task text-end">
                <label class="f-bold text-secondary uppercase mr-2">Seach for Recent Task </label>
                <input class="w-50 form-control input-search" type="text" id="myInput" placeholder="Search for Records..">
            </div>
            <hr>
            <table class="table table-hover table-sm">
                <thead class="text-dark">
                    <tr>
                    <th scope="col">Task Description</th>
                    <th scope="col">Intern</th>
                    <th scope="col">Description</th>
                    <th scope="col">due date</th>
                    <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody id="myTable">
                <?php 
                    $id = $_SESSION['log'];
                    $date_submitted = date('m-d-y');
                    $select = "SELECT * FROM task INNER JOIN interns
                    ON task.intern_id = interns.id WHERE comp_id = '$id' AND date_submitted = '$date_submitted' ORDER BY task.id DESC LIMIT 20 ";
                    $result = mysqli_query($conn, $select);
                    
                    while($rows = mysqli_fetch_array($result)){?>
                    
                   
                        <tr>
                        <td><?php echo $rows['task_title'] ?></td>
                        <td><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname'] ?></td>
                        <td><?php echo $rows['description'] ?></td>
                        <td><?php echo $rows['due_date'] ?></td>
                        <td><?php echo $rows['status'] ?></td>
                        </tr>
                    
                <?php
                    }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
