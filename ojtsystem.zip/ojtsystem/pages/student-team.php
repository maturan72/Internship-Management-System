<div class="page-title">
    <h4>My Team Members</h4>
  <hr>
</div>
<div class="row inbox-section">
   <div class="avatar-user d-flex">
       <div class="avatar1">
           <img src="../assets/images/avatar.jpg" alt="">
       </div>
       <div class="">
           <div class="user-name">
               <h4 class="f-bold m-0">Darwin Maturan</h4>
               <p class="message-content m-0"> Skills:<span class="f-bold"> Programmin, Encoding, Data Analyst, Problem Solving</span></p>
           </div>
       </div>
   </div>
   <div class="avatar-user mt-4 d-flex">
       <div class="avatar1">
           <img src="../assets/images/bpclogo.png" alt="">
       </div>
       <div class="">
            <div class="user-name">
               <h4 class="f-bold m-0">Jolly Cubijani</h4>
               <p class="message-content m-0"> Skills:<span class="f-bold"> Programmin, Encoding, Data Analyst, Problem Solving</span></p>
            </div>
       </div>
   </div>
   <div class="avatar-user mt-4 d-flex">
       <div class="avatar1">
           <img src="../assets/images/intern.jpg" alt="">
       </div>
       <div class="">
            <div class="user-name">
               <h4 class="f-bold m-0">Joseph Cedric</h4>
               <p class="message-content m-0"> Skills:<span class="f-bold"> Programmin, Encoding, Data Analyst, Problem Solving</span></p>
            </div>
       </div>
   </div>
   <div class="avatar-user mt-4 d-flex">
       <div class="avatar1">
           <img src="../assets/images/student.jpg" alt="">
       </div>
       <div class="">
            <div class="user-name">
               <h4 class="f-bold m-0">John Wick</h4>
               <p class="message-content m-0"> Skills:<span class="f-bold"> Programmin, Encoding, Data Analyst, Problem Solving</span></p>
            </div>
       </div>
   </div>
</div>