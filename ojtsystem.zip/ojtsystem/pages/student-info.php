<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-user" aria-hidden="true"></i> My Information</h4>
  <hr>
</div>
<?php
    $id = $_SESSION['log'];
    $instructor_data = "SELECT * FROM interns WHERE id = '$id'";
    $ins_result = mysqli_query($conn, $instructor_data);
    while($data = mysqli_fetch_array($ins_result)){
        ?>
<div class="row information">
    <div class="col-md-4 background-avatar text-center">
       <img src="../assets/avatar/<?php echo $data['id'].$data['firstname'].'.jpg' ?>" alt="">
   </div>
   <div class="col-md-8">
       <div class="">
            <div class="Instructor info">
                <h2 class="m-0"><?php echo $data['firstname'].' '.$data['middlename'][0].' '.$data['lastname']?></h2>
                <small class="text-secondary">Intern Name</small>
            </div>  
                <hr class="m-0"> 
            <div class="row">
                <div class="col-md-12">
                    <div class="row  mt-4">
                        <div class="col-md-6">
                            <div class="age">
                                <h6 class="m-0"><?php echo $data['age']?></h6>
                                <small class="text-secondary">Age</small>
                            </div> 
                        </div>
                        <div class="col-md-6">
                            <div class="gender">
                                <h6 class="m-0"><?php echo $data['gender']?></h6>
                                <small class="text-secondary">Gender</small>
                            </div> 
                        </div>
                    </div>
                    <hr class="m-0">
                    <div class="row mt-4">
                        <div class="course col-md-6">
                            <h6 class="m-0"><?php echo $data['course']?></h6>
                            <small class="text-secondary">course</small>
                        </div> 
                        <div class="course col-md-6">
                            <h6 class="m-0"><?php echo $data['contact']?></h6>
                            <small class="text-secondary">Contact Number</small>
                        </div> 
                    </div>
                    <hr class="m-0">
                    <div class="row  mt-4" >
                        <div class="col-md-6">
                            <div class="address">
                                <h6 class="m-0"><?php echo $data['address']?></h6>
                                <small class="text-secondary">Current Address</small>
                            </div> 
                        </div>
                        <div class="col-md-6">
                            <div class="email">
                                <h6 class="m-0"><?php echo $data['email']?></h6>
                                <small class="text-secondary">email Address</small>
                            </div> 
                        </div>
                    </div>
                    <hr class="m-0">
                    <!-- <div class="datadocuments mt-4">
                        <?php
                            $id = $_SESSION['log'];
                            $select = mysqli_query($conn, "SELECT * FROM interns WHERE id ='$id' ");
                    
                            $data = mysqli_fetch_array($select);
                            $name = $data['firstname'];
                    
                            if ($handle = opendir('../assets/documents/'.$id.$name.'/')) {
                                $path = $id.$name.'/';
                                while (false !== ($entry = readdir($handle))) {
                            
                                    if ($entry != "." && $entry != "..") {?>
                                    <a href="../assets/documents/<?php echo $path.$entry ?>"><?php echo $entry?></a>
                                    <br>
                                <?php    
                                    }
                                }
                            
                                closedir($handle);
                            }
                        ?>
                        <br>
                        <small class="text-secondary">Student Documents (click to download)</small>
                    </div>  -->
                    <!-- <hr class="m-0"> -->
                </div>
            </div> 
            <div class="update text-end mt-4">
                <a href="?inc=info-update" class="btn btn-info">Update Information</a>
            </div>
        </div>
   </div>
</div>
<?php
    }
?>