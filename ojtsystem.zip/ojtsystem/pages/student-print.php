<?php include "../includes/printheader/header.php" ?>

<div class="container h-1vh overflow">
        <div class="text-center">
            <h2 class="uppercase text-secondary">Weekly Reports</h2>
        </div>
    <div class="timeline bg-white text-black">
        <?php
             $limit = 7;  
             if (isset($_GET["page"])) {
                 $page  = $_GET["page"]; 
                 } 
                 else{ 
                 $page=1;
                 };  
             $start_from = ($page-1) * $limit;  
                 
             $id = $_SESSION['log'];
             $select = "SELECT * FROM task WHERE intern_id = '$id' ORDER BY id DESC LIMIT $start_from, $limit ";
             $result = mysqli_query($conn, $select);
             while($rows = mysqli_fetch_array($result)){?>
                <div class="text-center alert alert-success mt-4">
                    <div class="timeline-row">
                        <div class="timeline-content text-black">
                            <i class="icon-attachment"></i>
                            <h4><?php echo $rows['task_title']?></h4>
                            <p><?php echo $rows['description']?></p>
                            
                        </div>
                        <div class="timeline-time text-secondary">
                            <?php echo $rows['date_submitted']?>
                        </div>
                    </div>
                </div>
            <?php
            }
        ?>
	</div>
</div>

<?php include "../includes/printheader/footer.php" ?>