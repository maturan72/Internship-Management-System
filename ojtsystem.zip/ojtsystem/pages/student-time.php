<div class="page-title">
<h4 class="uppercase text-secondary"> <i class="fa fa-clock-o" aria-hidden="true"></i> My Time Records</h4>
</div>

<div class="task-table">
    <form action="../php/time-in-out.php" method="post">
        <div class="row">
            <div class="col-md-4">
                <div class="punch-time">
                    <h5>Current Time: <span id="live_time"></span></h5>
                    <div class="background-avatar avatar">
                        <img src="../assets/avatar/<?php echo $rows['id'].$rows['firstname'].'.jpg' ?>" alt="">
                    </div>
                </div>
                <div class="upload-task mt-4">
                    <input type="hidden" class="btn btn-info" name="id" value="<?php echo $_SESSION['log']?>">
                    <?php 
                        $id = $_SESSION['log'];
                        $date = date('m-d-y');
                        $select = "SELECT * FROM time_in WHERE intern_id = '$id' ORDER BY id DESC LIMIT 1";
                        $result = mysqli_query($conn, $select);
                        $rows = mysqli_fetch_array($result);
                        if($rows['timein'] != '' && $rows['timeout'] == ''){?>
                        <input type="submit" class="btn btn-danger w-100" name="time" value="Time Out">
                    <?php
                        }else{?>
                        <input type="submit" class="btn btn-info w-100" name="time" value="Time in">
                    <?php
                        }
                    ?>
                </div>
            </div>
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-7">
                        <h5>Time in / Time out Records</h5>         
                    </div>
                    <div class="col-md-5">
                        <?php 
                            $id = $_SESSION['log'];
                            $select = "SELECT * FROM interns WHERE id = '$id' ";
                            $result = mysqli_query($conn, $select);
                            while($rows = mysqli_fetch_array($result)){?>
                                <h6>Total Hours: <?php echo $rows['hours']?></h6>
                        <?php
                            }
                        ?>    
                    </div>
                </div>
                <hr>
                <div class="overflow-4">
                    <table class="table table-hover table-sm">
                        <thead class="text-dark">
                            <tr>
                            <th scope="col">Date</th>
                            <th scope="col">In</th>
                            <th scope="col">Out</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                                $id = $_SESSION['log'];
                                $select = "SELECT * FROM time_in WHERE intern_id = '$id' ";
                                $result = mysqli_query($conn, $select);
                                while($rows = mysqli_fetch_array($result)){?>
                                    <tr>
                                    <td><?php echo $rows['date'] ?></td>
                                    <td><?php echo $rows['timein'] ?></td>
                                    <td><?php echo $rows['timeout'] ?></td>
                                    </tr>
                            <?php
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </form>
</div>
<script>
setInterval(function(){
    var liveTime = new Date();
    document.getElementById("live_time").innerHTML = liveTime.toLocaleTimeString();
}, 1000);
</script>