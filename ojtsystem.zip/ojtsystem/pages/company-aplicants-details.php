<div class="page-title">
    <h4>Student Information</h4>
    <hr>
    <form action="../php/accept-intern.php" method="post">
        <?php
            $compid = $_SESSION['log'];
            $id = $_GET['intern_id'];
            $intern_data = "SELECT * FROM interns WHERE id = '$id'";
            $ins_result = mysqli_query($conn, $intern_data);
            while($data = mysqli_fetch_array($ins_result)){
                ?>
        <div class="row information">
        <div class="background-avatar avatar col-md-4 text-center">
            <img src="../assets/avatar/<?php echo $rows['id'].$rows['firstname'].'.jpg' ?>" alt="">
        </div>
        <div class="col-md-8">
            <div class="">
                    <div class="Instructor info">
                        <h3 class="m-0 uppercase"><?php echo $data['firstname'].' '.$data['middlename'][0].' '.$data['lastname']?></h3>
                        <small class="text-secondary">Intern Name</small>
                    </div>  
                        <hr class="m-0"> 
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row  mt-4">
                                <div class="col-md-4">
                                    <div class="age">
                                        <h6 class="m-0"><?php echo $data['age']?></h6>
                                        <small class="text-secondary">Age</small>
                                    </div> 
                                </div>
                                <div class="col-md-4">
                                    <div class="gender">
                                        <h6 class="m-0"><?php echo $data['gender']?></h6>
                                        <small class="text-secondary">Gender</small>
                                    </div> 
                                </div>
                            </div>
                            <hr class="m-0">
                            <div class="row">
                                <div class="course col-md-4 mt-4">
                                    <h6 class="m-0"><?php echo $data['course']?></h6>
                                    <small class="text-secondary">course</small>
                                </div> 
                                <div class="course col-md-4 mt-4">
                                    <h6 class="m-0"><?php echo $data['contact']?></h6>
                                    <small class="text-secondary">contact</small>
                                </div> 
                            </div>
                            <hr class="m-0">
                            <div class="row  mt-4" >
                                <div class="col-md-4">
                                    <div class="address">
                                        <h6 class="m-0"><?php echo $data['address']?></h6>
                                        <small class="text-secondary">Current Address</small>
                                    </div> 
                                </div>
                                <div class="col-md-4">
                                    <div class="email">
                                        <h6 class="m-0"><?php echo $data['email']?></h6>
                                        <small class="text-secondary">email Address</small>
                                    </div> 
                                </div>
                            </div>
                            <hr class="m-0">
                            <div class="row documents-btn mt-4">
                                <?php
                                    $log = $_SESSION['log'];
                                    $select_intern = mysqli_query($conn, "SELECT * FROM interns WHERE id ='$log' ");
                                    $row = mysqli_fetch_array($select_intern);
                                    $student_id = $row['student_id'];

                                    $find_application = mysqli_query($conn, "SELECT * FROM `application` WHERE studentid = '$student_id' ");
                                    $find_waiver = mysqli_query($conn, "SELECT * FROM `waiver` WHERE studentid = '$student_id' ");
                                    $find_evaluation = mysqli_query($conn, "SELECT * FROM `evaluation` WHERE studentid = '$student_id' ");
                                    $find_information = mysqli_query($conn, "SELECT * FROM `information` WHERE studentid = '$student_id' ");

                                    if(mysqli_num_rows($find_application) >= 1){?>
                                        <div class="d-flex flex-column">
                                            <div class="form_name row">
                                                <div class="col-md-5">
                                                    <h4>Student Application Form </h4>
                                                </div>
                                                <div class="col-md-7">
                                                    <div class="text-start">
                                                        <a target='_blank' href="student-application-form.php?studentid=<?php echo $student_id; ?>&comp_id=<?php echo $compid; ?>" class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Print / Save Application</a>
                                                        <!-- <a href="student-application-form.php?studentid=<?php echo $student_id; ?>" class="btn btn-success"><i class="fa fa-download"></i> Download Application</a>
                                                        <a href="?inc=application-form&studentid=<?php echo $student_id; ?>&ACTION=UPLOAD" class="btn btn-warning"><i class="fa fa-upload"></i> Update Application</a> -->
                                                    </div>
                                                </div>
                                            <small class="text-secondary">Application Form</small>
                                            </div>
                                            
                                        </div>
                                <?php
                                    }
                                    if(mysqli_num_rows($find_waiver) >= 1){?>
                                        <div class="d-flex flex-column">
                                            <div class="form_name row">
                                                <div class="col-md-5">
                                                    <h4>Student Waiver Form </h4>
                                                </div>
                                                <div class="col-md-7">
                                                    <div class="text-start">
                                                        <a target='_blank' href="student-waiver.php?studentid=<?php echo $student_id; ?>&comp_id=<?php echo $compid; ?>" class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Print / Save Waiver</a>
                                                        <!-- <a href="?inc=waiver&studentid<?php echo $student_id; ?>&ACTION=DOWNLOAD" class="btn btn-success"><i class="fa fa-download"></i> Download Waiver</a>
                                                        <a href="?inc=waiver&studentid<?php echo $student_id; ?>&ACTION=UPLOAD" class="btn btn-warning"><i class="fa fa-upload"></i> Update Waiver</a> -->
                                                    </div>
                                                </div>
                                            <small class="text-secondary">Waiver Form</small>
                                            </div>
                                            
                                        </div>
                                <?php
                                    }
                                    if(mysqli_num_rows($find_evaluation) >= 1){?>
                                        <div class="d-flex flex-column">
                                            <div class="form_name row">
                                                <div class="col-md-5">
                                                    <h4>Student Evaluation Form </h4>
                                                </div>
                                                <div class="col-md-7">
                                                    <div class="text-start">
                                                        <a target='_blank' href="student-evaluation.php?studentid=<?php echo $student_id; ?>&comp_id=<?php echo $compid; ?>" class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Print / Save Evaluation</a>
                                                        <!-- <a href="?inc=evaluation&studentid<?php echo $student_id; ?>&ACTION=DOWNLOAD" class="btn btn-success"><i class="fa fa-download"></i> Download Evaluation</a>
                                                        <a href="?inc=evaluation&studentid<?php echo $student_id; ?>&ACTION=UPLOAD" class="btn btn-warning"><i class="fa fa-upload"></i> Update Evaluation</a> -->
                                                    </div>
                                                </div>
                                            <small class="text-secondary">Evaluation Form</small>
                                            </div>
                                            
                                        </div>
                                <?php
                                    }
                                    if(mysqli_num_rows($find_information) >= 1){?>
                                        <div class="d-flex flex-column">
                                            <div class="form_name row">
                                                <div class="col-md-5">
                                                    <h4>Student Information Form </h4>
                                                </div>
                                                <div class="col-md-7">
                                                    <div class="text-start">
                                                        <a target='_blank' href="student-information-sheet.php?studentid=<?php echo $student_id; ?>&comp_id=<?php echo $compid; ?>" class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Print / Save Information</a>
                                                        <!-- <a href="?inc=information&studentid<?php echo $student_id; ?>&ACTION=DOWNLOAD" class="btn btn-success"><i class="fa fa-download"></i> Download Information</a>
                                                        <a href="?inc=information&studentid<?php echo $student_id; ?>&ACTION=UPLOAD" class="btn btn-warning"><i class="fa fa-upload"></i> Update Information</a> -->
                                                    </div>
                                                </div>
                                            <small class="text-secondary">Information Form</small>
                                            </div>
                                            
                                        </div>
                                <?php
                                    }
                                ?>
                            </div>
                            <hr class="m-0">
                        </div>
                    </div> 
                    <div class="update text-end mt-4">
                        <input type="hidden" name="studentid" value="<?php echo $data['student_id']?>">
                        <input type="hidden" name="intern_id" value="<?php echo $_GET['intern_id']?>">
                        <input type="hidden" name="comp_id" value="<?php echo $_SESSION['log']?>">
                        <input type="submit" class="btn btn-success" name="accept_intern" value="Accept Intern">
                    </div>
                </div>
        </div>
        </div>
        <?php
            }
        ?>
    </form>
</div>