<?php 
session_start();
include "../php/db_con.php" ;
error_reporting(0);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Documents</title>

    <link rel="stylesheet" href="../includes/bootstrap/css/bootstrap.min.css">
    <style>
        .m-0{
            margin: 0px;
        }
        .p-0{
            padding: 0;
        }
        .p-l-r-50{
            padding: 0px 50px;
        }
        .mr-80{
            margin-right: 80px;
        }
        .mr-50{
            margin-right: 50px;
        }
        .ml-50{
            margin-left: 50px;
        }
        .mr-20{
            margin-right: 20px;
        }
        .bold{
            font-weight: bold;
        }
        .uppercase{
            text-transform: uppercase;
        }
        body{
            font-family: '';
            font-size: 14px;
           
        }
        .header{
            position: absolute;
        }
        .header img{
            width: 100%;
            height: auto;
            background-color: white;
            z-index: 1;
        }
        .background{
            z-index: -1;
            height: 100vh;
            position: relative;
        }
        .background img{
            width: 100%;
            height: auto;
            position: absolute;
            bottom: 0;
            z-index: 1;
        }
        .content{
            padding: 0 96px;
            z-index: 1;
            position: absolute;
            height: 300px;
            background-color: white;
            width: 100%;
            top: 200px;
            text-align: justify;
        }
        .indent{
            text-indent: 50px;
        }
        .trainee{
            display:flex;
            width: 100%;
        }
        .trainee .flex{
            flex: wrap;
        }
        .trainee .flex1{
            flex: 1;
        }
        .trainee .flex-5{
            flex: .3;
        }
        .course{
            display: flex;
        }
        .course p{
            margin: 0;
        }
        .course .flex{
            flex: wrap;
        }
        .course .flex1{
            flex: 1;
        }
        .underline{
            border-bottom: 1px solid lightgray;
        }
        .long{
            width: 200px;
            border-bottom: 1px solid lightgray;
        }
        .table{
            border: 1px solid lightgray;
            border-bottom: none;
        }
        .data{
            display: flex;
        }
        .data .flex1{
            flex:1;
        }
        .data .flex-5{
            flex: .5;
        }
        .data p{
            padding: 0 10px;
            margin: 0;
        }
        .tb-r{
            border-right: 1px solid lightgray;
            border-left: 1px solid lightgray;
        }
        .tb-b{
            border-bottom: 1px solid lightgray;
        }
        .tb-h-6{
            height: 70px;
        }
        .pl-5{
            padding-left: 50px
        }
        .justify{
            text-align: justify;
        }
        .medium{
            border-bottom: 1px solid lightgray;
            width: 100px;
        }
        .long-underline{
            border-bottom: 1px solid lightgray;
            width: 100%;
        }
        .d-flex .flex1{
            flex: 1;
        }
        .malolos{
            position: absolute;
            bottom: 50px;
            z-index: 1;
            font-style: italic;
            color: #03034e;
            font-family: sans-serif;
            margin-left: 96px;
        }
        @page{
            size: legal;
        }
    </style>
</head>
<body>
    <?php
    $studentid = $_GET['studentid'];
    $select_data = mysqli_query($conn, "SELECT s.firstname, s.middlename, s.lastname, s.age, s.gender, s.address, s.course, e.hours_required, c.companyname, c.address AS companyaddress FROM interns s
    INNER JOIN `evaluation` e ON s.student_id = e.studentid INNER JOIN company c ON s.company = c.id WHERE s.student_id = '$studentid' ");
    while($row = mysqli_fetch_array($select_data)){?>

    <div class="header">
        <img src="../assets/forms/header.png" alt="">
    </div>
    <div class="background">
        <img src="../assets/forms/footer.jpg" alt="">
        <div class="content">
            <div class="title text-center">
                <h6>On-the-Job Training Program</h6>
                <h6>Performance Evaluation Report</h6>
            </div>
            <div class="i mt-4 ">
                <div class="trainee course">
                    <p class="flex">Student Trainee: </p>
                    <p class="flex1 underline indent uppercase"><?php echo $row['firstname'].' '.$row['middlename'][0].'. '.$row['lastname'] ?></p>
                    <p class="flex">Age: </p>
                    <p class="flex-5 underline text-center "><?php echo $row['age'] ?></p>
                    <p class="flex">sex: </p>
                    <p class="flex-5 underline text-center uppercase"><?php echo $row['gender'][0] ?></p >
                </div>
                <div class="course">
                    <p class="flex">Course: </p>
                    <p class="flex1 underline indent uppercase"><?php echo $row['course'] ?></p>
                </div>
                <div class="course">
                    <p class="flex">Name of Firm: </p>
                    <p class="flex1 underline indent uppercase"><?php echo $row['companyname'] ?></p>
                </div>
                <div class="course">
                    <p class="flex">Address of Firm: </p>
                    <p class="flex1 underline indent uppercase"><?php echo $row['companyaddress'] ?></p>
                </div>
                <div class="course">
                    <p class="flex">No. of Training Hours required: </p>
                    <p class="flex1 underline indent"><?php echo $row['hours_required'] ?></p>
                    <p class="flex">Total Hours rendered: </p>
                    <p class="flex1 underline"></p>
                </div>
                <div class="course">
                    <p class="flex">Division/Plant Assigned: </p>
                    <p class="flex1 underline"></p>
                </div>
                <div class="course">
                    <p class="flex">Training Period:  From </p>
                    <p class="flex1 underline"></p>
                    <p class="flex">To </p>
                    <p class="flex1 underline"></p>
                </div>
                <div class="text-end mt-4">
                    <label class="long"></label>
                    <div class="mr-50">Signature of Trainee</div>
                </div>
                <div class="table mt-4">
                    <div class="data tb-b tb-h-6">
                        <div class="flex1">
                            <h6 class="text-center  m-0">CRITERIA</h6>
                        </div>
                        <div class="flex-5 ext-center tb-r">
                            <h6 class="text-center  m-0">MAXIMUM RATING TO BE GIVEN</h6>
                        </div>
                        <div class="flex-5">
                            <h6 class="text-center m-0">RATING</h6>
                        </div>
                    </div>
                    <div class="data tb-b">
                        <div class="flex1">
                            <p>1. Quality of Work (thoroughness, accuracy, neatness and effectiveness)</p>
                        </div>
                        <div class="flex-5 text-center  tb-r">
                            <p>20%</p>
                        </div>
                        <div class="flex-5">
                            <p></p>
                        </div>
                    </div>
                    <div class="data tb-b">
                        <div class="flex1">
                            <p>2. Quantity of Work (able to complete work in allotted time)</p>
                        </div>
                        <div class="flex-5 text-center  tb-r">
                            <p>15%</p>
                        </div>
                        <div class="flex-5">
                            <p></p>
                        </div>
                    </div>
                    <div class="data tb-b">
                        <div class="flex1">
                            <p>3. Dependability, Reliability, and Resourcefulness (ability to work with minimum amount of supervision)</p>
                        </div>
                        <div class="flex-5 text-center  tb-r">
                            <p>15%</p>
                        </div>
                        <div class="flex-5">
                            <p></p>
                        </div>
                    </div>
                    <div class="data tb-b">
                        <div class="flex1">
                            <p>4. Judgment (sound decisions, ability to identify and evaluate pertinent factors)</p>
                        </div>
                        <div class="flex-5 text-center  tb-r">
                            <p>10%</p>
                        </div>
                        <div class="flex-5">
                            <p></p>
                        </div>
                    </div>
                    <div class="data tb-b">
                        <div class="flex1">
                            <p>5. Cooperation (works well with everyone, good team worker)</p>
                        </div>
                        <div class="flex-5 text-center  tb-r">
                            <p>10%</p>
                        </div>
                        <div class="flex-5">
                            <p></p>
                        </div>
                    </div>
                    <div class="data tb-b">
                        <div class="flex1">
                            <p>6. Attendance (regularity and punctuality in office attendance and proper observation of break periods</p>
                        </div>
                        <div class="flex-5 text-center  tb-r">
                            <p>10%</p>
                        </div>
                        <div class="flex-5">
                            <p></p>
                        </div>
                    </div>
                    <div class="data tb-b">
                        <div class="flex1">
                            <p>7. Personality (personal grooming and pleasant disposition)</p>
                        </div>
                        <div class="flex-5 text-center  tb-r">
                            <p>10%</p>
                        </div>
                        <div class="flex-5">
                            <p></p>
                        </div>
                    </div>
                    <div class="data tb-b">
                        <div class="flex1">
                            <p>8. Safety (awareness of safety practices)</p>
                        </div>
                        <div class="flex-5 text-center  tb-r">
                            <p>10%</p>
                        </div>
                        <div class="flex-5">
                            <p></p>
                        </div>
                    </div>
                </div>
                <div class="totalrating text-end">
                    <label class="bold">TOTAL RATING: </label>
                    <label class="medium"></label>
                </div>
                <div class="recomendation">
                    <p class="m-0 p-0">Recommendation for the trainee’s future growth:</p>
                    <p class="long-underline mt-4"></p>
                    <p class="long-underline "></p>
                    <p class="long-underline "></p>
                </div>

                <div class="d-flex mt-4">
                    <div class="flex1  p-l-r-50">
                        <h6>Evaluated by:</h6>
                        <div class="text-center mt-4">
                            <label class="long"></label>
                            <label>Name and Signature</label>
                        </div> 
                        <div class="text-center mt-4">
                            <label class="long"></label>
                            <label>Designation</label>
                        </div>    
                    </div>
                    <div class="flex1  p-l-r-50">
                        <h6>Noted by:</h6>
                        <div class="text-center mt-4">
                            <label class="long"></label>
                            <label>Name and Signature</label>
                        </div> 
                        <div class="text-center mt-4">
                            <label class="long"></label>
                            <label>Designation/ Company</label>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
        <div class="malolos">
            <label class="bold">Brgy, Bulihan, City of Malolos</label>
        </div>
    </div>
    <?php
        }
        
    ?>
    <script>window.print();</script>
</body>
</html>