<?php 
session_start();
include "../php/db_con.php" ;
error_reporting(0);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Documents</title>

    <link rel="stylesheet" href="../includes/bootstrap/css/bootstrap.min.css">
    <style>
        .m-0{
            margin: 0px;
        }
        .p-0{
            padding: 0;
        }
        .p-l-r-50{
            padding: 0px 50px;
        }
        .mr-80{
            margin-right: 80px;
        }
        .mr-50{
            margin-right: 50px;
        }
        .ml-50{
            margin-left: 50px;
        }
        .mr-20{
            margin-right: 20px;
        }
        .bold{
            font-weight: bold;
        }
        .underline{
            border-bottom: 1px solid lightgray;
        }
        body{
            font-family: '';
            font-size: 14px;
           
        }
        .header{
            position: absolute;
        }
        .header img{
            width: 100%;
            height: auto;
            background-color: white;
            z-index: 1;
        }
        .background{
            z-index: -1;
            height: 100vh;
            position: relative;
        }
        .background img{
            width: 100%;
            height: auto;
            position: absolute;
            bottom: 0;
            z-index: 1;
        }
        .content{
            padding: 0 96px;
            z-index: 1;
            position: absolute;
            height: 300px;
            background-color: white;
            width: 100%;
            top: 200px;
            text-align: justify;
        }
        .content p{
            padding: 0;
            margin: 0;
        }
        .indent{
            text-indent: 50px;
        }
        .indent-20{
            text-indent: 20px;
        }
        .photo{
            width: 192px;
            height: 192px;
            border: 1px solid black;
        }
        .main-photo{
            display: flex;
            align-items: right;
            justify-content: right;
            width: 100%;
        }
        .data{
            display:flex;
            flex: wrap;
        }
        .personal-data{
            display:flex;
        }
        .personal-data .wrap{
            flex: wrap;
        }
        .personal-data .flex1{
            flex: 1;
            border-bottom: 1px solid lightgray;
        }
        .personal-data .flex-5{
            flex: .5;
            border-bottom: 1px solid lightgray;
        }
        .school-data{
            display:flex;
        }
        .school-data .flex1{
            flex: 1;
        }
        .school-data .flex-5{
            flex: .5;
        }
        .thumbmark{
            display: flex;
            justify-content: center;
        }
        .thumbmark .flex1{
            flex: 1;
            padding: 0px 20px;
        }
        .thumbmark .flex1 p{
            height: 90px;
        }
        .thumbmark .wrap{
            flex: wrap;
            width: 96px;
            height: 96px;
            border: 1px solid black;
        }
        .malolos{
            position: absolute;
            bottom: 50px;
            z-index: 1;
            font-style: italic;
            color: #03034e;
            font-family: sans-serif;
            margin-left: 96px;
        }
        @page{
            size: legal;
        }
    </style>
</head>
<body>
    <?php
    $studentid = $_GET['studentid'];
    $select_data = mysqli_query($conn, "SELECT s.firstname, s.middlename, s.lastname, s.age, s.gender, s.address, s.course, s.contact, i.status, i.nationality, i.dob, i.pob, i.height, i.weight, i.fathersname, i.fathersoccupation, i.mothersname, i.mothersoccupation, i.parentsaddress, i.telno, i.nameofschool, i.schooladdress, i.coordinator, i.vpaa, i.ename, i.eaddress, i.erelationship, i.etelno FROM interns s
    INNER JOIN `information` i ON s.student_id = i.studentid WHERE s.student_id = '$studentid' ");
    while($row = mysqli_fetch_array($select_data)){?>
    <div class="header">
        <img src="../assets/forms/header.png" alt="">
    </div>
    <div class="background">
        <img src="../assets/forms/footer.jpg" alt="">
        <div class="content">
            <div class="title text-center">
                <h6 class="bold">STUDENT INFORMATION SHEET</h6>
            </div>
            <div class="text-end main-photo">
                <div class="photo"></div>
            </div>
            <div class="data mt-4">
                <h6 class="underline">PERSONAL DATA: </h6>
            </div>
            <div class="personal-data mt-4">
                <p class="wrap">Name: </p>
                <p class="flex1 indent-20"><?php echo $row['firstname'].' '.$row['middlename'][0].'. '.$row['lastname'] ?></p>
                <p class="wrap">Status: </p>
                <p class="flex-5 indent-20"><?php echo $row['status'] ?></p>
            </div>
            <div class="personal-data">
                <p class="wrap">Course: </p>
                <p class="flex1 indent-20"><?php echo $row['course'] ?></p>
                <p class="wrap">Year: </p>
                <p class="flex-5 indent-20">4th</p>
                <p class="wrap">Nationality:  </p>
                <p class="flex-5 indent-20"><?php echo $row['nationality'] ?></p>
            </div>
            <div class="personal-data">
                <p class="wrap">Complete Address:  </p>
                <p class="flex1 indent-20"><?php echo $row['address'] ?></p>
                <p class="wrap">CP No.:  </p>
                <p class="flex-5 indent-20"><?php echo $row['contact'] ?></p>
            </div>
            <div class="personal-data">
                <p class="wrap">Date of Birth: </p>
                <p class="flex1 indent-20"><?php echo $row['dob'] ?></p>
                <p class="wrap">Place of Birth: </p>
                <p class="flex1 indent-20"><?php echo $row['pob'] ?></p>
            </div>
            <div class="personal-data">
                <p class="wrap">Age: </p>
                <p class="flex1 indent-20"><?php echo $row['age'] ?></p>
                <p class="wrap">Sex: </p>
                <p class="flex1 indent-20"><?php echo $row['gender'][0] ?></p>
                <p class="wrap">Height: </p>
                <p class="flex1 indent-20"><?php echo $row['height'] ?></p>
                <p class="wrap">Weight (in lbs):</p>
                <p class="flex-5 indent-20"><?php echo $row['weight'] ?></p>
            </div>
            <div class="personal-data">
                <p class="wrap">Physical Disability, if any: </p>
                <p class="flex1"></p>
            </div>
            <div class="data mt-4">
                <h6 class="underline">FAMILY BACKGROUND: </h6>
            </div>
            <div class="personal-data">
                <p class="wrap">Father’s Name: </p>
                <p class="flex1 indent-20"><?php echo $row['fathersname'] ?></p>
                <p class="wrap">Occupation: </p>
                <p class="flex-5 indent-20"><?php echo $row['fathersoccupation'] ?></p>
            </div>
            <div class="personal-data">
                <p class="wrap">Mother’s Name:  </p>
                <p class="flex1 indent-20"><?php echo $row['mothersname'] ?></p>
                <p class="wrap">Occupation: </p>
                <p class="flex-5 indent-20"><?php echo $row['mothersoccupation'] ?></p>
            </div>
            <div class="personal-data">
                <p class="wrap">Address of Parents:  </p>
                <p class="flex1 indent-20"><?php echo $row['parentsaddress'] ?></p>
                <p class="wrap">Tel. No.:  </p>
                <p class="flex-5 indent-20"><?php echo $row['telno'] ?></p>
            </div>
            <div class="data mt-4">
                <h6 class="underline">SCHOOL DATA: </h6>
            </div>
            <div class="school-data">
                <div class="flex-5">
                    <p>Name of School: </p>
                </div>
                <div class="flex1">
                    <p class="uppercase"><?php echo $row['nameofschool'] ?></p>
                </div>
            </div>
            <div class="school-data">
                <div class="flex-5">
                    <p>School Address:</p>
                </div>
                <div class="flex1">
                    <p class="uppercase"><?php echo $row['schooladdress'] ?></p>
                </div>
            </div>
            <div class="school-data">
                <div class="flex-5">
                    <p>Industry/Training Coordinator:</p>
                </div>
                <div class="flex1">
                    <p class="coordinator"><?php echo $row['coordinator'] ?></p>
                </div>
            </div>
            <div class="school-data">
                <div class="flex-5">
                    <p>VPAA/OIC- OCP </p>
                </div>
                <div class="flex1">
                    <p class="bold upperacase"><?php echo $row['vpaa'] ?></p>
                </div>
            </div>
            <div class="data mt-4">
                <h6 class="underline">IN CASE OF EMERGENCY, NOTIFY:</h6>
            </div>
            <div class="personal-data">
                <p class="wrap">Name:  </p>
                <p class="flex1 indent-20"><?php echo $row['ename'] ?></p>
                <p class="wrap">Relationship:  </p>
                <p class="flex1 indent-20"><?php echo $row['erelationship'] ?></p>
            </div>
            <div class="personal-data">
                <p class="wrap">Address:  </p>
                <p class="flex1 indent-20"><?php echo $row['eaddress'] ?></p>
                <p class="wrap">Tel. No.:  </p>
                <p class="flex1 indent-20"><?php echo $row['etelno'] ?></p>
            </div>
            <div class="data mt-4">
                <h6>I HEREBY CERTIFY THAT THE DATA GIVEN ABOVE ARE TRUE AND CORRECT TO THE BEST OF MY KNOWLEDGE AND BELIEF.</h6>
            </div>
            <div class="thumbmark">
                <div class="flex1">
                    <p class="underline"></p>
                </div>
                <div class="wrap"></div>
                <div class="flex1 text-center">
                    <p class="underline"></p>
                    <label for="">Signature of Student</label>
                    
                    <h6 class="underline mt-4"></h6>
                    <label for="">Printed Name of Student</label>
                </div>
            </div>
        </div>
        <div class="malolos">
            <label class="bold">Brgy, Bulihan, City of Malolos</label>
        </div>
    </div>
    <?php
        }
    ?>
    <script>window.print();</script>
</body>
</html>