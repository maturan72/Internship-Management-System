<?php 
session_start();
include "../php/db_con.php" ;
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Documents</title>

    <link rel="stylesheet" href="../includes/bootstrap/css/bootstrap.min.css">
    <style>
        .mr-80{
            margin-right: 80px;
        }
        .mr-50{
            margin-right: 50px;
        }
        .mr-20{
            margin-right: 20px;
        }
        .bold{
            font-weight: bold;
        }
        body{
            font-family: '';
            font-size: 14px;
           
        }
        .header{
            position: absolute;
        }
        .header img{
            width: 100%;
            height: auto;
            background-color: white;
            z-index: 1;
        }
        .background{
            z-index: -1;
            height: 100vh;
            position: relative;
        }
        .background img{
            width: 100%;
            height: auto;
            position: absolute;
            bottom: 0;
            z-index: 1;
        }
        .content{
            padding: 0 96px;
            z-index: 1;
            position: absolute;
            height: 300px;
            background-color: white;
            width: 100%;
            top: 200px;
            text-align: justify;
        }
        .long{
            width: 250px;
            border-bottom: 1px solid lightgray;
        }
        .medium{
            width: 150px;
            border-bottom: 1px solid lightgray;
        }
        .small{
            width: 100px;
            border-bottom: 1px solid lightgray;
        }
        .indent{
            text-indent: 50px;
        }
        .witness{
            display: flex;
        }
        .witness .flex1{
            flex: 1;
        }
        .malolos{
            position: absolute;
            bottom: 50px;
            z-index: 1;
            font-style: italic;
            color: #03034e;
            font-family: sans-serif;
            margin-left: 96px;
        }
        @page{
            size: legal;
        }
    </style>
</head>
<body>
    <?php
    $studentid = $_GET['studentid'];
    $select_data = mysqli_query($conn, "SELECT s.firstname, s.middlename, s.lastname, s.address, w.witness1, w.witness2, w.confirmedby, w.confirmeraddress, c.companyname, c.address AS companyaddress FROM interns s
    INNER JOIN `waiver` w ON s.student_id = w.studentid INNER JOIN company c ON s.company = c.id WHERE s.student_id = '$studentid' ");
    while($row = mysqli_fetch_array($select_data)){?>

    <div class="header">
        <img src="../assets/forms/header.png" alt="">
    </div>
    <div class="background">
        <img src="../assets/forms/footer.jpg" alt="">
        <div class="content">
            <div class="title text-center">
                <h6>INTERNSHIP WAIVER</h6>
            </div>
            <div class="i mt-4">
                <p class="indent">I, <label class="long"><?php echo $row['firstname'].' '.$row['middlename'][0].'. '.$row['lastname'] ?></label> of legal age, single/married, and residing at 
                <label class="long"><?php echo $row['address'] ?></label> through the request of the Bulacan Polytechnic College and 
                <label class="long"><?php echo $row['companyname'] ?></label> in consideration thereof, hereby freely and voluntarily assume and 
                    impose upon myself the following duties:</p>
                
                <p class="indent">That I recognize the authority of the <label class="long"><?php echo $row['companyname'] ?></label> under whom I am placed and 
                submit myself to rules and regulations that may be imposed in connection with my training;</p>

                <p class="indent">That I assume full responsibility to all damages incurred by me arising out of and in course of my training during off hours;</p>

                <p class="indent">Furthermore, I renounce and waive all claims against the Bulacan Polytechnic College and <label for="" class="long"><?php echo $row['companyname'] ?></label> for any injury that may sustain or any loss that I may suffer, personal or pecuniary, in the performance of my duties or functions.</p>
                <p class="indent">Signed at City of Malolos this <label class="small"></label> day of <label  class="medium"></label> 2023.</p>
                <p class="text-end mt-4">
                    <label class="long"></label>
                    <br>
                    <label class="mr-80">Signature</label>
                </p>

                <p>WITNESS:</p>

                <div class="witness">
                    <div class="flex1 text-center">
                        <p class="text-center mt-4">
                            <label class="long"><?php echo $row['witness1'] ?></label>
                            <br>
                            <label>Signature over printed name</label>
                        </p>
                    </div>
                    <div class="flex1 text-center">
                        <p class="text-center mt-4">
                            <label class="long"><?php echo $row['witness2'] ?></label>
                            <br>
                            <label>Signature over printed name</label>
                        </p>
                    </div>
                </div>
                <p class="text-center bold">C O N F I R M A T I O N</p>
                <p class="indent">That we <label for="" class="long"><?php echo $row['confirmedby'] ?></label> of legal age, Filipino and a resident of
                     <label for="" class="long"><?php echo $row['confirmeraddress'] ?></label> after being duly sworn in accordance with law hereby agree and state:</p>
                <p class="indent">That we hereby confirm the above appearing in this instrument.</p>
                <p class="text-end mt-4">
                    <label class="long"></label>
                    <br>
                    <label class="mr-20">Signature of Parents/ Guardian</label>
                </p>
                <p class="indent">Subscribed and sworn to before me this <label for="" class="small"></label> day of
                     <label for="" class="medium"></label> 2023 affiant exhibiting his/ her residence certificate no.
                     <label for="" class="long"></label> issued at <label for="" class="long"></label> 
                     on <label for="" class="long"></label>.</p>

                <p class="text-end mt-4">
                    <label class="long"></label>
                    <br>
                    <label class="mr-50">(Administering Officer)</label>
                </p>
            </div>
        </div>
        <div class="malolos">
            <label class="bold">Brgy, Bulihan, City of Malolos</label>
        </div>
    </div>
    <?php
        }
        
    ?>

    <script>window.print();</script>
</body>
</html>