<div class="page-title">
    <h4 class="text-secondary uppercase">Archive Records</h4>
</div>
<div class="archive">
    <table class="table table-hover table-sm">
        <thead class="text-secondary">
            <tr>
            <th scope="col">Full Name</th>
            <th scope="col">Type</th>
            <th scope="col">Email</th>
            <th scope="col">address</th>
            <th scope="col"></th>
            </tr>
        </thead>
        <?php 
            $archive = "SELECT * FROM archive";
            $result = mysqli_query($conn, $archive);
            while($rows = mysqli_fetch_array($result)){
                $data = json_decode($rows['data']);
                if($data){ ?>
                     <tbody>
                        <tr>
                        <td class="uppercase"><?php echo $data->firstname .' '. $data->middlename[0] .' '. $data->lastname ?></td>
                        <td><?php echo $data->type ?></td>
                        <td><?php echo $data->email ?></td>
                        <td><?php echo $data->address ?></td>
                        <td><a class="btn btn-success" href="../php/restore.php?data=<?php echo $rows['id'] ?>">Restore</a></td>
                        <td></td>
                        </tr>
                    </tbody>
            <?php
                }
            }
        ?>
    </table>
</div>
