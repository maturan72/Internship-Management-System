<div id="request-info" class="container-fluid">
    <h4 class="uppercase text-secondary"> <i class="fa fa-user" aria-hidden="true"></i> Intern Information / Records</h4>
    <div class="row mt-4">
        <div class="col-md-4 info">
            <?php 
                $id = $_GET['id'];
                $select = "SELECT * FROM interns WHERE id = '$id' ";
                $result = mysqli_query($conn, $select);
                while($rows = mysqli_fetch_array($result)){?>
                    <div class="background-avatar avatar text-center">
                        <img src="../assets/avatar/<?php echo $rows['id'].$rows['firstname'].'.jpg' ?>" alt="">
                    </div>
                    <div class="name mt-4">
                        <h3 class="text-success"><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname']?></h3>
                        <small>Intern Name</small>
                    </div>
                    <hr>
                    <div class="d-flex">
                        <div class="age w-50">
                            <h6><?php echo $rows['age']?></h6>
                            <small>Age</small>
                        </div> 
                        <hr>
                        <div class="gender w-50">
                            <h6><?php echo $rows['gender']?></h6>
                            <small>Gender</small>
                        </div> 
                    </div>
                    <hr>
                    <div class="email">
                        <h6><?php echo $rows['email']?></h6>
                        <small>Email Address</small>
                    </div>  
                    <hr>
                    <div class="address">
                        <h6><?php echo $rows['address']?></h6>
                        <small>Address</small>
                    </div>  
                <?php
                    }
            ?>
            <div class="datadocuments mt-4">
                    <?php
                        $id = $_GET['id'];
                        $select = mysqli_query($conn, "SELECT * FROM interns WHERE id ='$id' ");
                
                        $data = mysqli_fetch_array($select);
                        $name = $data['firstname'];
                
                        if ($handle = opendir('../assets/documents/'.$id.$name.'/')) {
                            $path = $id.$name.'/';
                            while (false !== ($entry = readdir($handle))) {
                        
                                if ($entry != "." && $entry != "..") {?>
                                <a href="../assets/documents/<?php echo $path.$entry ?>"><?php echo $entry?></a>
                                <br>
                            <?php    
                                }
                            }
                        
                            closedir($handle);
                        }
                    ?>
                <small class="text-secondary">Student Documents</small>
            </div> 
            <hr>
        </div>
        <div class="col-md-8">
            
                <?php 
                    $id = $_GET['id'];
                    $select = "SELECT s.hours, c.companyname
                                FROM interns s INNER JOIN company c
                                ON s.company = c.id ";
                    $result = mysqli_query($conn, $select);
                    if($rows = mysqli_fetch_array($result)){?>
                        <div class="d-flex info">
                            <div class="age w-50">
                                <h6><?php echo $rows['companyname']?></h6>
                                <small>Company</small>
                            </div> 
                            <hr>
                            <div class="gender w-50">
                                <h6>Hour: <?php echo $rows['hours']?></h6>
                                <small>Hours Completed</small>
                            </div> 
                        </div>
                        <hr>
                    <?php
                        }
                ?>
            <div class="page-title mt-4">
                <h4 class="text-secondary uppercase">Student Task Reports / Documents</h4>
            </div>
            <div class="row mt-4">
                <div class="col-md-12">
                    <div class="page-title">
                        <div class="task-list d-flex">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <a class="" id="list-tab" data-bs-toggle="tab" data-bs-target="#list" type="button" role="tab" aria-controls="list" aria-selected="true">Task Reports</a>
                                <a class="" id="task-tab" data-bs-toggle="tab" data-bs-target="#task" type="button" role="tab" aria-controls="task" aria-selected="false">Log Records</a>
                                <a class="" id="form-tab" data-bs-toggle="tab" data-bs-target="#forms" type="button" role="tab" aria-controls="form" aria-selected="false">Student Forms</a>
                            </ul>
                        </div>
                    </div>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade" id="task" role="tabpanel" >
                            <div class="row task-table">
                                <div class="col-md-12 h-5 overflow border">
                                    <table class="table table-hover table-sm">
                                        <thead class="text-dark">
                                            <tr>
                                            <th scope="col">Date</th>
                                            <th scope="col">In</th>
                                            <th scope="col">Out</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php 
                                                $id = $_GET['id'];
                                                $select = "SELECT * FROM time_in WHERE intern_id = '$id' ";
                                                $result = mysqli_query($conn, $select);
                                                while($rows = mysqli_fetch_array($result)){?>
                                                    <tr>
                                                    <td><?php echo $rows['date'] ?></td>
                                                    <td><?php echo $rows['timein'] ?></td>
                                                    <td><?php echo $rows['timeout'] ?></td>
                                                    </tr>
                                            <?php
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade show" id="list" role="tabpanel">
                            <div class="row comp-interns">
                                <div class="col-md-12 h-5 overflow border">
                                <table class="table table-hover table-sm">
                                    <thead class="text-dark">
                                        <tr>
                                        <th scope="col">Task Name</th>
                                        <th scope="col">progress</th>
                                        <th scope="col">Due Date</th>
                                        <th scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <?php 
                                            $id = $_GET['id'];
                                            $select = "SELECT * FROM task WHERE intern_id = '$id' ";
                                            $result = mysqli_query($conn, $select);
                                            while($rows = mysqli_fetch_array($result)){?>
                                            <tbody>
                                                <tr>
                                                <td><?php echo $rows['task_description'] ?></td>
                                                <td><?php echo $rows['progress'] ?></td>
                                                <td><?php echo $rows['due_date'] ?></td>
                                                <td><?php echo $rows['status'] ?></td>
                                                </tr>
                                            </tbody>
                                        <?php
                                            }
                                        ?>
                                </table>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="forms" role="tabpanel" >
                            <div class="row mt-4">
                                <?php
                                    $id = $_GET['id'];
                                    $select_intern = mysqli_query($conn, "SELECT * FROM interns WHERE id ='$id' ");
                                    $row = mysqli_fetch_array($select_intern);
                                    $student_id = $row['student_id'];

                                    $find_application = mysqli_query($conn, "SELECT * FROM `application` WHERE studentid = '$student_id' ");
                                    $find_waiver = mysqli_query($conn, "SELECT * FROM `waiver` WHERE studentid = '$student_id' ");
                                    $find_evaluation = mysqli_query($conn, "SELECT * FROM `evaluation` WHERE studentid = '$student_id' ");
                                    $find_information = mysqli_query($conn, "SELECT * FROM `information` WHERE studentid = '$student_id' ");

                                    if(mysqli_num_rows($find_application) >= 1){?>
                                        <div class="d-flex flex-column">
                                            <div class="form_name row">
                                                <div class="col-md-5">
                                                    <h4>Student Application Form </h4>
                                                </div>
                                                <div class="col-md-7">
                                                    <div class="text-start">
                                                        <a target='_blank' href="student-application-form.php?studentid=<?php echo $student_id; ?>" class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Print / Save Application</a>
                                                        <!-- <a href="student-application-form.php?studentid=<?php echo $student_id; ?>" class="btn btn-success"><i class="fa fa-download"></i> Download Application</a>
                                                        <a href="?inc=application-form&studentid=<?php echo $student_id; ?>&ACTION=UPLOAD" class="btn btn-warning"><i class="fa fa-upload"></i> Update Application</a> -->
                                                    </div>
                                                </div>
                                            <small class="text-secondary">Application Form</small>
                                            </div>
                                            <hr class="text-secondary">
                                            
                                        </div>
                                <?php
                                    }
                                    if(mysqli_num_rows($find_waiver) >= 1){?>
                                        <div class="d-flex flex-column">
                                            <div class="form_name row">
                                                <div class="col-md-5">
                                                    <h4>Student Waiver Form </h4>
                                                </div>
                                                <div class="col-md-7">
                                                    <div class="text-start">
                                                        <a target='_blank' href="student-waiver.php?studentid=<?php echo $student_id; ?>" class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Print / Save Waiver</a>
                                                        <!-- <a href="?inc=waiver&studentid<?php echo $student_id; ?>&ACTION=DOWNLOAD" class="btn btn-success"><i class="fa fa-download"></i> Download Waiver</a>
                                                        <a href="?inc=waiver&studentid<?php echo $student_id; ?>&ACTION=UPLOAD" class="btn btn-warning"><i class="fa fa-upload"></i> Update Waiver</a> -->
                                                    </div>
                                                </div>
                                            <small class="text-secondary">Waiver Form</small>
                                            </div>
                                            <hr class="text-secondary">
                                            
                                        </div>
                                <?php
                                    }
                                    if(mysqli_num_rows($find_evaluation) >= 1){?>
                                        <div class="d-flex flex-column">
                                            <div class="form_name row">
                                                <div class="col-md-5">
                                                    <h4>Student Evaluation Form </h4>
                                                </div>
                                                <div class="col-md-7">
                                                    <div class="text-start">
                                                        <a target='_blank' href="student-evaluation.php?studentid=<?php echo $student_id; ?>" class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Print / Save Evaluation</a>
                                                        <!-- <a href="?inc=evaluation&studentid<?php echo $student_id; ?>&ACTION=DOWNLOAD" class="btn btn-success"><i class="fa fa-download"></i> Download Evaluation</a>
                                                        <a href="?inc=evaluation&studentid<?php echo $student_id; ?>&ACTION=UPLOAD" class="btn btn-warning"><i class="fa fa-upload"></i> Update Evaluation</a> -->
                                                    </div>
                                                </div>
                                            <small class="text-secondary">Evaluation Form</small>
                                            </div>
                                            <hr class="text-secondary">
                                            
                                        </div>
                                <?php
                                    }
                                    if(mysqli_num_rows($find_information) >= 1){?>
                                        <div class="d-flex flex-column">
                                            <div class="form_name row">
                                                <div class="col-md-5">
                                                    <h4>Student Information Form </h4>
                                                </div>
                                                <div class="col-md-7">
                                                    <div class="text-start">
                                                        <a target='_blank' href="student-information-sheet.php?studentid=<?php echo $student_id; ?>" class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Print / Save Information</a>
                                                        <!-- <a href="?inc=information&studentid<?php echo $student_id; ?>&ACTION=DOWNLOAD" class="btn btn-success"><i class="fa fa-download"></i> Download Information</a>
                                                        <a href="?inc=information&studentid<?php echo $student_id; ?>&ACTION=UPLOAD" class="btn btn-warning"><i class="fa fa-upload"></i> Update Information</a> -->
                                                    </div>
                                                </div>
                                            <small class="text-secondary">Information Form</small>
                                            </div>
                                            <hr class="text-secondary">
                                            
                                        </div>
                                <?php
                                    }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
