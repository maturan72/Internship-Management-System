<div class="page-title">
    <h1>Welcome, <span class="f-bold">Admin</span></h1>
</div>
<div class="admin-info">
    <div class="admin-update">
        <div class="box-header">
            <h4 class="text-primary f-bold">Add New Admin</h4>
        </div>
       
        <form action="../php/admin_add.php" method="post">
                <div class="box-content">
                    
                    <div class="row mt-4">
                        <div class="col-md-5">
                            <label for=""><strong>First Name:</strong></label>
                            <input class="form-control" type="text" name="fname" value="" required>
                        </div>
                        <div class="col-md-2">
                            <label for=""><strong>Middle Name:</strong></label>
                            <input class="form-control" type="text" name="mname" value="" required>
                        </div>
                        <div class="col-md-5">
                            <label for=""><strong>Last Name:</strong></label>
                            <input class="form-control" type="text" name="lname" value="" required>
                        </div>
                    </div>
                    <div class="email row mt-4">
                        <div class="col-md-4">
                            <label for=""><strong>Email Address:</strong></label>
                            <input onkeyup='validateForm();' id="email" class="form-control" type="text" name="email" value="" required>
                            <small id='email_message'></small>
                        </div>
                        <div class="col-md-4">
                            <label for=""><strong>Password:</strong></label>
                            <input class="form-control" type="password" name="password" value="" required>
                        </div>
                        <div class="col-md-4">
                            <label for=""><strong>Confrim Password:</strong></label>
                            <input class="form-control" type="password" name="confirm" value="" required>
                        </div>
                    </div>
                    <div class="button row mt-4 text-end">
                        <div class="col-md-12">
                            <label class="text-end">
                                <?php
                                    if($_SESSION['pass_err']){?>
                                    <div class="text-danger">
                                        Password Don't Match!
                                    </div>
                                    
                                <?php
                                    unset($_SESSION['pass_err']);
                                    }elseif($_SESSION['upd_succ']){?>
                                    <div class="text-success">
                                       Updated Successfully!
                                    </div>
                                <?php
                                    unset($_SESSION['upd_succ']);
                                    }
                                ?>
                            </label>
                            <input class="btn btn-info" type="submit" name="add_new" value="Add New Admin">
                        </div>
                    </div>
                </div>
        </form>
    </div>
</div>