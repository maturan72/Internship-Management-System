<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-list" aria-hidden="true"></i> My Weekly Reports</h4>
</div>

<div class="row ">
    <div class="col-md-12">
        <div class="upload-task text-end">
            <input class="w-50 form-control input-search" type="text" id="myInput" placeholder="Search for Records..">
            <a href="student-print.php?page=<?php echo $_GET['page']?>" target="_blank" class="btn btn-info">Print Reports</a>
        </div>
        <hr>
        

        <table class="table table-hover table-sm">
            <thead class="text-secondary">
                <tr>
                <th scope="col">Task Name</th>
                <th scope="col">Description</th>
                <th scope="col">Due Date</th>
                <th scope="col">Date Submitted</th>
                <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody id="myTable">
            <?php 
                $limit = 7;  
                if (isset($_GET["page"])) {
                    $page  = $_GET["page"]; 
                    } 
                    else{ 
                    $page=1;
                    };  
                $start_from = ($page-1) * $limit;  
                    
                $id = $_SESSION['log'];
                $select = "SELECT * FROM task WHERE intern_id = '$id' ORDER BY id DESC LIMIT $start_from, $limit ";
                $result = mysqli_query($conn, $select);
                while($rows = mysqli_fetch_array($result)){?>
                    
                <tr>
                <td><?php echo $rows['task_title'] ?></td>
                <td><?php echo $rows['description'] ?></td>
                <td><?php echo $rows['due_date'] ?></td>
                <td><?php echo $rows['date_submitted'] ?></td>
                <td><?php echo $rows['status'] ?></td>
                </tr>
                    
                <?php
                    }
                ?>
            </tbody>
        </table>
        <?php 
        $result_db = mysqli_query($conn,"SELECT COUNT(id) FROM task"); 
        $row_db = mysqli_fetch_row($result_db);  
        $total_records = $row_db[0];  
        $total_pages = ceil($total_records / $limit); 
        
        $pagLink = "<ul class='pagination'>";  
        for ($i=1; $i<=$total_pages; $i++) {
                    $pagLink .= "<li class='page-item'><a class='page-link' href='student.php?inc=weekly&page=".$i."'>".$i."</a></li>";	
        }
        echo  $pagLink . "</ul>"; 
        echo "<small class='text-secondary'>Paginate by Week</small>"; 
        ?>
    </div>
</div>