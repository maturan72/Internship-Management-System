<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-list" aria-hidden="true"></i>Create Forms (Documents)</h4>
    <div class="task-list d-flex">
        <?php
            $id = $_SESSION['log'];
            $select = mysqli_query($conn,"SELECT * FROM interns WHERE id = '$id' AND company != '' ");
            if(mysqli_num_rows($select) > 0){?>
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <a href="" id="list-tab" data-bs-toggle="tab" data-bs-target="#application" type="button" role="tab" aria-controls="application" aria-selected="true">Application Form</a>
                    <a href="" id="list-tab" data-bs-toggle="tab" data-bs-target="#waiver" type="button" role="tab" aria-controls="waiver" aria-selected="true">Internship Waiver</a>
                    <a href="" id="list-tab" data-bs-toggle="tab" data-bs-target="#information" type="button" role="tab" aria-controls="information" aria-selected="true">Information Sheet</a>
                    <a href="" id="list-tab" data-bs-toggle="tab" data-bs-target="#evaluation" type="button" role="tab" aria-controls="evaluation" aria-selected="true">Evaluation Report</a>
                </ul>
        <?php
            }else{?>
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <a href="" id="list-tab" data-bs-toggle="tab" data-bs-target="#application" type="button" role="tab" aria-controls="application" aria-selected="true">Application Form</a>
                </ul>
        <?php
            }
        ?>
        
    </div>
   
    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show" id="application" role="tabpanel">
            <div class="row">
                <h4 class="uppercase text-secondary">Student Application</h4>
                <form id="regForm" action="../php/create-form.php" method="POST" class="mt-4">
                    <div class="mt-4 row">
                        <?php
                            $id = $_SESSION['log'];
                            $select = mysqli_query($conn,"SELECT * FROM interns WHERE id = '$id'");
                            while($rows = mysqli_fetch_array($select)){
                                $comp_id = $rows['company'];?>
                                <div class="col-md-6">
                                    <h4 class="text-secondary">Student Details</h4>
                                    <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $rows['firstname'].' '.$rows['middlename'][0].'. '.$rows['lastname'] ?>">
                                    <hr class="text-secondary m-0">
                                    <small class="text-secondary ml-2"> Full Name</small>
                                    
                                    <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $rows['address'] ?>">
                                    <hr class="text-secondary m-0">
                                    <small class="text-secondary ml-2">Student Address</small>

                                    <input class="form-control border-0 mt-4" readonly type="text" value="ON THE JOB TRAINING">
                                    <hr class="text-secondary m-0">
                                    <small class="text-secondary ml-2">Nature Of Training</small>

                                    <input class="form-control border-0 mt-4" name="hours" type="number" value="" required>
                                    <hr class="text-secondary m-0">
                                    <small class="text-secondary ml-2">Number of Hours Daily</small>
                                </div>
                                
                                <?php
                                    if($comp_id == ''){?>
                                        <div class="col-md-6">
                                            <h4 class="text-secondary">Company Details</h4>
                                            <h4 class='text-secondary mt-4'>Not yet! in a Company</h4>
                                        </div>
                                    <?php    
                                    }else{
                                        $select_data = mysqli_query($conn,"SELECT * FROM company WHERE id = '$comp_id'");
                                            while($comp_data = mysqli_fetch_array($select_data)){?>
                                                <div class="col-md-6">
                                                    <h4 class="text-secondary">Establishment Details</h4>
                                                    <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $comp_data['companyname']?>">
                                                    <hr class="text-secondary m-0">
                                                    <small class="text-secondary ml-2">Establishment Name</small>
                                                    
                                                    <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $comp_data['address'] ?>">
                                                    <hr class="text-secondary m-0">
                                                    <small class="text-secondary ml-2">Establishment Address</small>
                                                </div>
                                                
                                        <?php
                                        }
                                    }
                                ?>
                                <div class="text-end">
                                    <input type="hidden" name="studentid" value="<?php echo $rows['student_id']?>">
                                    <input class="btn btn-success" type="submit" name="create-application" value="Create Application Form">
                                </div>
                            <?php
                            }
                        ?>
                    </div>
                </form>
            </div>
        </div>
        <div class="tab-pane fade show" id="waiver" role="tabpanel">
            <form id="regForm" action="../php/create-form.php" method="POST">
                <h4 class="uppercase text-secondary">Student Waiver</h4>
                <div class="row mt-4">
                    <?php
                        $id = $_SESSION['log'];
                        $select = mysqli_query($conn,"SELECT * FROM interns WHERE id = '$id'");
                        while($rows = mysqli_fetch_array($select)){
                            $comp_id = $rows['company'];?>
                            <div class="col-md-6">
                                <h4 class="text-secondary">Student Details</h4>
                                <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $rows['firstname'].' '.$rows['middlename'][0].'. '.$rows['lastname'] ?>">
                                <hr class="text-secondary m-0">
                                <small class="text-secondary ml-2"> Full Name</small>
                                
                                <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $rows['address'] ?>">
                                <hr class="text-secondary m-0">
                                <small class="text-secondary ml-2">Student Address</small>

                            </div>
                            
                            <?php
                                
                            $select_data = mysqli_query($conn,"SELECT * FROM company WHERE id = '$comp_id'");
                            while($comp_data = mysqli_fetch_array($select_data)){?>
                            <div class="col-md-6">
                                <h4 class="text-secondary">Establishment Details</h4>
                                <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $comp_data['companyname']?>">
                                <hr class="text-secondary m-0">
                                <small class="text-secondary ml-2">Establishment Name</small>

                                <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $comp_data['address']?>">
                                <hr class="text-secondary m-0">
                                <small class="text-secondary ml-2">Establishment Address</small>
                            </div>
                            <input type="hidden" name="studentid" value="<?php echo $rows['student_id']?>">
                            <input type="hidden" name="comp_id" value="<?php echo $rows['company']?>">
                            <?php
                            }
                            ?>
                            
                        <?php
                        }
                    ?>
                </div>
                <div class="row mt-4">
                    <h4 class="text-secondary">Witness</h4>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="w1" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Witness Name</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="w2" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Witness Name</small>
                    </div>
                </div>
                <div class="row mt-4">
                    <h4 class="text-secondary">Confirmation</h4>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="confirmname" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Confirmed By (name)</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="confirmaddress" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Confirmer (address)</small>
                    </div>
                    
                </div>
                <div class="text-end">
                    <input class="btn btn-success" type="submit" name="create-waiver" value="Create Waiver Form">
                </div>
            </form>
        </div>
        <div class="tab-pane fade show" id="information" role="tabpanel">
        <h4 class="uppercase text-secondary">Student Information</h4>
            <form id="regForm" action="../php/create-form.php" method="POST" class="mt-4">
                <div class="row mt-4">
                    <?php
                        $id = $_SESSION['log'];
                        $select = mysqli_query($conn,"SELECT * FROM interns WHERE id = '$id'");
                        while($rows = mysqli_fetch_array($select)){
                            $comp_id = $rows['company'];?>
                            <div class="col-md-6">
                                <h4 class="text-secondary">Student Details</h4>
                                <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $rows['firstname'].' '.$rows['middlename'][0].'. '.$rows['lastname'] ?>">
                                <hr class="text-secondary m-0">
                                <small class="text-secondary ml-2"> Full Name</small>
                                
                                <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $rows['address'] ?>">
                                <hr class="text-secondary m-0">
                                <small class="text-secondary ml-2">Student Address</small>

                            </div>
                            
                            <?php
                                
                            $select_data = mysqli_query($conn,"SELECT * FROM company WHERE id = '$comp_id'");
                            while($comp_data = mysqli_fetch_array($select_data)){?>
                            <div class="col-md-6">
                                <h4 class="text-secondary">Establishment Details</h4>
                                <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $comp_data['companyname']?>">
                                <hr class="text-secondary m-0">
                                <small class="text-secondary ml-2">Establishment Name</small>

                                <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $comp_data['address']?>">
                                <hr class="text-secondary m-0">
                                <small class="text-secondary ml-2">Establishment Address</small>
                            </div>
                            <input type="hidden" name="studentid" value="<?php echo $rows['student_id']?>">
                            <input type="hidden" name="comp_id" value="<?php echo $rows['company']?>">
                            <?php
                            }
                            ?>
                            
                        <?php
                        }
                    ?>
                </div>
                <div class="row mt-4">
                    <h4 class="text-secondary">Civil Status</h4>
                    <div class="col-md-6">
                        <select name="status" id="" class="form-control">
                            <option value="Single">Single</option>
                            <option value="Married">Married</option>
                        </select>
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Status</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="nationality" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Nationality</small>
                    </div>
                </div>
                <div class="row mt-4">
                    <h4 class="text-secondary">Student Birth Date and Place</h4>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="bod" type="date" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Student Birth Date</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="bop" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Student Birth place</small>
                    </div>
                </div>
                <div class="row mt-4">
                    <h4 class="text-secondary">Student Height and Weight</h4>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="height" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Student Height</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="weight" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Student Weight  (in lbs)</small>
                    </div>
                </div>
                <div class="row mt-4">
                    <h4 class="text-secondary">Father Information</h4>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="father" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Father Name</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="f-occupation" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Father Occupation</small>
                    </div>
                </div>
                <div class="row mt-4">
                    <h4 class="text-secondary">Mother Information</h4>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="mother" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Mother Name</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="m-occupation" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Mother Occupation</small>
                    </div>
                </div>
                <div class="row mt-4">
                    <h4 class="text-secondary">Parents Contact Info</h4>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="p-address" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Parents Address</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="p-tel" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Parents Tel No.</small>
                    </div>
                </div>
                <div class="row mt-4">
                    <h4 class="text-secondary">School Data</h4>
                    <div class="col-md-6">
                        <input class="form-control border-0 uppercase" name="nos" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Name of School</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="s-address" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">School Address</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0 uppercase" name="coordinator" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Industry / Training Coordinator</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0 uppercase" name="vpaa" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">VPAA / OIC-OCP</small>
                    </div>
                </div>
                <div class="row mt-4">
                    <h4 class="text-secondary">In Case of Emergency Notify</h4>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="e-name" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Full Name</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="e-address" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Address</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="e-relation" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Relationship</small>
                    </div>
                    <div class="col-md-6">
                        <input class="form-control border-0" name="e-tel" type="text" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Tel No.</small>
                    </div>
                </div>
                <div class="text-end">
                    <input class="btn btn-success" type="submit" name="create-information" value="Create Information Form">
                </div>
            </form>
        </div>
        <div class="tab-pane fade show" id="evaluation" role="tabpanel">
            <h4 class="uppercase text-secondary">Student Evaluation</h4>
            <form id="regForm" action="../php/create-form.php" method="POST" class="mt-4">
                <div class="row mt-4">
                    <?php
                        $id = $_SESSION['log'];
                        $select = mysqli_query($conn,"SELECT * FROM interns WHERE id = '$id'");
                        while($rows = mysqli_fetch_array($select)){
                            $comp_id = $rows['company'];?>
                            <div class="col-md-6">
                                <h4 class="text-secondary">Student Details</h4>
                                <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $rows['firstname'].' '.$rows['middlename'][0].'. '.$rows['lastname'] ?>">
                                <hr class="text-secondary m-0">
                                <small class="text-secondary ml-2"> Full Name</small>
                                
                                <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $rows['address'] ?>">
                                <hr class="text-secondary m-0">
                                <small class="text-secondary ml-2">Student Address</small>

                            </div>
                            
                            <?php
                                
                            $select_data = mysqli_query($conn,"SELECT * FROM company WHERE id = '$comp_id'");
                            while($comp_data = mysqli_fetch_array($select_data)){?>
                            <div class="col-md-6">
                                <h4 class="text-secondary">Establishment Details</h4>
                                <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $comp_data['companyname']?>">
                                <hr class="text-secondary m-0">
                                <small class="text-secondary ml-2">Establishment Name</small>

                                <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $comp_data['address']?>">
                                <hr class="text-secondary m-0">
                                <small class="text-secondary ml-2">Establishment Address</small>
                            </div>
                            <input type="hidden" name="studentid" value="<?php echo $rows['student_id']?>">
                            <input type="hidden" name="comp_id" value="<?php echo $rows['company']?>">
                            <?php
                            }
                            ?>
                            
                        <?php
                        }
                    ?>
                </div>
                <div class="row mt-4">
                    <h4 class="text-secondary">Number of Hours Required</h4>
                    <div class="col-md-4">
                        <input class="form-control border-0" name="hours" type="number" required value="">
                        <hr class="text-secondary m-0">
                        <small class="text-secondary">Hours</small>
                    </div>
                </div>
                <div class="text-end">
                    <input class="btn btn-success" type="submit" name="create-evaluation" value="Create Evaluation Form">
                </div>
            </form>
        </div>
    </div>

</div>