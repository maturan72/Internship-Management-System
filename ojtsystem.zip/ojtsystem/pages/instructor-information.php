<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-user" aria-hidden="true"></i> My Information</h4>
  <hr>
</div>
<?php
    $id = $_SESSION['log'];
    $instructor_data = "SELECT * FROM instructor WHERE id = '$id'";
    $ins_result = mysqli_query($conn, $instructor_data);
    while($data = mysqli_fetch_array($ins_result)){
        ?>
<div class="row information">
    <div class="col-md-4 background-avatar text-center">
        <img src="../assets/avatar/<?php echo $data['id'].$data['firstname'].'.jpg' ?>" alt="">
    </div>
   <div class="col-md-8">
       <div class="">
            <div class="Instructor info">
                <h1 class="m-0"><?php echo $data['firstname'].' '.$data['middlename'][0].' '.$data['lastname']?></h1>
                <small class="text-secondary">Instructor</small>
            </div>  
                <hr> 
            <div class="row">
                <div class="col-md-6">
                    <div class="email">
                        <h5 class="m-0"><?php echo $data['email']?></h5>
                        <small class="text-secondary">Email Address</small>
                    </div> 
                </div>
                <div class="col-md-6">
                    <div class="address">
                        <h5 class="m-0"><?php echo $data['contact']?></h5>
                        <small class="text-secondary">Contact Number</small>
                    </div> 
                </div>
                <hr>
                <div class="col-md-12">
                    <div class="address">
                        <h5 class="m-0"><?php echo $data['address']?></h5>
                        <small class="text-secondary">Instructor Address</small>
                    </div> 
                </div>
                <hr>
            </div> 
            <div class="update text-end mt-4">
                <a href="?inc=info-update" class="btn btn-info">Update Information</a>
            </div>
        </div>
   </div>
</div>
<?php
    }
?>