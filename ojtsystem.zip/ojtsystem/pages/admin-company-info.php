<div id="request-info" class="container-fluid">
    <h2 class="text-secondary uppercase"><i class="fa fa-building" aria-hidden="true"></i> Company information / Records</h2>
    <div class="row info mt-4">
        <?php 
        $id = $_GET['id'];
        $select = "SELECT * FROM company WHERE id = '$id' ";
        $result = mysqli_query($conn, $select);
        while($rows = mysqli_fetch_array($result)){?>
            <div class="col-md-3">
                <div class="background-avatar avatar text-center">
                    <img src="../assets/avatar/<?php echo $rows['id'].$rows['firstname'].'.jpg' ?>" alt="">
                </div>
            </div>
            <div class="col-md-8">
                <div class="name mt-4">
                    <h3 class="text-success"><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname']?></h3>
                    <small>Supervisor Name</small>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <div class="email">
                            <h6><?php echo $rows['email']?></h6>
                            <small>Email Address</small>
                        </div>  
                    </div>
                    <div class="col-md-6">
                        <div class="contact">
                            <h6><?php echo $rows['contact']?></h6>
                            <small>Contact Number</small>
                        </div> 
                    </div>
                </div>
                
                <hr>
                <div class="row">
                    <div class="col-md-6">
                        <div class="company">
                            <h6><?php echo $rows['companyname']?></h6>
                            <small>Company Name</small>
                        </div>  
                        
                    </div>
                    <div class="col-md-6">
                        <div class="company">
                            <h6><?php echo $rows['address']?></h6>
                            <small>Company Address</small>
                        </div> 
                    </div>
                </div>
                <hr>
            </div>
        <?php
            }
        ?>
    </div>
    <div class="row mt-4">
        <div class="col-md-12">
            <div class="page-title">
                <div class="task-list d-flex">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <a class="" id="list-tab" data-bs-toggle="tab" data-bs-target="#list" type="button" role="tab" aria-controls="list" aria-selected="true">List Of Interns</a>
                        <a class="" id="task-tab" data-bs-toggle="tab" data-bs-target="#task" type="button" role="tab" aria-controls="task" aria-selected="false">Task Reports</a>
                    </ul>
                </div>
            </div>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade" id="task" role="tabpanel" >
                    <div class="row task-table">
                        <div class="col-md-12 h-5 overflow border">
                            <table class="table table-hover table-sm">
                                <thead class="text-dark">
                                    <tr>
                                    <th scope="col">Task Name</th>
                                    <th scope="col">progress</th>
                                    <th scope="col">Due Date</th>
                                    <th scope="col">Status</th>
                                    </tr>
                                </thead>
                                <?php 
                                        $id = $_GET['id'];
                                        $select = "SELECT * FROM task WHERE comp_id = '$id' ";
                                        $result = mysqli_query($conn, $select);
                                        while($rows = mysqli_fetch_array($result)){?>
                                        <tbody>
                                            <tr>
                                            <td><?php echo $rows['task_description'] ?></td>
                                            <td><?php echo $rows['progress'] ?></td>
                                            <td><?php echo $rows['due_date'] ?></td>
                                            <td><?php echo $rows['status'] ?></td>
                                            </tr>
                                        </tbody>
                                    <?php
                                        }
                                    ?>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade show active" id="list" role="tabpanel">
                    <div class="row comp-interns">
                        <div class="col-md-12 h-5 overflow border">
                            <table class="table table-hover table-sm">
                                <thead class="text-dark">
                                    <tr>
                                    <th scope="col">Full Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">address</th>
                                    </tr>
                                </thead>
                                <?php 
                                    $id = $_GET['id'];
                                    $select = "SELECT * FROM interns WHERE company = '$id' ";
                                    $result = mysqli_query($conn, $select);
                                    while($rows = mysqli_fetch_array($result)){?>
                                    <tbody>
                                        <tr>
                                        <td class="uppercase"><?php echo $rows['firstname'] .' '. $rows['middlename'][0] .' '. $rows['lastname'] ?></td>
                                        <td><?php echo $rows['email'] ?></td>
                                        <td><?php echo $rows['address'] ?></td>
                                        </tr>
                                    </tbody>
                                <?php
                                    }
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



