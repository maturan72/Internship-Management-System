<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-list" aria-hidden="true"></i>Create Forms (Documents)</h4>
    <div class="task-list d-flex">
            <a href="?inc=forms">Application Form</a>
            <a class="active" href="?inc=forms-waiver">Internship Waiver</a>
            <a href="?inc=forms-informatioj">Information Sheet</a>
            <a href="?inc=forms-evaluation">Evaluation Report</a>
    </div>
    <div class="row">
        <form id="regForm" action="../php/create-form.php" method="POST" class="mt-4">
            <div class="row mt-4">
                <h4 class="uppercase text-secondary">Student Waiver</h4>
                <?php
                    $id = $_SESSION['log'];
                    $select = mysqli_query($conn, "SELECT * FROM interns s
                    INNER JOIN `waiver` w ON s.student_id = w.studentid WHERE s.id = '$id' ");
                    while($rows = mysqli_fetch_array($select)){
                        $comp_id = $rows['company'];?>
                        <div class="col-md-6">
                            <h4 class="text-secondary">Student Details</h4>
                            <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $rows['firstname'].' '.$rows['middlename'][0].'. '.$rows['lastname'] ?>">
                            <hr class="text-secondary m-0">
                            <small class="text-secondary ml-2"> Full Name</small>
                            
                            <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $rows['address'] ?>">
                            <hr class="text-secondary m-0">
                            <small class="text-secondary ml-2">Student Address</small>

                        </div>
                        
                        <?php
                            
                        $select_data = mysqli_query($conn,"SELECT * FROM company WHERE id = '$comp_id'");
                        while($comp_data = mysqli_fetch_array($select_data)){?>
                        <div class="col-md-6">
                            <h4 class="text-secondary">Establishment Details</h4>
                            <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $comp_data['companyname']?>">
                            <hr class="text-secondary m-0">
                            <small class="text-secondary ml-2">Establishment Name</small>

                            <input class="form-control border-0 mt-4" type="text" readonly value="<?php echo $comp_data['address']?>">
                            <hr class="text-secondary m-0">
                            <small class="text-secondary ml-2">Establishment Address</small>
                        </div>
                        <input type="hidden" name="studentid" value="<?php echo $rows['student_id']?>">
                        <input type="hidden" name="comp_id" value="<?php echo $rows['company']?>">
                        <?php
                        }
                        ?>
                        
                    </div>
                    <div class="row mt-4">
                        <h4 class="text-secondary">Witness</h4>
                        <div class="col-md-6">
                            <input class="form-control border-0" name="w1" type="text" required value="<?php echo $rows['witness1']?>">
                            <hr class="text-secondary m-0">
                            <small class="text-secondary">Witness Name</small>
                        </div>
                        <div class="col-md-6">
                            <input class="form-control border-0" name="w2" type="text" required value="<?php echo $rows['witness2']?>">
                            <hr class="text-secondary m-0">
                            <small class="text-secondary">Witness Name</small>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <h4 class="text-secondary">Confirmation</h4>
                        <div class="col-md-6">
                            <input class="form-control border-0" name="confirmname" type="text" required value="<?php echo $rows['confirmedby']?>">
                            <hr class="text-secondary m-0">
                            <small class="text-secondary">Confirmed By (name)</small>
                        </div>
                        <div class="col-md-6">
                            <input class="form-control border-0" name="confirmaddress" type="text" required value="<?php echo $rows['confirmeraddress']?>">
                            <hr class="text-secondary m-0">
                            <small class="text-secondary">Confirmer (address)</small>
                        </div>
                        
                    </div>
                <?php
                    }
                ?>
            <div class="text-end">
                <input class="btn btn-success" type="submit" name="create-waiver" value="Save Waiver Form">
            </div>
        </form>
    </div>
</div>