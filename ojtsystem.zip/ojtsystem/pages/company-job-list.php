<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-list" aria-hidden="true"></i> My Jobs List</h4>
</div>
<div class="row">
    <div class="col-md-4">
        <div class="desc">
            <?php
                $job_id = $_GET['id'];
                $select_job = mysqli_query($conn, "SELECT * FROM jobs WHERE id ='$job_id' ");
                while($row = mysqli_fetch_array($select_job)){?>
                <div class="title text-secondary">
                    <h4 class="uppercase"><?php echo $row['job_title'] ?></h4>
                    <small>Job Title</small>
                    <hr class="margin-0">
                </div>
                <div class="desc text-secondary">
                    <p ><?php echo $row['job_desc'] ?></p>
                    <small>Job Description</small>
                    <hr class="margin-0">
                </div>
                <div class="title text-secondary">
                    <p class="uppercase"><?php echo $row['position'] ?></p>
                    <small>Job Postion</small>
                    <hr class="margin-0">
                </div>
            <?php
                }
            ?>
            
        </div>
    </div>
    <div class="col-md-8">
        <div class="text-end">
            <label class="text-secondary mr-20" for="">Search For Records</label>
            <input class="w-50 form-control input-search" type="text" id="myInput" placeholder="Search for Records..">
        </div>
        <table class="table table-hover table-sm mt-4">
            <thead class="text-secondary">
                <tr>
                <th scope="col">Full name</th>
                <th scope="col">Email</th>
                <th scope="col">Contact</th>
                <th scope="col">Address</th>
                <th></th>
                </tr>
                
            </thead>
            <tbody id="myTable"> 
            <?php
            $comp_id = $_SESSION['log'];
            $job_id = $_GET['id'];
            $select = mysqli_query($conn, "SELECT * FROM interns WHERE company = '$comp_id' AND job_id = '$job_id'");
            if(mysqli_num_rows($select) < 1){
                echo "<tr><td><h4 class='text-secondary'>Nor Records Found!!</h4></td></tr>";
            }else{
                while($rows = mysqli_fetch_array($select)){?>
                    <tr>
                    <td><?php echo $rows['firstname'] .' '. $rows['middlename'][0] .' '. $rows['lastname'] ?></td>
                    <td><?php echo $rows['email'] ?></td>
                    <td><?php echo $rows['contact'] ?></td>
                    <td><?php echo $rows['address'] ?></td>
                    <td><a class="text-decor-none" href="?inc=interns-info&id=<?php echo $rows['id'] ?>"><i class="fa fa-arrow-right text-success"><small> Show Details</small></i></a></td>
                    </tr>
                <?php
                    }
                }
            
            ?>
            </tbody>
        </table>
    </div>
</div>

