<?php 
session_start();
include "../php/db_con.php" ;
error_reporting(0);
$type = $_SESSION['type'];
if($type != "student"){
  header("location: javascript://history.go(-1)");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/pages.css">
    <style>
       
        @page{
            size: auto;
        }
        body{
            color: black !important;
        }
    </style>
</head>
<body>

<div class="container h-1vh overflow">
        <div class="text-center">
            <h2 class="uppercase text-secondary">Student Documentation</h2>
        </div>
    <div class="timeline text-white">
        <?php
            $id = $_GET['id'];
            $select_task = mysqli_query($conn, "SELECT * FROM task WHERE id = '$id' ");

            while ($rows = mysqli_fetch_array($select_task)) {?>
                <div class="timeline-row">
                    <div class="timeline-content">
                        <i class="icon-attachment"></i>
                        <h4 class="text-black uppercase"><?php echo $rows['task_title']?></h4>
                        <p class="text-black"><?php echo $rows['description']?></p>
                        <div class="">
                            <img class="img-fluid rounded" src="../assets/tasks/<?php echo $rows['documents']?>" alt="Maxwell Admin">
                        </div>
                    </div>
                    <div class="timeline-time text-center">
                        <?php echo $rows['date_submitted']?>
                    </div>
                </div>
        <?php
            }
        ?>
	</div>
</div>

<?php include "../includes/printheader/footer.php" ?>