<div class="page-title">
    <h2 class="text-secondary uppercase"><i class="fa fa-user" aria-hidden="true"></i> Interns Applicants</h2>
</div>
<div class="recent-registration">
    <div class="row">
        <div class="col-md-12">
            <div class="upload-task text-end">
                <label class="f-bold text-secondary uppercase mr-2">Seach for Intern  Applicants</label>
                <input class="w-50 form-control input-search" type="text" id="myInput" placeholder="Search for Records..">
            </div>
            <table class="table table-hover table-sm mt-4">
                <thead class="text-secondary">
                    <tr>
                    <th scope="col">Full Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Address</th>
                    <th scope="col">Course</th>
                    <th scope="col"></th>
                    </tr>
                </thead>
                <tbody id="myTable">
                    <?php 
                        $comp_id = $_SESSION['log'];
                        $select = "SELECT * FROM applicants WHERE company_id = '$comp_id'";
                        $result = mysqli_query($conn, $select);
                        
                        while($rows = mysqli_fetch_array($result)){
                            $intern_id = $rows['intern_id'];
                            
                            $select_interns = "SELECT * FROM interns WHERE id = '$intern_id'";
                           
                            $result_intern = mysqli_query($conn, $select_interns);
                            while($data = mysqli_fetch_array($result_intern)){
                                ?>
                                
                                    <tr>
                                    <td class="uppercase"><?php echo $data['firstname'] .' '. $data['middlename'][0] .' '. $data['lastname'] ?></td>
                                    <td><?php echo $data['email']?></td>
                                    <td><?php echo $data['contact']?></td>
                                    <td><?php echo $data['address']?></td>
                                    <td><?php echo $data['course']?></td>
                                    <td><a class="text-decor-none" href="../php/remove_aplicants.php?remove_aplicants=<?php echo $data['id']?>"><i class="fa fa-trash text-danger"><small> Remove</small></i></a> | <a class="text-decor-none" href="company.php?inc=aplicants-details&intern_id=<?php echo $data['id'] ?>"><i class="fa fa-arrow-right text-success"><small> Show Details</small></i></a></td>
                                    </tr>
                               
                        <?php
                            }
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
