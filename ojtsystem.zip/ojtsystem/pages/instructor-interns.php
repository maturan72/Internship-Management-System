<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-user" aria-hidden="true"></i> Intern Students</h4>
</div>
<div class="row comp-interns">
<hr>
<table class="table table-hover table-sm" id="find-table">
    <thead class="text-dark ">
        <tr>
        <th scope="col">Course</th>
        <th scope="col">Section</th>
        <th scope="col">Total Interns</th>
        <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php 
        $id = $_SESSION['log'];
        $select = "SELECT firstname, middlename, lastname, address,  course, section, count(course) as total_intern 
        FROM interns WHERE instructor = '$id'  GROUP BY course, section ";
        $result = mysqli_query($conn, $select);
        while($rows = mysqli_fetch_array($result)){
            $course = $rows['course'];
            $section = $rows['section'];
        ?>
        
            <tr class="bg-lightgray" data-bs-toggle="collapse" href="#<?php echo $course.'-'.$section ?>" role="button" aria-expanded="false" aria-controls="collapseExample">
            <!-- <td class="text-center"><i id="" class="fa fa-chevron-right show-button"></i></td> -->
            <td class="uppercase"><?php echo $rows['course']?></td>
            <td><?php echo $rows['section'] ?></td>
            <td><?php echo $rows['total_intern'] ?></td>
            <td></td>
            </tr>

            <?php
            $id = $_SESSION['log'];
            $select_data = "SELECT * FROM interns WHERE instructor = '$id' AND course = '$course' AND section = '$section'";
            $result_data = mysqli_query($conn, $select_data);
            while($rows_data = mysqli_fetch_array($result_data)){?>
            
                <tr class="collapse table-collapse"  id="<?php echo $course.'-'.$section ?>">
                <td><?php echo $rows_data['firstname'].' '.$rows_data['middlename'][0].'. '.$rows_data['lastname'] ?></td>
                <td><?php echo $rows_data['email'] ?></td>
                <td><?php echo $rows_data['address'] ?></td>
                <td><a class="text-success text-decor-none" href="instructor.php?inc=intern-info&id=<?php echo $rows_data['id']?>"><i class="fa fa-arrow-right"></i>Show More</a></td>
                </tr>
            <div>
            <?php
            }
            ?>
            
        
    <?php
        }
    ?>
    </tbody>
</table>
</div>
