<?php 
session_start();
include "../php/db_con.php" ;
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Documents</title>

    <link rel="stylesheet" href="../includes/bootstrap/css/bootstrap.min.css">
    <style rel="stylesheet" type="text/css">
        body{
            font-family: '';
            font-size: 14px;
        }
        .absolute{
            position: absolute;
        }
        .relative{
            position: relative;
        }
        .indent{
            text-indent: 20px;
        }
        .uppercase{
            text-transform: uppercase;
        }
        .background img{
            width: 100%;
            position: absolute;
            bottom:0px;
            z-index: -1;
        }
        .header{
            background-color: white;
            height: 500px;
            z-index: 1;
        }
        .header img{
            position: absolute;
            width: 100%;
            height: auto;
            top: 0;
            background-color: white;
        }
        .star{
            background-color: white;
            width: 100%;
        }
        .star img{
            position: absolute;
            width: auto;
            height: 80px;
            top: 14%;
            left: 44%;
            background-color: white;
        }
        .title{
            background-color: white;
            position: absolute;
            top: 300px;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
        }
        .title p{
            margin: 0;
            padding: 0;
        }
        .title h6{
            margin: 0;
            padding: 0;
        }
        .main-content{
            margin: 0px 96px;
            margin-top: -100px;
        }
        .apply{
            margin-top: 10px;
            border-bottom: 2px solid gray;
            text-transform: uppercase;
            background-color: white;
        }
        .this{
            margin-top: 10px;
            text-indent: 50px;
            background-color: white;
        }
        .fill-up{
            margin-top: 10px;
        }
        .fill-up p{
            margin: 0;
            padding: 0;
        }
        .one .underline{
            flex: 1;
            border-bottom: 1px solid lightgray;
        }
        .one{
            display: flex;
        }
        .undersign{
            text-indent: 50px;
        }
        .sign{
            display: flex;
        }
        .flex-1{
            flex:1;
        }
        .underline-top{
            border-top: 1px solid lightgray;
        }
        .underline{
            border-bottom: 1px solid lightgray;
        }
        .data{
            margin-top: 10px;
        }
        .left-side{
            padding: 0px 50px 0px 0px;
        }
        .right-side{
            padding: 0px 0px 0px 0px;
        }
        .photo{
            width: 96px;
            height: 96px;
            border: 1px solid black;
            margin: 0 auto;
        }
        .ojt{
            margin-top: 20px;
        }
        .malolos{
            position: absolute;
            bottom: 50px;
            z-index: 1;
            font-style: italic;
            color: #03034e;
            font-family: sans-serif;
            margin-left: 96px;
        }
        @page{
            size: legal;
        }
    </style>
</head>
<body>
    <?php
        $studentid = $_GET['studentid'];
        $select_data = mysqli_query($conn, "SELECT s.firstname, s.middlename, s.lastname, s.address, a.hours_spent, c.firstname AS cfn, c.middlename AS cmn, c.lastname AS cln, c.companyname, c.address AS companyaddress FROM interns s
        INNER JOIN `application` a ON s.student_id = a.studentid INNER JOIN company c ON s.company = c.id WHERE s.student_id = '$studentid' ");
        if(mysqli_num_rows($select_data) > 0){
            while($row = mysqli_fetch_array($select_data)){?>
                <div id="allcontent">
                    <div class="background">
                        <img src="../assets/forms/footer.jpg" alt="">
                    </div>
                    <div class="header">
                        <img src="../assets/forms/header.png" alt="">
                        <div class="star">
                            <img src="../assets/forms/starlogo.png" alt="">
                        </div>
                        <div class="title content text-center">
                            <div class="text-center">
                            <p>Republic of the Philippines</p>
                            <h6>DEPARTMENT OF LABOR AND EMPLOYMENT</h6>
                            <h6>BULACAN EXTENSION OFFICE</h6>
                            <p>Provincial Capitol, Malolos City, Bulacan</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="main-content">
                        
                        <div class="apply text-start">
                            <h6>APPLICATION FOR SPECIAL CERTIFICATE TO EMPLOY, LEARNER OR APPRENTICE WITHOUT COMPENSATION AS A REQUIREMENT OF A SCHOOL CURRICULUM OR AS A PRE-REQUISITE TO A BOARD EXAMININATION</h6>
                        </div>
                        <div class="this text-start">
                            <p>This application must be accompanied by a certification from the school attended by the apprentice stating the number of hours of On-the-Job Training required by the curriculum course being taken.  Attach recent photo of apprentice.  Application may not fully accomplish shall not be entertained.</p>
                        </div>
                        <div class="fill-up text-start">
                            <div class="one">
                                <p>1.  Name of Establishment: </p>
                                <p class="underline text-start indent uppercase"><?php echo $row['companyname'] ?></p>
                            </div>
                            <div class="one">
                                <p>2.  Address of Location: </p>
                                <p class="underline text-start indent uppercase"><?php echo $row['companyaddress'] ?></p>
                            </div>
                            <div class="one">
                                <p>3.  Name of Proposed Apprentice/Student-Trainee: </p>
                                <p class="underline text-start indent uppercase"><?php echo $row['firstname'].' '.$row['middlename'][0].'. '.$row['lastname'] ?></p>
                            </div>
                            <div class="one">
                                <p>4.  Name of Institution: </p>
                                <p class="underline text-start indent uppercase">Bulacan Polytechnic College</p>
                            </div>
                            <div class="one">
                                <p>5.  Nature of Training: </p>
                                <p class="underline text-start indent uppercase">ON THE JOB TRAINING</p>
                            </div>
                            <div class="one">
                                <p>6.  Period of Training: </p>
                                <p class="underline text-start indent uppercase"> </p>
                            </div>
                            <div class="one">
                                <p>7.  Number of Hours to be spent Daily: </p>
                                <p class="underline text-start indent uppercase"><?php echo $row['hours_spent'] ?> hours</p>
                            </div>
                        </div>
                        <div class="note text-start mt-4">
                            <p>(Note:  Trainees should not expend more than eight (8) hours/day.  In excess of the required (8) hours training is not obligatory, but for the purpose of concluding the required number of hours for the entire training, it will be arranged accordingly between the student and the company).</p>
                        </div>
                        <div class="undersign text-start">
                            <p>The undersigned certifies that the information given above is true and correct and that the employment of the above-named apprentice will not prejudice the existing office personnel of the establishment and that the picture attached is that of apprentice; and that the said practice/training will not be a ground for employment on any position that may become vacant in the future.</p>
                        </div>
                        <div class="sign mt-4">
                            <div class="flex-1 text-center left-side ">
                                <div class="photo">

                                </div>
                                <div class="ojt mt-4">
                                    <h6 class="data mt-4"></h6>
                                    <h6 class="underline-top designation">Signature of Apprentice/OJT</h6>
                                    <h6 class="data underline mt-4"></h6>
                                </div>
                            </div>
                            <div class="flex-1 text-center right-side mt-4">
                                <h6 class="data"></h6>
                                <h6 class="underline-top">Signature of Employer over Printed Name</h6>
                                <h6 class="data mt-4"></h6>
                                <h6 class="underline-top designation">Designation</h6>
                                <h6 class="data mt-4"></h6>
                                <h6 class="underline-top designation">Date</h6>
                            </div>
                        </div>
                    </div>
                    <div class="malolos">
                        <label class="bold">Brgy, Bulihan, City of Malolos</label>
                    </div>
                </div>
            <?php
            }
        }else{
            $compid = $_GET['comp_id'];
            $studentid = $_GET['studentid'];
            $select_data = mysqli_query($conn, "SELECT s.firstname, s.middlename, s.lastname, s.address, a.hours_spent FROM interns s
            INNER JOIN `application` a ON s.student_id = a.studentid WHERE s.student_id = '$studentid' ");

            $select_comp = mysqli_query($conn, "SELECT * FROM company WHERE id = '$compid' ");
            $comp = mysqli_fetch_array($select_comp);

            while($row = mysqli_fetch_array($select_data)){?>
                <div id="allcontent">
                    <div class="background">
                        <img src="../assets/forms/footer.jpg" alt="">
                    </div>
                    <div class="header">
                        <img src="../assets/forms/header.png" alt="">
                        <div class="star">
                            <img src="../assets/forms/starlogo.png" alt="">
                        </div>
                        <div class="title content text-center">
                            <div class="text-center">
                            <p>Republic of the Philippines</p>
                            <h6>DEPARTMENT OF LABOR AND EMPLOYMENT</h6>
                            <h6>BULACAN EXTENSION OFFICE</h6>
                            <p>Provincial Capitol, Malolos City, Bulacan</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="main-content">
                        
                        <div class="apply text-start">
                            <h6>APPLICATION FOR SPECIAL CERTIFICATE TO EMPLOY, LEARNER OR APPRENTICE WITHOUT COMPENSATION AS A REQUIREMENT OF A SCHOOL CURRICULUM OR AS A PRE-REQUISITE TO A BOARD EXAMININATION</h6>
                        </div>
                        <div class="this text-start">
                            <p>This application must be accompanied by a certification from the school attended by the apprentice stating the number of hours of On-the-Job Training required by the curriculum course being taken.  Attach recent photo of apprentice.  Application may not fully accomplish shall not be entertained.</p>
                        </div>
                        <div class="fill-up text-start">
                            <div class="one">
                                <p>1.  Name of Establishment: </p>
                                <p class="underline text-start indent uppercase"><?php echo $comp['companyname'] ?></p>
                            </div>
                            <div class="one">
                                <p>2.  Address of Location: </p>
                                <p class="underline text-start indent uppercase"><?php echo $comp['address'] ?></p>
                            </div>
                            <div class="one">
                                <p>3.  Name of Proposed Apprentice/Student-Trainee: </p>
                                <p class="underline text-start indent uppercase"><?php echo $row['firstname'].' '.$row['middlename'][0].'. '.$row['lastname'] ?></p>
                            </div>
                            <div class="one">
                                <p>4.  Name of Institution: </p>
                                <p class="underline text-start indent uppercase">Bulacan Polytechnic College</p>
                            </div>
                            <div class="one">
                                <p>5.  Nature of Training: </p>
                                <p class="underline text-start indent uppercase">ON THE JOB TRAINING</p>
                            </div>
                            <div class="one">
                                <p>6.  Period of Training: </p>
                                <p class="underline text-start indent uppercase"> </p>
                            </div>
                            <div class="one">
                                <p>7.  Number of Hours to be spent Daily: </p>
                                <p class="underline text-start indent uppercase"><?php echo $row['hours_spent'] ?> hours</p>
                            </div>
                        </div>
                        <div class="note text-start mt-4">
                            <p>(Note:  Trainees should not expend more than eight (8) hours/day.  In excess of the required (8) hours training is not obligatory, but for the purpose of concluding the required number of hours for the entire training, it will be arranged accordingly between the student and the company).</p>
                        </div>
                        <div class="undersign text-start">
                            <p>The undersigned certifies that the information given above is true and correct and that the employment of the above-named apprentice will not prejudice the existing office personnel of the establishment and that the picture attached is that of apprentice; and that the said practice/training will not be a ground for employment on any position that may become vacant in the future.</p>
                        </div>
                        <div class="sign mt-4">
                            <div class="flex-1 text-center left-side ">
                                <div class="photo">

                                </div>
                                <div class="ojt mt-4">
                                    <h6 class="data mt-4"></h6>
                                    <h6 class="underline-top designation">Signature of Apprentice/OJT</h6>
                                    <h6 class="data underline mt-4"></h6>
                                </div>
                            </div>
                            <div class="flex-1 text-center right-side mt-4">
                                <h6 class="data"></h6>
                                <h6 class="underline-top">Signature of Employer over Printed Name</h6>
                                <h6 class="data mt-4"></h6>
                                <h6 class="underline-top designation">Designation</h6>
                                <h6 class="data mt-4"></h6>
                                <h6 class="underline-top designation">Date</h6>
                            </div>
                        </div>
                    </div>
                    <div class="malolos">
                        <label class="bold">Brgy, Bulihan, City of Malolos</label>
                    </div>
                </div>
        <?php
            }
        }
    ?>
    <script>window.print();</script>
</body>
</html>