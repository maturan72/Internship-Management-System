<div class="page-title">
    <h4>My Messages</h4>
  <hr>
</div>
<div class="row inbox-section">
   <div class="avatar-user message d-flex">
       <div class="avatar1">
           <img src="../assets/images/avatar.jpg" alt="">
       </div>
       <div class="">
           <div class="user-name">
               <h6 class="f-bold m-0">Darwin Maturan</h6>
               <p class="message-content m-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium obcaecati corrupti ab deserunt ad odio repellendus, minus voluptatum illo maxime. A quo mollitia quas deleniti, commodi dolor temporibus molestiae expedita.</p>
               <p class="m-0">Jan 3, 2023</p>
           </div>
       </div>
   </div>
   <div class="avatar-user message mt-4 d-flex">
       <div class="avatar1">
           <img src="../assets/images/bpclogo.png" alt="">
       </div>
       <div class="">
           <div class="user-name">
               <h6 class="f-bold m-0">Administrator</h6>
               <p class="message-content m-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium obcaecati corrupti ab deserunt ad odio repellendus, minus voluptatum illo maxime. A quo mollitia quas deleniti, commodi dolor temporibus molestiae expedita.</p>
               <p class="m-0">Jan 3, 2023</p>
           </div>
       </div>
   </div>
   <div class="avatar-user message mt-4 d-flex">
       <div class="avatar1">
           <img src="../assets/images/intern.jpg" alt="">
       </div>
       <div class="">
           <div class="user-name">
               <h6 class="f-bold m-0">Jolly Cubijano</h6>
               <p class="message-content m-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium obcaecati corrupti ab deserunt ad odio repellendus, minus voluptatum illo maxime. A quo mollitia quas deleniti, commodi dolor temporibus molestiae expedita.</p>
               <p class="m-0">Jan 3, 2023</p>
           </div>
       </div>
   </div>
   <div class="avatar-user message mt-4 d-flex">
       <div class="avatar1">
           <img src="../assets/images/student.jpg" alt="">
       </div>
       <div class="">
           <div class="user-name">
               <h6 class="f-bold m-0">Josehp Cedric Vallente</h6>
               <p class="message-content m-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium obcaecati corrupti ab deserunt ad odio repellendus, minus voluptatum illo maxime. A quo mollitia quas deleniti, commodi dolor temporibus molestiae expedita.</p>
               <p class="m-0">Jan 3, 2023</p>
           </div>
       </div>
   </div>
</div>