<div class="admin-info">
    <div class="admin-update">
        <form action="../php/instructor_update.php" method="post">
            <?php
                $id = $_SESSION['log'];
                $instructor_data = "SELECT * FROM instructor WHERE id = '$id'";
                $ins_result = mysqli_query($conn, $instructor_data);
                while($data = mysqli_fetch_array($ins_result)){
                    ?>
                    <div class="box-content">
                        <h4 class="f-bold text-primary">Instructor Information:</h4>
                        
                        <div class="row mt-4">
                            <div class="col-md-5">
                                <label for=""><strong>First Name:</strong></label>
                                <input class="form-control" type="text" name="fname" value="<?php echo $data['firstname']?>">
                            </div>
                            <div class="col-md-2">
                                <label for=""><strong>Middle Name:</strong></label>
                                <input class="form-control" type="text" name="mname" value="<?php echo $data['middlename']?>">
                            </div>
                            <div class="col-md-5">
                                <label for=""><strong>Last Name:</strong></label>
                                <input class="form-control" type="text" name="lname" value="<?php echo $data['lastname']?>">
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="col-md-12">
                                    <label for=""><strong>Address:</strong></label>
                                    <input class="form-control" type="text" name="address" value="<?php echo $data['address']?>">
                                </div>
                                <div class="col-md-12">
                                    <div class="email mt-4">
                                        <label for=""><strong>Email Address:</strong></label>
                                        <input class="form-control" type="email" name="email" value="<?php echo $data['email']?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="col-md-12">
                                    <div class="email">
                                        <label for=""><strong>Password:</strong></label>
                                        <input class="form-control" type="password" name="password" value="<?php echo $data['password']?>">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="email mt-4">
                                        <label for=""><strong>Password:</strong></label>
                                        <input class="form-control" type="password" name="confirm" value="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input class="form-control" type="hidden" name="id" value="<?php echo $data['id']?>">
                        <div class="button mt-4 text-end">
                            <div class="col-md-12">
                                <label class="text-end">
                                    <?php
                                        if($_SESSION['pass_err']){?>
                                        <div class="text-danger">
                                            Password Don't Match!
                                        </div>
                                        
                                    <?php
                                        unset($_SESSION['pass_err']);
                                        }elseif($_SESSION['upd_succ']){?>
                                        <div class="text-success">
                                        Updated Successfully!
                                        </div>
                                    <?php
                                        unset($_SESSION['upd_succ']);
                                        }
                                    ?>
                                </label>
                            </div>
                        <input class="form-control" type="hidden" name="comp_id" value="<?php echo $data['id']?>">
                            <input type="submit" class="btn btn-success" name="comp_upd" value="Update Information">
                        </div>
                    </div>
                <?php
                }
            ?>
        </form>
    </div>
</div>