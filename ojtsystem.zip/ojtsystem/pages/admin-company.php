<div id="records" class="container bg-white">
    <div class="page-title">
        <h4 class="uppercase text-secondary"> <i class="fa fa-building" aria-hidden="true"></i> List of Compnay</h4>
    </div>
    <div class="overflow bg-white mt-4 h-5 p-20-0">
        <div class="upload-task text-end">
            <label class="f-bold text-secondary uppercase mr-2">Seach for Company </label>
            <input class="w-50 form-control input-search" type="text" id="myInput" placeholder="Search for names..">
        </div>
        <table class="table table-hover table-sm mt-4">
            <thead class="text-secondary">
                <tr>
                <th scope="col">Supervisor Name</th>
                <th scope="col">Email</th>
                <th scope="col">Contact</th>
                <th scope="col">Address</th>
                <th></th>
                </tr>
            </thead>
            <tbody id="myTable">
            <?php
            $select = mysqli_query($conn, "SELECT * FROM company");
            while($rows = mysqli_fetch_array($select)){?>
                <tr>
                <td class="uppercase"><?php echo $rows['firstname'] .' '. $rows['middlename'][0] .' '. $rows['lastname'] ?></td>
                <td><?php echo $rows['email'] ?></td>
                <td><?php echo $rows['contact'] ?></td>
                <td><?php echo $rows['address'] ?></td>
                <td><a class="text-decor-none" href="../php/archive.php?id=<?php echo $rows['id']?>&type=company"><i class="fa fa-archive text-danger"><small> archive</small></i></a> | <a class="text-decor-none" href="?inc=company-info&id=<?php echo $rows['id'] ?>"><i class="fa fa-arrow-right text-success"><small> show</small></i></td>
                </tr>
            <?php
                }
            ?>
            </tbody>
        </table>
    </div>
</div>
