<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-list" aria-hidden="true"></i> My Documents</h4>
</div>

<div class="row documents-btn">
    <div class="col-md-12">
        <div class="upload-task text-end">
            <a href="student.php?inc=forms" class="btn btn-success">Create or Update Form</a>
        </div>
        <hr>
        <?php
            $log = $_SESSION['log'];
            $select_intern = mysqli_query($conn, "SELECT * FROM interns WHERE id ='$log' ");
            $row = mysqli_fetch_array($select_intern);
            $student_id = $row['student_id'];

            $find_application = mysqli_query($conn, "SELECT * FROM `application` WHERE studentid = '$student_id' ");
            $find_waiver = mysqli_query($conn, "SELECT * FROM `waiver` WHERE studentid = '$student_id' ");
            $find_evaluation = mysqli_query($conn, "SELECT * FROM `evaluation` WHERE studentid = '$student_id' ");
            $find_information = mysqli_query($conn, "SELECT * FROM `information` WHERE studentid = '$student_id' ");

            if(mysqli_num_rows($find_application) >= 1){?>
                <div class="d-flex flex-column">
                    <div class="form_name row">
                        <div class="col-md-5">
                            <h4>Student Application Form </h4>
                        </div>
                        <div class="col-md-7">
                            <div class="text-start">
                                <a target='_blank' href="student-application-form.php?studentid=<?php echo $student_id; ?>" class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Print / Save Application</a>
                                <!-- <a href="student-application-form.php?studentid=<?php echo $student_id; ?>" class="btn btn-success"><i class="fa fa-download"></i> Download Application</a>
                                <a href="?inc=application-form&studentid=<?php echo $student_id; ?>&ACTION=UPLOAD" class="btn btn-warning"><i class="fa fa-upload"></i> Update Application</a> -->
                            </div>
                        </div>
                    <small class="text-secondary">Application Form</small>
                    </div>
                    <hr class="text-secondary">
                    
                </div>
        <?php
            }
            if(mysqli_num_rows($find_waiver) >= 1){?>
                <div class="d-flex flex-column">
                    <div class="form_name row">
                        <div class="col-md-5">
                            <h4>Student Waiver Form </h4>
                        </div>
                        <div class="col-md-7">
                            <div class="text-start">
                                <a target='_blank' href="student-waiver.php?studentid=<?php echo $student_id; ?>" class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Print / Save Waiver</a>
                                <!-- <a href="?inc=waiver&studentid<?php echo $student_id; ?>&ACTION=DOWNLOAD" class="btn btn-success"><i class="fa fa-download"></i> Download Waiver</a>
                                <a href="?inc=waiver&studentid<?php echo $student_id; ?>&ACTION=UPLOAD" class="btn btn-warning"><i class="fa fa-upload"></i> Update Waiver</a> -->
                            </div>
                        </div>
                    <small class="text-secondary">Waiver Form</small>
                    </div>
                    <hr class="text-secondary">
                    
                </div>
        <?php
            }
            if(mysqli_num_rows($find_evaluation) >= 1){?>
                <div class="d-flex flex-column">
                    <div class="form_name row">
                        <div class="col-md-5">
                            <h4>Student Evaluation Form </h4>
                        </div>
                        <div class="col-md-7">
                            <div class="text-start">
                                <a target='_blank' href="student-evaluation.php?studentid=<?php echo $student_id; ?>" class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Print / Save Evaluation</a>
                                <!-- <a href="?inc=evaluation&studentid<?php echo $student_id; ?>&ACTION=DOWNLOAD" class="btn btn-success"><i class="fa fa-download"></i> Download Evaluation</a>
                                <a href="?inc=evaluation&studentid<?php echo $student_id; ?>&ACTION=UPLOAD" class="btn btn-warning"><i class="fa fa-upload"></i> Update Evaluation</a> -->
                            </div>
                        </div>
                    <small class="text-secondary">Evaluation Form</small>
                    </div>
                    <hr class="text-secondary">
                    
                </div>
        <?php
            }
            if(mysqli_num_rows($find_information) >= 1){?>
                <div class="d-flex flex-column">
                    <div class="form_name row">
                        <div class="col-md-5">
                            <h4>Student Information Form </h4>
                        </div>
                        <div class="col-md-7">
                            <div class="text-start">
                                <a target='_blank' href="student-information-sheet.php?studentid=<?php echo $student_id; ?>" class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Print / Save Information</a>
                                <!-- <a href="?inc=information&studentid<?php echo $student_id; ?>&ACTION=DOWNLOAD" class="btn btn-success"><i class="fa fa-download"></i> Download Information</a>
                                <a href="?inc=information&studentid<?php echo $student_id; ?>&ACTION=UPLOAD" class="btn btn-warning"><i class="fa fa-upload"></i> Update Information</a> -->
                            </div>
                        </div>
                    <small class="text-secondary">Information Form</small>
                    </div>
                    <hr class="text-secondary">
                    
                </div>
        <?php
            }
        ?>
    </div>
</div>