admin pages
	1. approve company / instructor
	2. archive data
	3. view company / instructor / interns data
	
company pages
	1.post new opening jobs
	2.view task reports of interns
	3.view all interns
	4.view interns records
	5.view delete and accept new interns 		  applicants

instructor pages
	1.accept and delete new interns students
	2.view interns by course and section
	3.view interns records
	
interns pages
	1.view timeline records
	2.upload task / day
	3.create form or documents
	4.print for documentation (per day)
	5.time in (out)
	6.print weekly reports
	7.search for new oppening jobs
