<div class="register">
    <div class="register-content">
        <div class="row right-col">
            <div class="col-md-10 content">
                <form action="php/register.php" method="post">
                    <div class="text-center uppercase text-secondary">
                        <h3 class="f-bold">Instructor Registration Form</h3>
                    </div>
                    <div class="row mt-4">
                        <h6>Personal Details</h6>
                        <div class="col-md-4">
                            <input name="fname" class="form-control border-0" type="text" required>
                            <hr class="m-0">
                            <small class="text-secondary">First Name:</small>
                        </div>
                        <div class="col-md-4">
                            <input name="mname" class="form-control border-0" type="text" required>
                            <hr class="m-0">
                            <small class="text-secondary">Middle Name:</small>
                        </div>
                        <div class="col-md-4">
                            <input name="lname" class="form-control border-0" type="text" required>
                            <hr class="m-0">
                            <small class="text-secondary">Last Name:</small>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-md-4">
                            <input name="contact" class="form-control border-0" type="text"
                            oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)./g, '$1');" required>
                            <hr class="m-0">
                            <small class="text-secondary">Contact Number:</small>
                        </div>
                        <div class="col-md-8">
                            <input name="address" class="form-control border-0" type="text" required>
                            <hr class="m-0">
                            <small class="text-secondary">Address:</small>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-md-4">
                            <input name="email" onkeyup='validateForm();' id="email" class="form-control border-0" type="email" required>
                            <hr class="m-0">
                            <small class="text-secondary">Email:</small>
                            <small id='email_message'></small>
                        </div>
                        <div class="col-md-4">
                            <div class="input-group">
                                <input id="password" name="password" class="form-control border-0" type="password" required>
                                <span onclick="showpass()" class="eye fa fa-eye"></span>
                            </div>
                            <hr class="m-0">
                            <small class="text-secondary">Password:</small>
                        </div>
                        <div class="col-md-4">
                            <div class="input-group">
                                <input id="confirmpassword" onkeyup='check();' name="confirm" class="form-control border-0" type="password" required>
                                <span onclick="showpass2()" class="eye fa fa-eye"></span>
                            </div>
                            <hr class="m-0">
                            <small class="text-secondary">Confirm Password:</small>
                            <small id='message'></small>
                        </div>
                    </div>
                
                    <div class="submit text-end mt-4">
                        <a href="index.php" class="btn btn-danger" type="submit">Cancel</a>
                        <input class="btn btn-info" id="submit" type="submit" name="instructor" value="Register Now..">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>