<?php include "includes/header.php" ?>

    <!-- Begin Page Content -->
  <div class="page-content container-fluid">
        <?php 
            if ($_GET['inc']){
                $inc = $_GET['inc'] . '.php';
                include $inc;
            }else{
                include "login-acc.php";
            }
        ?>
  </div>

    
<?php include "includes/footer.php" ?>

