<div class="register">
    <div class="register-content">
        <div class="row">
            <div class="col-md-12">
                <div class="d-flex justify-content-center align-items-center">
                    <div class="login-form bg-white">
                        <form action="php/login.php" method="post">
                            <h4 class="text-secondary">Login</h4>
                            <hr>
                            <label class="text-secondary" for="">Email:</label>
                            <input class="form-control" type="email" name="email" required>
                            <label class="text-secondary" for="">password:</label>
                            <input class="form-control" type="password" name="password" required>
                            <div class="button text-end mt-4">
                                <input type="submit" class="btn btn-success form-control" name="login" value="Log In">
                                <div class="button text-center mt-4">
                                    <a class="btn btn-danger form-control" href="index.php">Go Back</a>
                                </div>
                            </div>
                            <div class="text-center mt-4">
                                <a class="text-center" href="">forgot password?</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>