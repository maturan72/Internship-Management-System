<div class="register">
    <div class="register-content">
        <div class="row">
            <div class="col-md-4 left-col">
                <div class="image text-center">
                    <img src="assets/images/bpclogo.png" alt="">
                    <h3>Bulacan</h3>
                    <h4>Polytechnic College</h4>
                    <h5>Main Campus</h5>
                </div>
            </div>
            <div class="col-md-8">
                <div class="right-col d-flex justify-content-center align-items-center">
                    <div class="back-button">
                        
                    </div>
                    <div class="login-form">
                        <form action="php/login.php" method="post">
                            <h4>Login</h4>
                            <hr>
                            <label for="">Email:</label>
                            <input class="form-control" type="email" name="email" required>
                            <label for="">password:</label>
                            <input class="form-control" type="password" name="password" required>
                            <div class="button text-end mt-4">
                                <h6 for="" class="text-danger text-center">
                                <?php
                                    if($_SESSION['pass_err']){
                                        echo "Invalid Account or Password";
                                        unset($_SESSION['pass_err']);
                                    }
                                ?>
                                </h6>
                                <h6 for="" class="text-success text-center">
                                <?php
                                    if($_SESSION['succ']){
                                        echo "Good job! please wait for confirmation.";
                                        unset($_SESSION['succ']);
                                    }
                                ?>
                                </h6>
                                <a class="btn btn-danger" href="index.php">Cancel</a>
                                <input type="submit" class="btn btn-info" name="login" value="Log In">
                            </div>
                            <div class="text-center mt-4">
                                <a class="text-center" href="">forgot password?</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>