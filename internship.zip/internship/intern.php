<div class="register">
    <div class="register-content">
        <div class="row">
            <div class="col-md-4 left-col">
                <div class="image text-center">
                    <img src="assets/images/bpclogo.png" alt="">
                    <h3>Bulacan</h3>
                    <h4>Polytechnic College</h4>
                    <h5>Main Campus</h5>
                </div>
            </div>
            <div class="col-md-8">
                <form action="php/register.php" method="post">
                    <div class="right-col">
                        <!-- <div class="type-button text-end">
                            <div class="bacground-button text-center">
                                <a href="?inc=instructor">Instructor</a>
                                <a class="active" href="?inc=intern">Interns</a>
                            </div>
                        </div> -->
                        <div class="text-center">
                            <h3>Interns Registration Form</h3>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-4">
                                <label for="fname">First Name:</label>
                                <input name="fname" class="form-control" type="text" required>
                            </div>
                            <div class="col-md-4">
                                <label for="mname">Middle Name:</label>
                                <input name="mname" class="form-control" type="text" required>
                            </div>
                            <div class="col-md-4">
                                <label for="lname">Last Name:</label>
                                <input name="lname" class="form-control" type="text" required>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-2">
                                <label for="age">Age:</label>
                                <input name="age" class="form-control" type="number" required>
                            </div>
                            <div class="col-md-3">
                                <label for="">Gender:</label>
                                <select name="gender" id="" class="form-control" required>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                            </div>
                            <div class="col-md-7">
                                <label for="address">Address:</label>
                                <input name="address" class="form-control" type="text" required>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-4">
                                <label for="course">Course:</label>
                                <input name="course" class="form-control" type="text" required>
                            </div>
                            <div class="col-md-4">
                                <label for="course">Instructor:</label>
                                    <select name="instructor" id="" class="form-control" required>
                                        <option value="">Search instructor..</option>
                                    <?php
                                        $select = mysqli_query($conn, ("SELECT * FROM instructor"));
                                        while($row = mysqli_fetch_array($select)){?>
                                                <option value="<?php echo $row['id']?>"><?php echo $row['firstname'].' '.$row['middlename'].' '.$row['lastname'] ?></option>
                                    <?
                                        }
                                    ?>
                                    </select>
                            </div>
                            <div class="col-md-4">
                                
                                <label for="email">Email: <span><small class="text-danger">
                                <?php 
                                    if($_SESSION['email_err']){
                                    echo"Email is already taken!";
                                    }
                                    unset($_SESSION['email_err']);
                                ?>
                                </small></span></label>
                                <input name="email" id="txtemail" class="form-control" type="email" required>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <?php 
                                if($_SESSION['err']){?>
                                <div class="col-md-6">
                                    <div class="col-md-12">
                                        <label for="password">Password: <span class="message text-danger">Password dont match!</span></label>
                                        <input name="password" class="err form-control" type="password" required>
                                    </div>
                                    <div class="col-md-12">
                                        <label for="confirm">Confirm Password:</label>
                                        <input  name="confirm" class="err form-control" type="password" required>
                                    </div>
                                </div>
                            <?php
                                unset($_SESSION['err']);
                                }else {?>
                                <div class="col-md-6">
                                    <div class="col-md-12">
                                        <label for="password">Password:</label>
                                        <input name="password" class="form-control" type="password" required>
                                    </div>
                                    <div class="col-md-12">
                                        <label for="confirm">Confirm Password:</label>
                                        <input  name="confirm" class="form-control" type="password" required>
                                    </div>
                                </div>
                            <?php
                                }
                            ?>
                            
                            <div class="col-md-6">
                                <label for="">Skills:</label>
                                <textarea name="skills" class="form-control" name="skills" id="" required></textarea>
                            </div>
                        </div>
                        <div class="submit text-end mt-4">
                            <a href="index.php" class="btn btn-danger" type="submit">Cancel</a>
                            <input class="btn btn-info" type="submit" name="intern" value="Register Now..">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>