<div class="page-title">
    <h4>My Task</h4>
    <div class="task-list d-flex">
        <a href="?inc=finish-task">Finished Task</a>
        <a href="?inc=ongoing-task">Ongoing Task</a>
        <!-- <a href="">Pending Task</a> -->
    </div>
</div>

<div class="row task-table">
    <div class="col-md-12">
        <div class="upload-task text-end">
            <a href="student.php?inc=upload-task" class="btn btn-info">Upload Task Progress</a>
        </div>
        <hr>
        <table class="table table-hover table-sm">
            <thead class="text-dark">
                <tr>
                <th scope="col">Task Name</th>
                <th scope="col">progress</th>
                <th scope="col">Due Date</th>
                <th scope="col">Status</th>
                </tr>
            </thead>
            <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM task WHERE intern_id = '$id' ";
                    $result = mysqli_query($conn, $select);
                    while($rows = mysqli_fetch_array($result)){?>
                    <tbody>
                        <tr>
                        <td><?php echo $rows['task_description'] ?></td>
                        <td><?php echo $rows['progress'] ?></td>
                        <td><?php echo $rows['due_date'] ?></td>
                        <td><?php echo $rows['status'] ?></td>
                        </tr>
                    </tbody>
                <?php
                    }
                ?>
        </table>
    </div>
</div>