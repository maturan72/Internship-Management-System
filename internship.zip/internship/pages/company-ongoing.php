<div class="page-title">
    <h4>Task Reports</h4>
    <div class="task-list d-flex">
        <a href="?inc=finish">Finished Task</a>
        <a class="text-success"  href="?inc=ongoing">Ongoing Task</a>
        <!-- <a href="">Pending Task</a> -->
    </div>
</div>

<div class="row task-table">
    <div class="col-md-12">
        <hr>
        <table class="table table-hover table-sm">
            <thead class="text-dark">
                <tr>
                <th scope="col">Task Name</th>
                <th scope="col">Intern</th>
                <th scope="col">progress</th>
                <th scope="col">Due Date</th>
                <th scope="col">Status</th>
                </tr>
            </thead>
            <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM task INNER JOIN interns
                    ON task.intern_id = interns.id WHERE comp_id = '$id' AND task.status = 'ongoing' ";
                    $result = mysqli_query($conn, $select);
                    while($rows = mysqli_fetch_array($result)){?>
                    <tbody>
                        <tr>
                        <td><?php echo $rows['task_description'] ?></td>
                        <td><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname'] ?></td>
                        <td><?php echo $rows['progress'] ?></td>
                        <td><?php echo $rows['due_date'] ?></td>
                        <td><?php echo $rows['status'] ?></td>
                        </tr>
                    </tbody>
                <?php
                    }
                ?>
        </table>
    </div>
</div>