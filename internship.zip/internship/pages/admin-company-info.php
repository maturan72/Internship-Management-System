<div id="request-info" class="container-fluid">
    <h1>Company information / Records</h1>
    <div class="row mt-4">
        <div class="col-md-4 info">
            <?php 
                $id = $_GET['id'];
                $select = "SELECT * FROM company WHERE id = '$id' ";
                $result = mysqli_query($conn, $select);
                while($rows = mysqli_fetch_array($result)){?>
                    <div class="background-avatar avatar">
                        <img src="../assets/avatar/<?php echo $rows['id'].$rows['firstname'].'.jpg' ?>" alt="">
                    </div>
                    <div class="name mt-4">
                        <h3 class="text-success"><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname']?></h3>
                        <small>Supervisor Name</small>
                    </div>
                    <hr>
                    <div class="company">
                        <h6><?php echo $rows['email']?></h6>
                        <small>Email Address</small>
                    </div>  
                    <hr>
                    <div class="company">
                        <h6><?php echo $rows['companyname']?></h6>
                        <small>Company Name</small>
                    </div>  
                    <hr>
                    <div class="company">
                        <h6><?php echo $rows['address']?></h6>
                        <small>Company Address</small>
                    </div> 
            <?php
                }
            ?>
        </div>
        <div class="col-md-8">
            <div class="page-title">
                <h4 class="text-info">My Task</h4>
                <div class="task-list d-flex">
                    <a href="">Finished Task</a>
                    <a href="">Ongoing Task</a>
                </div>
            </div>
            <div class="row task-table">
                <div class="col-md-12 h-2-5 overflow border">
                    <hr>
                    <table class="table table-hover table-sm">
                        <thead class="text-dark">
                            <tr>
                            <th scope="col">Task Name</th>
                            <th scope="col">progress</th>
                            <th scope="col">Due Date</th>
                            <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <?php 
                                $id = $_GET['id'];
                                $select = "SELECT * FROM task WHERE comp_id = '$id' ";
                                $result = mysqli_query($conn, $select);
                                while($rows = mysqli_fetch_array($result)){?>
                                <tbody>
                                    <tr>
                                    <td><?php echo $rows['task_description'] ?></td>
                                    <td><?php echo $rows['progress'] ?></td>
                                    <td><?php echo $rows['due_date'] ?></td>
                                    <td><?php echo $rows['status'] ?></td>
                                    </tr>
                                </tbody>
                            <?php
                                }
                            ?>
                    </table>
                </div>
            </div>
            <div class="recent-registration">
                <div class="row comp-interns">
                    <div class="col-md-12 h-4 overflow">
                        <div class="row">
                            <div class="col-md-6">
                                <h5 class="f-bold text-info">List Of Interns</h5>
                            </div>
                        </div>
                        <hr>
                        <table class="table table-hover table-sm">
                            <thead class="text-dark">
                                <tr>
                                <th scope="col">Full Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">address</th>
                                </tr>
                            </thead>
                            <?php 
                                $id = $_GET['id'];
                                $select = "SELECT * FROM interns WHERE company = '$id' ";
                                $result = mysqli_query($conn, $select);
                                while($rows = mysqli_fetch_array($result)){?>
                                <tbody>
                                    <tr>
                                    <td class="uppercase"><?php echo $rows['firstname'] .' '. $rows['middlename'][0] .' '. $rows['lastname'] ?></td>
                                    <td><?php echo $rows['email'] ?></td>
                                    <td><?php echo $rows['address'] ?></td>
                                    </tr>
                                </tbody>
                            <?php
                                }
                            ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
