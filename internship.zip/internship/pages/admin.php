<?php include "../includes/admin/header.php" ?>

  <!-- Begin Page Content -->
  <div class="page-content container-fluid">
        <?php 
            if ($_GET['inc']){
                $inc = 'admin-' . $_GET['inc'] . '.php';
                include $inc;
            }else{
                include "admin-dashboard.php";
            }
        ?>
  </div>

</div>

    
<?php include "../includes/admin/footer.php" ?>