<?php include "../includes/company/header.php" ?>

  <!-- Begin Page Content -->
  <div class="page-content container-fluid">
        <?php 
            if ($_GET['inc']){
                $inc = 'company-' . $_GET['inc'] . '.php';
                include $inc;
            }else{
                include "company-dashboard.php";
            }
        ?>
  </div>

</div>

    
<?php include "../includes/company/footer.php" ?>