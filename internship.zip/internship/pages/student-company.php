<div class="page-title">
<h4 class="uppercase text-secondary"> <i class="fa fa-building" aria-hidden="true"></i> Search For Jobs</h4>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="upload-task text-end">
            <label class="f-bold text-secondary uppercase mr-2">Seach for Company </label>
            <input class="w-50 form-control input-search" type="text" id="myInput" placeholder="Search for names..">
        </div>
        <hr>
        <table class="table table-hover table-sm">
            <thead class="text-secondary">
                <tr>
                <th scope="col">Job Title</th>
                <th scope="col">Company Name</th>
                <th scope="col">email</th>
                <th scope="col">contact</th>
                <th scope="col">address</th>
                <th></th>
                </tr>
            </thead>
            <?php 
                    $select = "SELECT * FROM jobs
                    INNER JOIN company
                    ON jobs.comp_id = company.id ORDER BY jobs.id DESC";
                    $result = mysqli_query($conn, $select);
                    while($rows = mysqli_fetch_array($result)){
                        if($rows['position'] == $rows['total_intern']){?>
                    <?php
                    }else{?>
                        <tbody id="myTable">
                            <tr>
                            <td><?php echo $rows['job_title'] ?></td>
                            <td><?php echo $rows['companyname'] ?></td>
                            <td><?php echo $rows['email'] ?></td>
                            <td><?php echo $rows['contact'] ?></td>
                            <td><?php echo $rows['address'] ?></td>
                            <td><a class="btn text-success" href="?inc=company-info&comp_id=<?php echo $rows['id'] ?>&job_title=<?php echo $rows['job_title'] ?>">Show more</a></td>
                            </tr>
                        </tbody>
                    <?php
                    }
                }
                ?>
        </table>
    </div>
</div>