<div class="page-title">
    <h4>Search for Company</h4>
</div>

<div class="row">
    <div class="col-md-12">
        <hr>
        <table class="table table-hover table-sm">
            <thead class="text-secondary">
                <tr>
                <th scope="col">Company Name</th>
                <th scope="col">Address</th>
                <th scope="col">Position</th>
                <th></th>
                </tr>
            </thead>
            <?php 
                    $select = "SELECT * FROM company";
                    $result = mysqli_query($conn, $select);
                    while($rows = mysqli_fetch_array($result)){?>
                    <tbody>
                        <tr>
                        <td><?php echo $rows['companyname'] ?></td>
                        <td><?php echo $rows['address'] ?></td>
                        <td><?php echo $rows['position'] ?></td>
                        <td><a class="btn text-success" href="?inc=company-info&comp_id=<?php echo $rows['id'] ?>">Show more</a></td>
                        </tr>
                    </tbody>
                <?php
                    }
                ?>
        </table>
    </div>
</div>