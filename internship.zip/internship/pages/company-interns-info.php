<div id="request-info" class="container-fluid">
<h2 class="text-secondary uppercase"><i class="fa fa-user" aria-hidden="true"></i> Interns information / Records</h2>
    <div class="row mt-4">
        <div class="col-md-4 info">
            <?php 
                $id = $_GET['id'];
                $select = "SELECT * FROM interns WHERE id = '$id' ";
                $result = mysqli_query($conn, $select);
                while($rows = mysqli_fetch_array($result)){?>
                    <div class="background-avatar avatar text-center">
                        <img src="../assets/avatar/<?php echo $rows['id'].$rows['firstname'].'.jpg' ?>" alt="">
                    </div>
                    <div class="name mt-4">
                        <h3 class="text-success"><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname']?></h3>
                        <small>Intern Name</small>
                    </div>
                    <hr>
                    <div class="d-flex">
                        <div class="age w-50">
                            <h6><?php echo $rows['age']?></h6>
                            <small>Age</small>
                        </div> 
                        <hr>
                        <div class="gender w-50">
                            <h6><?php echo $rows['gender']?></h6>
                            <small>Gender</small>
                        </div> 
                    </div>
                    <hr>
                    <div class="email">
                        <h6><?php echo $rows['email']?></h6>
                        <small>Email Address</small>
                    </div>  
                    <hr>
                    <div class="address">
                        <h6><?php echo $rows['address']?></h6>
                        <small>Address</small>
                    </div>  
                <?php
                    }
            ?>
        </div>
        <div class="col-md-8">
            <?php 
                $id = $_GET['id'];
                $select = "SELECT s.hours, s.instructor, s.company, i.firstname, i.middlename, i.lastname, c.companyname
                            FROM interns s INNER JOIN instructor i 
                            ON s.instructor = i.id INNER JOIN company c
                            ON s.company = c.id ";
                $result = mysqli_query($conn, $select);
                if($rows = mysqli_fetch_array($result)){?>
                    <div class="d-flex info">
                        <div class="age w-50">
                            <h6><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname']?></h6>
                            <small>Instructor</small>
                        </div> 
                        <hr>
                        <div class="gender w-50">
                            <h6>Hour: <?php echo $rows['hours']?></h6>
                            <small>Hours Completed</small>
                        </div> 
                    </div>
                    <hr>
                <?php
                    }
            ?>
            <div class="page-title mt-4">
                <h4 class="text-info">Intern Task Reports</h4>
            </div>
            <div class="row mt-4">
                <div class="col-md-12">
                    <div class="page-title">
                        <div class="task-list d-flex">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <a class="" id="list-tab" data-bs-toggle="tab" data-bs-target="#list" type="button" role="tab" aria-controls="list" aria-selected="true">Task Reports</a>
                                <a class="" id="task-tab" data-bs-toggle="tab" data-bs-target="#task" type="button" role="tab" aria-controls="task" aria-selected="false">Log Records</a>
                            </ul>
                        </div>
                    </div>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade" id="task" role="tabpanel" >
                            <div class="row task-table">
                                <div class="col-md-12 h-5 overflow border">
                                    <table class="table table-hover table-sm">
                                        <thead class="text-dark">
                                            <tr>
                                            <th scope="col">Date</th>
                                            <th scope="col">In</th>
                                            <th scope="col">Out</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php 
                                                $id = $_GET['id'];
                                                $select = "SELECT * FROM time_in WHERE intern_id = '$id' ";
                                                $result = mysqli_query($conn, $select);
                                                while($rows = mysqli_fetch_array($result)){?>
                                                    <tr>
                                                    <td><?php echo $rows['date'] ?></td>
                                                    <td><?php echo $rows['timein'] ?></td>
                                                    <td><?php echo $rows['timeout'] ?></td>
                                                    </tr>
                                            <?php
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade show active" id="list" role="tabpanel">
                            <div class="row comp-interns">
                                <div class="col-md-12 h-5 overflow border">
                                <table class="table table-hover table-sm">
                                    <thead class="text-dark">
                                        <tr>
                                        <th scope="col">Task Name</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">Due Date</th>
                                        <th scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <?php 
                                            $id = $_GET['id'];
                                            $select = "SELECT * FROM task WHERE intern_id = '$id' ";
                                            $result = mysqli_query($conn, $select);
                                            while($rows = mysqli_fetch_array($result)){?>
                                            <tbody>
                                                <tr>
                                                <td><?php echo $rows['task_title'] ?></td>
                                                <td><?php echo $rows['description'] ?></td>
                                                <td><?php echo $rows['due_date'] ?></td>
                                                <td><?php echo $rows['status'] ?></td>
                                                </tr>
                                            </tbody>
                                        <?php
                                            }
                                        ?>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>   
        </div>
    </div>
</div>
