<div class="page-title">
    <h4>My Task Progress</h4>
    <hr>
</div>

<div class="task_upload">
    <form action="../php/task-upload.php" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col-md-6">
                <label for="">Task Title:</label>
                <input class="form-control" type="hidden" name="intern_id" value="<?php echo $_SESSION['log'] ?>">
                <?php
                    $id = $_SESSION['log'];
                    $select = mysqli_query($conn, "SELECT * FROM interns WHERE id = '$id' ");
                    $row = mysqli_fetch_array($select);
                    if($row){?>
                        <input class="form-control" type="hidden" name="comp_id" value="<?php echo $row['company'] ?>">
                <?php
                    }
                ?>
                <input class="form-control" type="text" name="desc" required>
            </div>
            <div class="col-md-6 text-end mt-4">
                <input type="submit" name="task" class="btn btn-success" value="Upload Task">
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-6">
                <label for="">Task Description:</label>
                <input class="form-control" type="text" name="progress" required>
            </div>
            <div class="col-md-3">
                <label for="">Task due date:</label>
                <input class="form-control" type="date" name="duedate" required>
            </div>
            <div class="col-md-3">
                <label for="">Task status:</label>
                <select class="form-control" name="status" id="" required>
                    <option value="ongoing">Ongoing</option>
                    <option value="done">Done</option>
                </select>
            </div>
        </div>
        <div class="document mt-4">
            <h6>Select Image For Documentation</h6>
            <div class="row">
                <div class="col-md-3">
                    <input class="taskfile" type="file" name="fileToUpload" accept="image/png, image/gif, image/jpeg" required>
                </div>
            </div>
        </div>
    </form>
</div>