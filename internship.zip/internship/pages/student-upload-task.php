<div class="page-title">
    <h4>My Task Progress</h4>
    <hr>
</div>

<div class="task_upload">
    <form action="../php/task-upload.php" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col-md-6">
                <label for="">Task Description:</label>
                <input class="form-control" type="hidden" name="intern_id" value="<?php echo $_SESSION['log'] ?>">
                <?php
                    $id = $_SESSION['log'];
                    $select = mysqli_query($conn, "SELECT * FROM interns WHERE id = '$id' ");
                    $row = mysqli_fetch_array($select);
                    if($row){?>
                        <input class="form-control" type="hidden" name="comp_id" value="<?php echo $row['company'] ?>">
                <?php
                    }
                ?>
                <input class="form-control" type="text" name="desc">
            </div>
            <div class="col-md-6 text-end">
                <input type="submit" name="task" class="btn btn-info" value="Upload Task Progress">
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-6">
                <label for="">Task progress:</label>
                <input class="form-control" type="text" name="progress">
            </div>
            <div class="col-md-3">
                <label for="">Task due date:</label>
                <input class="form-control" type="date" name="duedate">
            </div>
            <div class="col-md-3">
                <label for="">Task status:</label>
                <select class="form-control" name="status" id="">
                    <option value="ongoing">Ongoing</option>
                    <option value="done">Done</option>
                </select>
            </div>
        </div>
        <div class="document mt-4">
            <h6>Documents File</h6>
            <div class="row">
                <div class="col-md-3">
                    <input class="taskfile" type="file" name="fileToUpload">
                </div>
            </div>
        </div>
        
    </form>
</div>