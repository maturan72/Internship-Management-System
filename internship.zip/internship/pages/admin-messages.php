<div class="page-title">
    <h4 class="uppercase">Messages</h4>
</div>
<div class="messages" id="message">
    <div class="row border b-r-10">
        <div class="col-md-5 mt-4">
            <div class="message-data overflow-5">
                <?php
                    $select_message = mysqli_query($conn, "SELECT * FROM messages ORDER BY id DESC");
                    while($rows = mysqli_fetch_array($select_message)){?>
                    <a class="data text-decor-none" href="?inc=messages&mess_id=<?php echo $rows['id'] ?>">
                        <h6 class="uppercase m-0 text-black"><?php echo $rows['fullname'] ?></h6>
                        <small class="text-secondary">Full Name</small>
                    </a>
                    <hr class="text-secondary">
                <?php
                    }
                ?>
            </div>
        </div>
        <div class="col-md-7 bg-white">
            <?php
                $mess_id = $_GET['mess_id'];
                if(!$_GET['mess_id']){?>
                    <div class="text-center mt-4 text-secondary">
                        <h4>No Message Selected!</h4>
                    </div>
            <?php
                }else{
                    $message_content = mysqli_query($conn, "SELECT * FROM messages WHERE id ='$mess_id'");
                    if($data = mysqli_fetch_array($message_content)){?>
                    <div class="name mt-4">
                        <h6 class="m-0 f-bold"><?php echo $data['fullname'] ?></h6>
                        <small class="text-secondary">Date Submmited:  <span class="ml-2"><?php echo $data['message_date'] ?></span></small>
                        <hr class="text-secondary">
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="m-0"><?php echo $data['email'] ?></h6>
                            <small class="text-secondary">Email Address</small>
                            <hr class="text-secondary">
                        </div>
                        <div class="col-md-6">
                            <h6 class="m-0"><?php echo $data['contactno'] ?></h6>
                            <small class="text-secondary">Contact Number</small>
                            <hr class="text-secondary">
                        </div>
                    </div>
                    <div class="messages_content">
                        <h5><?php echo $data['message'] ?></h5>
                        <small class="text-secondary">Message Content</small>
                        <hr class="text-secondary">
                    </div>
                    <div class="remove text-end">
                        <a class="btn btn-danger" href="../php/message-remove.php?id=<?php echo $data['id'] ?>">Delete Message</a>
                    </div>
                <?php
                    }
                }
            ?>
        </div>
    </div>
</div>
