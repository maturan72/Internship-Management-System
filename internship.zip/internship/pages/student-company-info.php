<div id="request-info" class="container-fluid">
    <h4 class="uppercase text-secondary"> <i class="fa fa-buiding" aria-hidden="true"></i> Company information</h4>
    <div class="row mt-4">
        <div class="col-md-4 info">
            <?php 
                $id = $_GET['comp_id'];
                $select = "SELECT * FROM company WHERE id = '$id' ";
                $result = mysqli_query($conn, $select);
                while($rows = mysqli_fetch_array($result)){?>
                    <div class="background-avatar avatar text-center">
                        <img src="../assets/avatar/<?php echo $rows['id'].$rows['firstname'].'.jpg' ?>" alt="">
                    </div>
                    <div class="name mt-4">
                        <h3 class="text-success"><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname']?></h3>
                        <small>Supervisor Name</small>
                    </div>
                    <hr>
                    <div class="company">
                        <h6><?php echo $rows['email']?></h6>
                        <small>Email Address</small>
                    </div>  
                    <hr>
                    <div class="company">
                        <h6><?php echo $rows['companyname']?></h6>
                        <small>Company Name</small>
                    </div>  
                    <hr>
                    <div class="company">
                        <h6><?php echo $rows['address']?></h6>
                        <small>Company Address</small>
                    </div> 
            <?php
                }
            ?>
        </div>
        <div class="col-md-8">
            <div class="recent-registration">
                <div class="row comp-interns">
                    <div class="col-md-12 h-4 overflow">
                        <div class="row">
                            <div class="col-md-6">
                                <?php
                                    $job_title = $_GET['job_title'];
                                    $select_job = mysqli_query($conn, "SELECT * FROM jobs WHERE job_title ='$job_title' ");
                                    while($row = mysqli_fetch_array($select_job)){?>
                                    <div class="title text-secondary">
                                        <h4 class="uppercase"><?php echo $row['job_title'] ?></h4>
                                        <small>Job Title</small>
                                        <hr class="margin-0">
                                    </div>
                                    <div class="desc text-secondary">
                                        <p ><?php echo $row['job_desc'] ?></p>
                                        <small>Job Description</small>
                                        <hr class="margin-0">
                                    </div>
                                    <div class="title text-secondary">
                                        <p class="uppercase"><?php echo $row['position'] ?></p>
                                        <small>Job Postion</small>
                                        <hr class="margin-0">
                                    </div>
                                <?php
                                    }
                                ?>
                            </div>
                            <div class="col-md-6 text-end">
                                <form action="../php/apply.php" method="post">
                                    <?php 
                                        $id = $_SESSION['log'];
                                        $select = mysqli_query($conn,"SELECT * FROM interns WHERE id = '$id' ");
                                        $row = mysqli_fetch_assoc($select);

                                        if($row['company'] != ""){?>
                                           
                                    <?php
                                        }else{?>
                                            <input type="hidden" name="comp_id" value="<?php echo $_GET['comp_id']?>">
                                            <input type="hidden" name="job_title" value="<?php echo $_GET['job_title']?>">
                                            <input type="submit" class="btn btn-info" name="apply" value="Submit Application">
                                    <?php
                                        }
                                    ?>

                                </form>
                            </div>
                        </div>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
