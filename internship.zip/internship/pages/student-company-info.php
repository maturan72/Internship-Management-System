<div id="request-info" class="container-fluid">
    <h1>Company information / Records</h1>
    <div class="row mt-4">
        <div class="col-md-4 info">
            <?php 
                $id = $_GET['comp_id'];
                $select = "SELECT * FROM company WHERE id = '$id' ";
                $result = mysqli_query($conn, $select);
                while($rows = mysqli_fetch_array($result)){?>
                    <div class="background-avatar avatar">
                        <img src="../assets/avatar/<?php echo $rows['id'].$rows['firstname'].'.jpg' ?>" alt="">
                    </div>
                    <div class="name mt-4">
                        <h3 class="text-success"><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname']?></h3>
                        <small>Supervisor Name</small>
                    </div>
                    <hr>
                    <div class="company">
                        <h6><?php echo $rows['email']?></h6>
                        <small>Email Address</small>
                    </div>  
                    <hr>
                    <div class="company">
                        <h6><?php echo $rows['companyname']?></h6>
                        <small>Company Name</small>
                    </div>  
                    <hr>
                    <div class="company">
                        <h6><?php echo $rows['address']?></h6>
                        <small>Company Address</small>
                    </div> 
            <?php
                }
            ?>
        </div>
        <div class="col-md-8">
            <div class="recent-registration">
                <div class="row comp-interns">
                    <div class="col-md-12 h-4 overflow">
                        <div class="row">
                            <div class="col-md-6">
                                <h5 class="f-bold text-info">List Of Interns</h5>
                            </div>
                            <div class="col-md-6 text-end">
                                <form action="../php/apply.php" method="post">
                                    <?php 
                                        $id = $_SESSION['log'];
                                        $select = mysqli_query($conn,"SELECT * FROM interns WHERE id = '$id' ");
                                        $row = mysqli_fetch_assoc($select);

                                        if($row['company'] != ""){?>
                                            <!-- <input type="hidden" name="comp_id" value="<?php echo $_GET['comp_id']?>">
                                            <input type="hidden" name="int_id" value="<?php echo $_SESSION['log']?>">
                                            <input type="submit" class="btn btn-info" name="apply" value="Change Company"> -->
                                    <?php
                                        }else{?>
                                            <input type="hidden" name="comp_id" value="<?php echo $_GET['comp_id']?>">
                                            <input type="submit" class="btn btn-info" name="apply" value="Submit Application">
                                    <?php
                                        }
                                    ?>

                                </form>
                            </div>
                        </div>
                        <hr>
                        <table class="table table-hover table-sm">
                            <thead class="text-dark">
                                <tr>
                                <th scope="col">Full Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">address</th>
                                </tr>
                            </thead>
                            <?php 
                                $id = $_GET['comp_id'];
                                $select = "SELECT * FROM interns WHERE company = '$id' ";
                                $result = mysqli_query($conn, $select);
                                while($rows = mysqli_fetch_array($result)){?>
                                <tbody>
                                    <tr>
                                    <td class="uppercase"><?php echo $rows['firstname'] .' '. $rows['middlename'][0] .' '. $rows['lastname'] ?></td>
                                    <td><?php echo $rows['email'] ?></td>
                                    <td><?php echo $rows['address'] ?></td>
                                    </tr>
                                </tbody>
                            <?php
                                }
                            ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
