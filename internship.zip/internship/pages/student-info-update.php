<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-user" aria-hidden="true"></i> My Information</h4>
    <hr>
    <form action="../php/intern_update.php" method="post">
        <?php
            $id = $_SESSION['log'];
            $instructor_data = "SELECT * FROM interns WHERE id = '$id'";
            $ins_result = mysqli_query($conn, $instructor_data);
            while($data = mysqli_fetch_array($ins_result)){
                ?>
        <div class="row information">
        <div class="col-md-4 background-avatar text-center">
            <img src="../assets/avatar/<?php echo $data['id'].$data['firstname'].'.jpg' ?>" alt="">
        </div>
        <div class="col-md-8">
            <div class="">
                    <div class="Instructor info">
                        <div class="row">
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="fname" value="<?php echo $data['firstname']?>" required>
                                <small class="text-secondary">First Name</small>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="mname" value="<?php echo $data['middlename']?>" required>
                                <small class="text-secondary">Middlename Name</small>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="lname" value="<?php echo $data['lastname']?>" required>
                                <small class="text-secondary">last Name</small>
                            </div>
                        </div>
                        
                    </div>  
                        <hr> 
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="age">
                                        <input class="form-control" type="number" name="age" value="<?php echo $data['age']?>" required>
                                        <small class="text-secondary">Age</small>
                                    </div> 
                                </div>
                                <div class="col-md-4">
                                    <div class="gender">
                                        <input class="form-control" type="text" name="gender" value="<?php echo $data['gender']?>" required>
                                        <small class="text-secondary">Gender</small>
                                    </div> 
                                </div>
                                <div class="col-md-4">
                                    <div class="contact">
                                        <input class="form-control" type="text" name="contact" value="<?php echo $data['contact']?>" required>
                                        <small class="text-secondary">Contact Number</small>
                                    </div> 
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="gender">
                                        <input class="form-control" type="text" name="course" value="<?php echo $data['course']?>" required>
                                        <small class="text-secondary">course</small>
                                    </div> 
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="address">
                                        <input class="form-control" type="text" name="address" value="<?php echo $data['address']?>" required>
                                        <small class="text-secondary">Current Address</small>
                                    </div> 
                                </div>
                                <div class="col-md-6">
                                    <div class="email">
                                        <input class="form-control" type="text" name="email" value="<?php echo $data['email']?>" required>
                                        <small class="text-secondary">Email Address</small>
                                    </div> 
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="skill">
                                        <input class="form-control" type="text" name="skills" value="<?php echo $data['skills']?>" required>
                                        <small class="text-secondary">Intern Skills</small>
                                    </div> 
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="email">
                                        <input class="form-control" type="password" name="password" value="<?php echo $data['password']?>" required>
                                        <small class="text-secondary">Old Password</small>
                                    </div> 
                                </div>
                                <div class="col-md-6">
                                    <div class="address">
                                        <input class="form-control" type="password" name="newpassword" value="">
                                        <small class="text-secondary">New Password (optional)</small>
                                    </div> 
                                </div>
                            </div>
                            <hr>
                        </div>
                    </div> 
                    <div class="update text-end mt-4">
                        <input class="form-control" type="hidden" name="id" value="<?php echo $data['id']?>" required>
                        <input type="submit" class="btn btn-success" name="int_upd" value="Update Information">
                    </div>
                </div>
        </div>
        </div>
        <?php
            }
        ?>
    </form>
</div>