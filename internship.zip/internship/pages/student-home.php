<div class="page-title">
    <h4>Home</h4>
    <h1>Welcome back, John</h1>
    <div class="records d-flex">
        <!-- <h6><a class="text-decor-none text-black" href="">Weekly Reports</a></h6> -->
        <h6>Task Completed: 
            <span> 
                <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM task WHERE intern_id = '$id' AND status = 'done' ";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </span>
        </h6>
        <h6>Hours Completed: 
            <span> 
                <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM interns WHERE id = '$id' ";
                    $result = mysqli_query($conn, $select);
                    $data = mysqli_fetch_array($result);
                    echo $data['hours'];
                ?>
            </span>
        </h6>
    </div>
</div>
<div class="row column-row">
    <div class="col-md-12">
        <h3>Recent task</h3>
        <hr>
        <table class="table table-hover table-sm">
            <thead class="text-dark">
                <tr>
                <th scope="col">Task Description</th>
                <th scope="col">Progress</th>
                <th scope="col">due date</th>
                <th scope="col">Status</th>
                </tr>
            </thead>
            <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM task WHERE intern_id = '$id' ";
                    $result = mysqli_query($conn, $select);
                    
                    while($rows = mysqli_fetch_array($result)){?>
                    
                    <tbody>
                        <tr>
                        <td><?php echo $rows['task_description'] ?></td>
                        <td><?php echo $rows['progress'] ?></td>
                        <td><?php echo $rows['due_date'] ?></td>
                        <td><?php echo $rows['status'] ?></td>
                        </tr>
                    </tbody>
                <?php
                    }
                ?>
        </table>
    </div>
</div>