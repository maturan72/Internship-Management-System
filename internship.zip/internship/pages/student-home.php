<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-home" aria-hidden="true"></i> Home</h4>
</div>
<div class="container h-1vh overflow">
        <div class="text-center">
            <h2 class="uppercase text-secondary">Task Timeline</h2>
        </div>
    <div class="timeline text-white">
        <?php
            $log_id = $_SESSION['log'];
            $select_task = mysqli_query($conn, "SELECT * FROM task WHERE intern_id = '$log_id' ");

            while ($rows = mysqli_fetch_array($select_task)) {?>
                <div class="timeline-row">
                    <div class="timeline-time">
                        <?php echo $rows['date_submitted']?>
                    </div>
                    <div class="timeline-content">
                        <i class="icon-attachment"></i>
                        <h4><?php echo $rows['task_title']?></h4>
                        <p><?php echo $rows['description']?></p>
                        <div class="">
                            <img class="img-fluid rounded" src="../assets/tasks/<?php echo $rows['documents']?>" alt="Maxwell Admin">
                        </div>
                        <!-- <div class="">
                            <span class="badge badge-pill">Sales</span>
                            <span class="badge badge-pill">Admin</span>
                        </div> -->
                    </div>
                </div>
        <?php
            }
        ?>
	</div>
</div>