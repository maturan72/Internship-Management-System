<div class="page-title">
    <h4>Dashboard</h4>
    <h1>Welcome, Admin</h1>
</div>
<div class="row total-count">
    <div class="cards col-md-3">
        <div class="card-body cb-1 d-flex align-items-center">
            <div class="count">
                <h6 class="">Administrator</h6>
                <?php 
                    $select = "SELECT * FROM admin";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo "<h5 class='f-bold'>$row</h5>"
                ?>
            </div>
        </div>
    </div>
    
    <div class="cards col-md-3">
        <div class="card-body cb-2 d-flex align-items-center">
            <div class="count">
                <h6 class="">Registered Company</h6>
                <?php 
                    $select = "SELECT * FROM company";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo "<h5 class='f-bold'>$row</h5>"
                ?>
            </div>
        </div>
    </div>
    <div class="cards col-md-3">
        <div class="card-body cb-3 d-flex align-items-center">
            <div class="count">
                <h6 class="">Project Head</h6>
                <?php 
                    $select = "SELECT * FROM instructor";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo "<h5 class='f-bold'>$row</h5>"
                ?>
            </div>
        </div>
    </div>
    <div class="cards col-md-3">
        <div class="card-body cb-4 d-flex align-items-center">
            <div class="count">
                <h6 class="">Interns Student</h6>
                <?php 
                    $select = "SELECT * FROM interns";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo "<h5 class='f-bold'>$row</h5>"
                ?>
            </div>
        </div>
    </div>
    <hr>
</div>
<div class="row">
    <div class="recent-registration col-md-12">
        <div class="row notif-table">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-6">
                        <h5 class="f-bold text-secondary">Approval</h5>
                    </div>
                </div>
                <hr>
                <div id="approvals" class="container-fluid">
                    <div class="container">
                        <div class="row">
                            <?php
                            $pending = "SELECT * FROM pending_registration";
                            $result = mysqli_query($conn, $pending);
                            $count = mysqli_num_rows($result);
                            if($count == 0){?>
                                <h3 class="text-secondary">No Request Found</h3>
                            <?php
                            }else{
                                while($rows = mysqli_fetch_array($result)){
                                $id = $rows['id'];
                                $data = json_decode($rows['data']);
                            ?>
                        
                            <div class="approval-content col-md-4">
                                <div class="content">
                                    <div class="d-flex flex">
                                        <?php
                                            if($data->type == 'intern'){?>
                                                <div class="type flex-fill bg-warning">
                                                    <?php echo $data->type; ?>
                                                </div>
                                                <div class="show text-end flex-fill">
                                                    <a href="?inc=request-info&id=<?php echo $rows['id'] ?>">Show More</a>
                                                </div>
                                        <?php
                                            }
                                            elseif($data->type == 'company'){?>
                                                <div class="type flex-fill bg-success">
                                                    <?php echo $data->type; ?>
                                                </div>
                                                <div class="show text-end flex-fill">
                                                    <a href="?inc=request-info&id=<?php echo $rows['id'] ?>">Show More</a>
                                                </div>
                                        <?php
                                            }
                                            else{?>
                                                <div class="type flex-fill bg-info">
                                                    <?php echo $data->type; ?>
                                                </div>
                                                <div class="show text-end flex-fill">
                                                    <a href="?inc=request-info&id=<?php echo $rows['id'] ?>">Show More</a>
                                                </div>
                                        <?php
                                            }
                                        ?>
                                    </div>
                                    <?php
                                        $imglink = '../assets/avatar/'.$rows['id'].$rows['firstname'].'.jpg';
                                        if(@getimagesize($imglink)){?>
                                            <div class="image table-avatar text-center">
                                                <img src="../assets/avatar/<?php echo $rows['id'].$rows['firstname'].'.jpg' ?>" alt="">
                                            </div>
                                    <?php
                                        }else{?>
                                            <div class="image text-center">
                                                <img src="../assets/images/user2.png">
                                            </div>
                                    <?php
                                        }
                                    ?>
                                    
                                    <div class="name text-center mt-4">
                                        <h5><?php echo $data->firstname.' '.$data->middlename[0].' '.$data->lastname ?></h5>
                                    </div>
                                    <div class="info mt-4">
                                        <p>Email: <?php echo $data->email ?></p>
                                        <p>Address: <?php echo $data->address ?></p>
                                    </div>
                                    <div class="row buttons">
                                        <div class="col-md-6 text-center pl-0 pr-0">
                                            <a class="but-accept" href="../php/request.php?data=<?php echo $rows['id'] ?>"><li class="fa border text-success form-control fa-check"><span>Aprrove</span></li></a>
                                        </div>
                                        <div class="col-md-6 text-center pl-0 pr-0">
                                            <a class="but-delete" href="../php/delete-request.php?del=<?php echo $rows['id'] ?>"><li class="fa border text-danger form-control fa-times"><span>Reject</span></li></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php

                                }
                            }

                            ?>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
