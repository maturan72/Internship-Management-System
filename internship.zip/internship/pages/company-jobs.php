<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-list" aria-hidden="true"></i> My Jobs List</h4>
</div>
<div class="row">
        <div class="upload-task text-end">
            <input class="w-50 form-control input-search" type="text" id="myInput" placeholder="Search for Records..">
            <a href="" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#postmodal">Post New Jobs</a>
            <div class="modal fade" id="postmodal" tabindex="-1" aria-labelledby="postmodalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <form action="../php/new_job.php" method="POST">
                        <div class="modal-header">
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body text-start">
                                
                                <h4 class="uppercase text-secondary">Create New Job</h4>
                                <hr class="margin-0">
                                <div class="title">
                                    <input class="form-control" type="text" name="title" placeholder="Enter Job Title!" required>
                                    <small class="text-secondary">Job Title</small>
                                    <hr class="margin-0">
                                </div>
                                <div class="desc">
                                    <input class="form-control" type="text" name="desc" placeholder="Enter Job Description!" required>
                                    <small class="text-secondary">Job Description</small>
                                    <hr class="margin-0">
                                </div>
                                <div class="position">
                                    <input class="form-control" type="number" name="position" placeholder="Enter Job Position Vacancies" required>
                                    <small class="text-secondary">Job Position Needed</small>
                                    <hr class="margin-0">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <input class="btn btn-success" type="submit" name="add_job" value="Submit New Job">
                                <button id="stop_button" type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <table class="table table-hover table-sm mt-4" id="find-table">
        <thead class="text-secondary ">
            <tr>
            <th scope="col">Job Title</th>
            <th scope="col">Description</th>
            <th scope="col">Positions</th>
            <th scope="col">Total Intern</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php 
            $id = $_SESSION['log'];
            $select = "SELECT * FROM jobs WHERE comp_id = '$id' GROUP BY job_title";
            $result = mysqli_query($conn, $select);
            while($rows = mysqli_fetch_array($result)){
                $job_id = $rows['id'];
                ?>
                <tr class="bg-lightgray">
                <td><?php echo $rows['job_title']?></td>
                <td><?php echo $rows['job_desc'] ?></td>
                <td><?php echo $rows['position'] ?></td>
                <td><?php echo $rows['total_intern'] ?></td>
                <td><a class="text-success text-decor-none" href="?inc=job-list&id=<?php echo $job_id?>"> Show List</a></td>
                </tr>
        <?php
            }
        ?>
        </tbody>
    </table>
</div>

