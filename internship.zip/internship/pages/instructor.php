<?php include "../includes/instructor/header.php" ?>

  <!-- Begin Page Content -->
  <div class="page-content container-fluid">
        <?php 
            if ($_GET['inc']){
                $inc = 'instructor-' . $_GET['inc'] . '.php';
                include $inc;
            }else{
                include "instructor-dashboard.php";
            }
        ?>
  </div>

</div>

    
<?php include "../includes/instructor/footer.php" ?>