<div class="page-title">
    <h4>Home</h4>
</div>
<div class="row total-count">
    <div class="cards col-md-3">
        <div class="card-body cb-1 d-flex align-items-center">
            <div class="count">
                <h6 class="">Interns</h6>
                <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM interns WHERE instructor = '$id'";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </div>
        </div>
    </div>
</div>
<div class="recent-registration">
    <div class="row">
        <div class="col-md-12 overflow-4">
            <div class="row">
                <div class="col-md-6">
                    <h5 class="f-bold text-secondary uppercase">Recent Progress Of My Interns</h5>
                </div>
                <div class="col-md-6 text-end">
                    <form action="instructor.php?inc=progress" method="post">
                        <div class="row">
                            <div class="col-md-7">
                                <select class="form-control text-secondary" name="user" >
                                    <option value="">Search For Intern</option>
                                <?php
                                    $id = $_SESSION['log'];
                                    $select = "SELECT * FROM interns WHERE instructor = '$id'";
                                    $result = mysqli_query($conn, $select);
                                    while($row = mysqli_fetch_array($result)){?>
                                    <option class="text-black" value="<?php echo $row['id']?>"><?php echo $row['firstname'].' '.$row['middlename'][0].'. '.$row['lastname']?></option>
                                <?php
                                    }
                                ?>
                                </select>
                            </div>
                            <div class="col-md-5">
                                <input class="btn btn-success" type="submit" value="Show Intern Progress">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <hr>
            <table class="table table-hover table-sm">
                <thead class="text-dark">
                    <tr>
                    <th scope="col">Full Name</th>
                    <th scope="col">Tasks</th>
                    <th scope="col">Due Date</th>
                    <th scope="col">Company Name</th>
                    <th scope="col">Status</th>
                    <th scope="col"></th>
                    </tr>
                </thead>
                <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM interns INNER JOIN company
                    ON interns.company = company.id  INNER JOIN task
                    ON interns.id = task.intern_id WHERE instructor = '$id' ORDER BY task.id DESC LIMIT 20";
                    $result = mysqli_query($conn, $select);
                    while($rows = mysqli_fetch_array($result)){
                    ?>
                    <tbody>
                        <tr>
                        <td class="uppercase"><?php echo $rows['firstname'] .' '. $rows['middlename'][0] .' '. $rows['lastname'] ?></td>
                        <td><?php echo $rows['task_description'] ?></td>
                        <td><?php echo $rows['due_date'] ?></td>
                        <td><?php echo $rows['companyname'] ?></td>
                        <td><?php echo $rows['status'] ?></td>
                        <td></td>
                        </tr>
                    </tbody>
                <?php
                    }
                ?>
            </table>
        </div>
    </div>
</div>
