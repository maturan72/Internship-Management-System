<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-home" aria-hidden="true"></i> Home</h4>
</div>
<div class="row total-count">
    <div class="cards col-md-3">
        <div class="card-body cb-1 d-flex align-items-center">
            <div class="count">
                <h6 class="">Interns</h6>
                <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM interns WHERE instructor = '$id'";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </div>
        </div>
    </div>
</div>
<div id="approvals" class="container">
    <h4 class="uppercase text-secondary"> <i class="fa fa-user" aria-hidden="true"></i> Intern Students Request</h4>
    <div class="container">
        <div class="row">
            <div class="overflow bg-white h-5 p-20-0">
                <div class="upload-task text-end">
                    <label class="f-bold text-secondary uppercase mr-2">Seach for Intern Request</label>
                    <input class="w-50 form-control input-search" type="text" id="myInput" placeholder="Search for Records..">
                </div>
                <table class="table table-hover table-sm mt-4">
                    <thead class="text-secondary">
                        <tr>
                        <th scope="col">Full Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Contact</th>
                        <th scope="col">Address</th>
                        <th scope="col">course</th>
                        <th scope="col">section</th>
                        <th></th>
                        </tr>
                    </thead>
                    <tbody id="myTable">
                    <?php
                    $log_id = $_SESSION['log'];
                    $pending = "SELECT * FROM pending_registration";
                    $result = mysqli_query($conn, $pending);
                    $count = mysqli_num_rows($result);
                    if($count == 0){?>
                        <h3 class="text-secondary">No Request Found</h3>
                    <?php
                    }else{
                        while($rows = mysqli_fetch_array($result)){
                        $id = $rows['id'];
                        $data = json_decode($rows['data']);
                            if($data->type == 'intern' AND $data->instructor == $log_id){?>
                            <tr>
                            <td><?php echo $data->firstname .' '. $data->middlename[0] .'. '. $data->lastname  ?></td>
                            <td><?php echo $data->email ?></td>
                            <td><?php echo $data->contact?></td>
                            <td><?php echo $data->address ?></td>
                            <td><?php echo $data->course?></td>
                            <td><?php echo $data->section ?></td>
                            <td><a class="text-decor-none" href="../php/delete-request.php?instructor_del_req=<?php echo $rows['id'] ?>"><i class="fa text-danger fa-trash"><span> Reject</span></i></a> | <a class="text-decor-none" href="../php/request.php?instructor_accept_req=<?php echo $rows['id'] ?>"><i class="fa text-success fa-arrow-right"><span> Aprrove</span></i></a></td>
                            </tr>
                        <?php
                            }else{


                            }
                        }
                    }

                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>