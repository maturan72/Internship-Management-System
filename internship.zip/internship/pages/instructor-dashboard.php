<div class="page-title">
    <h4>Home</h4>
    <h1>Welcome, Admin</h1>
</div>
<div class="row total-count">
    <div class="cards col-md-3">
        <div class="card-body cb-1 d-flex align-items-center">
            <div class="count">
                <h6 class="">Interns</h6>
                <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM interns WHERE instructor = '$id'";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </div>
        </div>
    </div>
</div>
<div class="recent-registration">
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    <h5 class="f-bold text-primary">Progress Of My Interns</h5>
                </div>
            </div>
            <hr>
            <table class="table table-hover table-sm">
                <thead class="text-dark">
                    <tr>
                    <th scope="col">Full Name</th>
                    <th scope="col">Tasks</th>
                    <th scope="col">Due Date</th>
                    <th scope="col">Company Name</th>
                    <th scope="col">Status</th>
                    <th scope="col"></th>
                    </tr>
                </thead>
                <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM interns INNER JOIN company
                    ON interns.company = company.id  INNER JOIN task
                    ON interns.id = task.intern_id WHERE instructor = '$id' ";
                    $result = mysqli_query($conn, $select);
                    while($rows = mysqli_fetch_array($result)){
                    ?>
                    <tbody>
                        <tr>
                        <td class="uppercase"><?php echo $rows['firstname'] .' '. $rows['middlename'][0] .' '. $rows['lastname'] ?></td>
                        <td><?php echo $rows['task_description'] ?></td>
                        <td><?php echo $rows['due_date'] ?></td>
                        <td><?php echo $rows['companyname'] ?></td>
                        <td><?php echo $rows['status'] ?></td>
                        <td><a class="text-primary" href="instructor.php?inc=progress">Show Progress</a></td>
                        </tr>
                    </tbody>
                <?php
                    }
                ?>
            </table>
        </div>
    </div>
</div>
