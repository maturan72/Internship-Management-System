<div class="page-title">
    <h4>My Information</h4>
  <hr>
</div>
<?php
    $id = $_SESSION['log'];
    $instructor_data = "SELECT * FROM company WHERE id = '$id'";
    $ins_result = mysqli_query($conn, $instructor_data);
    while($data = mysqli_fetch_array($ins_result)){
        ?>
<div class="row information">
    <div class="col-md-4 background-avatar">
       <img src="../assets/avatar/<?php echo $data['id'].$data['firstname'].'.jpg' ?>" alt="">
   </div>
   <div class="col-md-8">
       <div class="">
            <div class="Instructor info">
                <h1 class="m-0"><?php echo $data['firstname'].' '.$data['middlename'][0].' '.$data['lastname']?></h1>
                <small class="text-secondary">Supervisor</small>
            </div>  
                <hr class="m-0"> 
            <div class="row">
                <div class="col-md-12">
                    <div class="email mt-4">
                        <h6 class="m-0"><?php echo $data['companyname']?></h6>
                        <small class="text-secondary">Company Name</small>
                    </div> 
                    <hr  class="m-0">
                    <div class="address mt-4">
                        <h6 class="m-0"><?php echo $data['address']?></h6>
                        <small class="text-secondary">Company Address</small>
                    </div> 
                    <hr  class="m-0">
                    <div class="email mt-4">
                        <h6 class="m-0"><?php echo $data['email']?></h6>
                        <small class="text-secondary">Email Address</small>
                    </div> 
                    
                </div>
            </div> 
            <div class="update text-end mt-4">
                <a href="?inc=info-update" class="btn btn-info">Update Information</a>
            </div>
        </div>
   </div>
</div>
<?php
    }
?>