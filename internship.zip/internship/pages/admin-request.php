<div class="page-title">
</div>
<div class="recent-registration">

    <div class="row notif-table">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    <h5 class="f-bold text-primary">List Of Pending Request</h5>
                </div>
                <!-- <div class="col-md-6 text-end">
                    <input type="submit" name="multiple" class="btn btn-success" value="Accept Requests">
                </div> -->
            </div>
            <hr>
            <table class="table table-hover table-sm">
                <thead class="text-dark">
                    <tr>
                    <th></th>
                    <th scope="col">Full Name</th>
                    <th scope="col">Type of registration</th>
                    <th scope="col">Action</th>
                    </tr>
                </thead>
                    <?php 
                        
                        $pending = "SELECT * FROM pending_registration";
                        $result = mysqli_query($conn, $pending);
                        
                        while($rows = mysqli_fetch_array($result)){
                            $data = explode(',', $rows['data']);
                            
                            ?>
                                <form action="../php/request.php" method="post">
                                <tbody>
                                    <tr>
                                    <td><input type="hidden" name="id" value="<?php echo $rows['id'] ?>"></td>
                                    <td><?php echo $data[1] .' '. $data[2] .' '. $data[3] ?></td>
                                    <td><?php echo $data[0] ?></td>
                                    <td><a class="btn btn-info" href="admin.php?inc=request-info&id=<?php echo $rows['id'] ?>">Show More</a> | <input class="btn btn-success" type="submit" name="single" value="Accept"></td>
                                    </tr>
                                
                                </tbody>
                                </form>
                    <?php
                            }
                        
                    ?>
            </table>
        </div>
    </div>
</div>
