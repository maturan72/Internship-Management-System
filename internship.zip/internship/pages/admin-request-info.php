<div id="request-info" class="container-fluid">
    <h1>Company Information <span><small><a class="btn text-danger border" href="?inc=dashboard">back to previous page</a></small></span></h1>
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="avatar">
                <img src="../assets/images/avatar.jpg" alt="">
            </div>
            <div class="buttons mt-4">
                <div class="row">
                    <div class="col-md-6 text-center pl-0 pr-0">
                        <a class="but-accept" href="../php/request.php?data=<?php echo $rows['id'] ?>"><li class="fa border text-success form-control fa-check"><span>Aprrove</span></li></a>
                    </div>
                    <div class="col-md-6 text-center pl-0 pr-0">
                        <a class="but-delete" href="../php/delete-request.php?del=<?php echo $rows['id'] ?>"><li class="fa border text-danger form-control fa-times"><span>Reject</span></li></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-1"></div>
        <?php
            $id = $_GET['id'];
            $select = mysqli_query($conn,"SELECT * FROM pending_registration WHERE id = '$id'");
            while($rows = mysqli_fetch_array($select)){
                $data = json_decode($rows['data']);
                ?>
                
                <?php
                    if($data->type == 'company'){?>
                        <div class="col-md-7 info">
                            <div class="name">
                                <h3><?php echo $data->firstname.' '.$data->middlename[0].' '.$data->lastname ?></h3>
                                <small>Supervisor Name</small>
                            </div>
                            <hr>
                            <div class="email">
                                <h6><?php echo $data->email ?></h6>
                                <small>Email Address</small>
                            </div>  
                            <hr>
                            <div class="company">
                                <h6><?php echo $data->company ?></h6>
                                <small>Company Name</small>
                            </div>  
                            <hr>
                            <div class="address">
                                <h6><?php echo $data->address ?></h6>
                                <small>Company address</small>
                            </div> 
                            <hr>
                            <div class="position">
                                <h6><?php echo $data->position ?></h6>
                                <small>Position Available</small>
                            </div>           
                        </div>
                <?php
                    }elseif($data->type == 'instructor'){?>
                        <div class="col-md-7 info">
                            <div class="name">
                                <h3><?php echo $data->firstname.' '.$data->middlename[0].' '.$data->lastname ?></h3>
                                <small>Supervisor Name</small>
                            </div>
                            <hr>
                            <div class="email">
                                <h6><?php echo $data->email ?></h6>
                                <small>Email Address</small>
                            </div>  
                            <hr>
                            <div class="address">
                                <h6><?php echo $data->address ?></h6>
                                <small>Instructor Address</small>
                            </div>  
                        </div>
                <?php
                    }else{?>
                        <div class="col-md-7 info">
                            <div class="name">
                                <h3><?php echo $data->firstname.' '.$data->middlename[0].' '.$data->lastname ?></h3>
                                <small>Supervisor Name</small>
                            </div>
                            <hr>
                            <div class="email">
                                <h6><?php echo $data->email ?></h6>
                                <small>Email Address</small>
                            </div>  
                            <hr>
                            <div class="gender">
                                <h6><?php echo $data->gender ?></h6>
                                <small>Gender</small>
                            </div>
                            <hr>
                            <div class="course">
                                <h6><?php echo $data->course ?></h6>
                                <small>Course</small>
                            </div> 
                            <hr>
                            <div class="address">
                                <h6><?php echo $data->address ?></h6>
                                <small>Intern Address</small>
                            </div>
                            <hr>
                            <div class="skill">
                                <h6><?php echo $data->skill ?></h6>
                                <small>Skills</small>
                            </div>
                        </div>
                <?php
                    }
                ?>
        <?php
            }
        ?>
    </div>
</div>
