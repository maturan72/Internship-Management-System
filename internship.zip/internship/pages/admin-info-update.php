<!-- <div class="admin-info">
    <div class="admin-update">
        
    <?php
                $id = $_SESSION['log'];
                $instructor_data = "SELECT * FROM instructor WHERE id = '$id'";
                $ins_result = mysqli_query($conn, $instructor_data);
                while($data = mysqli_fetch_array($ins_result)){
                    ?>
                    <div class="box-content">
                        <h4 class="f-bold text-primary">Instructor Information:</h4>
                        
                        <div class="row mt-4">
                            <div class="col-md-5">
                                <label for=""><strong>First Name:</strong></label>
                                <input class="form-control" required type="text" name="fname" value="<?php echo $data['firstname']?>">
                            </div>
                            <div class="col-md-2">
                                <label for=""><strong>Middle Name:</strong></label>
                                <input class="form-control" required type="text" name="mname" value="<?php echo $data['middlename']?>">
                            </div>
                            <div class="col-md-5">
                                <label for=""><strong>Last Name:</strong></label>
                                <input class="form-control" required type="text" name="lname" value="<?php echo $data['lastname']?>">
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="col-md-12">
                                    <label for=""><strong>Address:</strong></label>
                                    <input class="form-control" required type="text" name="address" value="<?php echo $data['address']?>">
                                </div>
                                <div class="col-md-12">
                                    <div class="email mt-4">
                                        <label for=""><strong>Email Address:</strong></label>
                                        <input class="form-control" required type="email" name="email" value="<?php echo $data['email']?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="col-md-12">
                                    <div class="email">
                                        <label for=""><strong>Password:</strong></label>
                                        <input class="form-control" required type="password" name="password" value="<?php echo $data['password']?>">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="email mt-4">
                                        <label for=""><strong>Confirm Password:</strong></label>
                                        <input class="form-control" required type="password" name="confirm" value="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input class="form-control" type="hidden" required name="id" value="<?php echo $data['id']?>">
                        <div class="button mt-4 text-end">
                            <div class="col-md-12">
                                <label class="text-end">
                                    <?php
                                        if($_SESSION['pass_err']){?>
                                        <div class="text-danger">
                                            Password Don't Match!
                                        </div>
                                        
                                    <?php
                                        unset($_SESSION['pass_err']);
                                        }elseif($_SESSION['upd_succ']){?>
                                        <div class="text-success">
                                        Updated Successfully!
                                        </div>
                                    <?php
                                        unset($_SESSION['upd_succ']);
                                        }
                                    ?>
                                </label>
                            </div>
                        <input class="form-control" type="hidden" name="comp_id" value="<?php echo $data['id']?>">
                            <input type="submit" class="btn btn-success" name="comp_upd" value="Update Information">
                        </div>
                    </div>
                <?php
                }
            ?>
        
    </div>
</div> -->
<div class="page-title">
    <h4>My Information</h4>
    <hr>
    <form action="../php/admin_update.php" method="post">
        <?php
            $id = $_SESSION['log'];
            $instructor_data = "SELECT * FROM admin WHERE id = '$id'";
            $ins_result = mysqli_query($conn, $instructor_data);
            while($data = mysqli_fetch_array($ins_result)){
                ?>
        <div class="row information">
        <div class="col-md-4 background-avatar">
            <img src="../assets/avatar/<?php echo $data['id'].$data['firstname'].'.jpg' ?>" alt="">
        </div>
        <div class="col-md-8">
            <div class="">
                    <div class="Instructor info">
                        <div class="row">
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="fname" value="<?php echo $data['firstname']?>" required>
                                <small class="text-secondary">First Name</small>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="mname" value="<?php echo $data['middlename']?>" required>
                                <small class="text-secondary">Middlename Name</small>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="lname" value="<?php echo $data['lastname']?>" required>
                                <small class="text-secondary">last Name</small>
                            </div>
                        </div>
                        
                    </div>  
                        <hr> 
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="email">
                                        <input class="form-control" type="text" name="email" value="<?php echo $data['email']?>" required>
                                        <small class="text-secondary">Email Address</small>
                                    </div> 
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="email">
                                        <input class="form-control" type="password" name="password" value="<?php echo $data['password']?>" required>
                                        <small class="text-secondary">Old Password</small>
                                    </div> 
                                </div>
                                <div class="col-md-6">
                                    <div class="address">
                                        <input class="form-control" type="password" name="newpassword" value="">
                                        <small class="text-secondary">New Password (optional)</small>
                                    </div> 
                                </div>
                            </div>
                            <hr>
                        </div>
                    </div> 
                    <div class="update text-end mt-4">
                        <input class="form-control" type="hidden" name="id" value="<?php echo $data['id']?>" required>
                        <input type="submit" class="btn btn-success" name="admin_upd" value="Update Information">
                    </div>
                </div>
        </div>
        </div>
        <?php
            }
        ?>
    </form>
</div>