<div class="page-title">
    <h4>Interns Students</h4>
</div>
<div class="recent-registration">
    <div class="row comp-interns">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    <h5 class="f-bold text-primary">List Of Interns</h5>
                </div>
            </div>
            <hr>
            <table class="table table-hover table-sm">
                <thead class="text-dark">
                    <tr>
                    <th scope="col">Full Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Company</th>
                    </tr>
                </thead>
                <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT s.id, s.email, s.instructor, s.firstname, s.middlename, s.lastname, c.companyname
                    FROM interns s INNER JOIN instructor i 
                    ON s.instructor = i.id INNER JOIN company c
                    ON s.company = c.id ";
                    $result = mysqli_query($conn, $select);
                    while($rows = mysqli_fetch_array($result)){?>
                    <tbody>
                        <tr>
                        <td class="uppercase"><?php echo $rows['firstname'] .' '. $rows['middlename'][0] .' '. $rows['lastname'] ?></td>
                        <td><?php echo $rows['email'] ?></td>
                        <td><?php echo $rows['companyname'] ?></td>
                        <td><a class="btn text-success" href="instructor.php?inc=intern-info&id=<?php echo $rows['id']?>">Show More</a></td>
                        </tr>
                    </tbody>
                <?php
                    }
                ?>
            </table>
        </div>
    </div>
</div>
