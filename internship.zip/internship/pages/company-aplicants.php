<div class="page-title">
    <h4>Interns Aplications</h4>
</div>
<div class="recent-registration">
    
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <h5 class="f-bold text-primary">List Of Aplicants</h5>
            </div>
            <hr>
            <table class="table table-hover table-sm">
                <thead class="text-dark">
                    <tr>
                    <th scope="col">Full Name:</th>
                    <th scope="col">Course</th>
                    <th scope="col"></th>
                    </tr>
                </thead>
                    <?php 
                        $comp_id = $_SESSION['log'];
                        $select = "SELECT * FROM applicants WHERE company_id = '$comp_id'";
                        $result = mysqli_query($conn, $select);
                        
                        while($rows = mysqli_fetch_array($result)){
                            $intern_id = $rows['intern_id'];
                            
                            $select_interns = "SELECT * FROM interns WHERE id = '$intern_id'";
                           
                            $result_intern = mysqli_query($conn, $select_interns);
                            while($data = mysqli_fetch_array($result_intern)){
                                ?>
                                <tbody>
                                    <tr>
                                    <td class="uppercase"><?php echo $data['firstname'] .' '. $data['middlename'][0] .' '. $data['lastname'] ?></td>
                                    <td><?php echo $data['course']?></td>
                                    <td><a class="btn text-success" href="company.php?inc=aplicants-details&intern_id=<?php echo $data['id'] ?>">Show Details</a></td>
                                    </tr>
                                </tbody>
                        <?php
                            }
                        }
                    ?>
                
            </table>
        </div>
    </div>
</div>
