<div class="page-title">
    <h4>My Information</h4>
    <hr>
    <form action="../php/instructor_update.php" method="post">
        <?php
            $id = $_SESSION['log'];
            $instructor_data = "SELECT * FROM instructor WHERE id = '$id'";
            $ins_result = mysqli_query($conn, $instructor_data);
            while($data = mysqli_fetch_array($ins_result)){
                ?>
        <div class="row information">
        <div class="col-md-4 background-avatar">
            <img src="../assets/avatar/<?php echo $data['id'].$data['firstname'].'.jpg' ?>" alt="">
        </div>
        <div class="col-md-8">
            <div class="">
                    <div class="Instructor info">
                        <div class="row">
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="fname" value="<?php echo $data['firstname']?>" required>
                                <small class="text-secondary">First Name</small>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="mname" value="<?php echo $data['middlename']?>" required>
                                <small class="text-secondary">Middlename Name</small>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="lname" value="<?php echo $data['lastname']?>" required>
                                <small class="text-secondary">last Name</small>
                            </div>
                        </div>
                        
                    </div>  
                        <hr> 
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="email">
                                        <input class="form-control" type="text" name="email" value="<?php echo $data['email']?>" required>
                                        <small class="text-secondary">Email Address</small>
                                    </div> 
                                </div>
                                <div class="col-md-6">
                                    <div class="address">
                                        <input class="form-control" type="text" name="address" value="<?php echo $data['address']?>" required>
                                        <small class="text-secondary">Instructor Address</small>
                                    </div> 
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="email">
                                        <input class="form-control" type="password" name="password" value="<?php echo $data['password']?>" required>
                                        <small class="text-secondary">Old Password</small>
                                    </div> 
                                </div>
                                <div class="col-md-6">
                                    <div class="address">
                                        <input class="form-control" type="password" name="newpassword" value="">
                                        <small class="text-secondary">New Password (optional)</small>
                                    </div> 
                                </div>
                            </div>
                            <hr>
                        </div>
                    </div> 
                    <div class="update text-end mt-4">
                        <input class="form-control" type="hidden" name="id" value="<?php echo $data['id']?>" required>
                        <input type="submit" class="btn btn-success" name="ins_upd" value="Update Information">
                    </div>
                </div>
        </div>
        </div>
        <?php
            }
        ?>
    </form>
</div>