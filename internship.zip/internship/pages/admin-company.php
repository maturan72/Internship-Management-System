<div class="page-title">
    <h4>Registered Company</h4>
</div>
<div class="row total-count">
    <div class="cards col-md-3">
        <div class="card-body cb-2 d-flex align-items-center">
            <div class="count">
                <h6 class="">Registered Company</h6>
                <?php 
                    $select = "SELECT * FROM company";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo "<h5 class='f-bold'>$row</h5>"
                ?>
            </div>
        </div>
    </div>
</div>
<div id="records" class="container-fluid">
    <h1>List Of Company</h1>
    <div class="row">
        <?php
            $select = mysqli_query($conn, "SELECT * FROM company");
            while($rows = mysqli_fetch_array($select)){?>
                <div class="col-md-4  mt-4">
                    <div class="content border">
                        <div class="avatar col-avatar">
                            <img src="../assets/avatar/<?php echo $rows['id'].$rows['firstname'].'.jpg' ?>" alt="">
                        </div>
                        <div class="data">
                            <h5 class="text-primary f-bold"><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname'] ?></h5>
                            <small><?php echo $rows['companyname']?></small>
                        </div>
                    <div class="show">
                        <a class="btn text-success" href="?inc=company-info&id=<?php echo $rows['id'] ?>">Show more</a>
                    </div>
                    </div>
                </div>
               
        <?php
            }
        ?>
    </div>
</div>
