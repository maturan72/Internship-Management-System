<div class="page-title">
    <h4>My Documents</h4>
  <hr>
</div>
<div class="row document">
    <h4>Upload your documents here!</h4>
    <div id="drop_file_zone" ondrop="upload_file(event)" ondragover="return false">
        <div id="drag_upload_file">
            <p><strong>Choose a file</strong> or drop it here.</p>
            <p><input class="btn btn-info" type="button" value="Select File(s)" onclick="file_explorer();" /></p>
            <input type="file" id="selectfile" multiple />
        </div>
    </div>
    <?php
        $id = $_SESSION['log'];
        if ($handle = opendir('../assets/documents/'.$id.'/')) {

            while (false !== ($entry = readdir($handle))) {
        
                if ($entry != "." && $entry != "..") {
        
                    echo "<small><a href='' class='docummentfile'>$entry</a></smal>";
                }
            }
        
            closedir($handle);
        }
    ?>

</div>