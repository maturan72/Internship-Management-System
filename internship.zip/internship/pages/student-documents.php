<div class="page-title">
    <h4 class="uppercase text-secondary"> <i class="fa fa-folder" aria-hidden="true"></i> My Documents</h4>
  <hr>
</div>
<div class="row document">
    <div class="col-md-8">
        <h4>Upload your Documents here!</h4>
        <div id="drop_file_zone" ondrop="upload_file(event)" ondragover="return false">
            <div id="drag_upload_file">
                <p><strong>Choose a file</strong> or drop it here.</p>
                <p><input class="btn btn-info" type="button" value="Select File(s)" onclick="file_explorer();" /></p>
                <input type="file" id="selectfile" multiple />
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <h4>Documents <span class="text-secondary"><small>(Click to Download)</small></span></h4>
        <?php
            $id = $_SESSION['log'];
            $select = mysqli_query($conn, "SELECT * FROM interns WHERE id ='$id' ");

            $data = mysqli_fetch_array($select);
            $name = $data['firstname'];

            if ($handle = opendir('../assets/documents/'.$id.$name.'/')) {
                $path = $id.$name.'/';
                while (false !== ($entry = readdir($handle))) {
            
                    if ($entry != "." && $entry != "..") {?>
                    <div class="content">
                    <a href="../assets/documents/<?php echo $path.$entry ?>"><?php echo $entry?></a>
                    <br>
                    <a href="../php/remove_file.php?file_name=<?php echo $path.$entry ?>" class="fa fa-trash text-danger"> remove</a>
                    <hr class="text-secondary">
                    </div>
                <?php    
                    }
                }
            
                closedir($handle);
            }
        ?>
    </div>

</div>