<div id="request-info" class="container-fluid">
    <h1>Intern information / Records</h1>
    <div class="row mt-4">
        <div class="col-md-4 info">
            <?php 
                $id = $_GET['id'];
                $select = "SELECT * FROM interns WHERE id = '$id' ";
                $result = mysqli_query($conn, $select);
                while($rows = mysqli_fetch_array($result)){?>
                    <div class="background-avatar avatar">
                        <img src="../assets/avatar/<?php echo $rows['id'].$rows['firstname'].'.jpg' ?>" alt="">
                    </div>
                    <div class="name mt-4">
                        <h3 class="text-success"><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname']?></h3>
                        <small>Intern Name</small>
                    </div>
                    <hr>
                    <div class="d-flex">
                        <div class="age w-50">
                            <h6><?php echo $rows['age']?></h6>
                            <small>Age</small>
                        </div> 
                        <hr>
                        <div class="gender w-50">
                            <h6><?php echo $rows['gender']?></h6>
                            <small>Gender</small>
                        </div> 
                    </div>
                    <hr>
                    <div class="email">
                        <h6><?php echo $rows['email']?></h6>
                        <small>Email Address</small>
                    </div>  
                    <hr>
                    <div class="address">
                        <h6><?php echo $rows['address']?></h6>
                        <small>Address</small>
                    </div>  
                <?php
                    }
            ?>
        </div>
        <div class="col-md-8">
            
                <?php 
                    $id = $_GET['id'];
                    $select = "SELECT s.hours, s.instructor, s.company, i.firstname, i.middlename, i.lastname, c.companyname
                                FROM interns s INNER JOIN instructor i 
                                ON s.instructor = i.id INNER JOIN company c
                                ON s.company = c.id ";
                    $result = mysqli_query($conn, $select);
                    if($rows = mysqli_fetch_array($result)){?>
                        <div class="d-flex info">
                            <div class="age w-50">
                                <h6><?php echo $rows['companyname']?></h6>
                                <small>Company</small>
                            </div> 
                            <hr>
                            <div class="gender w-50">
                                <h6>Hour: <?php echo $rows['hours']?></h6>
                                <small>Hours Completed</small>
                            </div> 
                        </div>
                        <hr>
                        <div class="Instructor info">
                            
                            <h6><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname']?></h6>
                            <small>Instructor</small>
                        </div>  
                        <hr> 
                    <?php
                        }
                ?>
                
            <div class="page-title mt-4">
                <h4 class="text-info">My Task</h4>
                <div class="task-list d-flex">
                    <a href="">Finished Task</a>
                    <a href="">Ongoing Task</a>
                </div>
            </div>
            <div class="row task-table">
                <div class="col-md-12 h-2-5 overflow border">
                    <hr>
                    <table class="table table-hover table-sm">
                        <thead class="text-dark">
                            <tr>
                            <th scope="col">Task Name</th>
                            <th scope="col">progress</th>
                            <th scope="col">Due Date</th>
                            <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <?php 
                                $id = $_GET['id'];
                                $select = "SELECT * FROM task WHERE intern_id = '$id' ";
                                $result = mysqli_query($conn, $select);
                                while($rows = mysqli_fetch_array($result)){?>
                                <tbody>
                                    <tr>
                                    <td><?php echo $rows['task_description'] ?></td>
                                    <td><?php echo $rows['progress'] ?></td>
                                    <td><?php echo $rows['due_date'] ?></td>
                                    <td><?php echo $rows['status'] ?></td>
                                    </tr>
                                </tbody>
                            <?php
                                }
                            ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
