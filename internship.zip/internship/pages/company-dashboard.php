<div class="page-title">
    <h4>Dashboard</h4>
    <h1>Welcome back, John</h1>
    <div class="records d-flex">
        <h6>Weekly Reports</h6>
        <h6>Task Completed</h6>
    </div>
</div>
<div class="row total-count">
    <div class="cards col-md-3">
        <div class="card-body cb-1 d-flex align-items-center">
            <div class="count">
                <h6 class="">Interns</h6>
                <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM interns WHERE company = '$id'";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo "<h5 class='f-bold'>$row</h5>"
                ?>
            </div>
        </div>
    </div>
    
    <div class="cards col-md-3">
        <div class="card-body cb-2 d-flex align-items-center">
            <div class="count">
                <h6 class="">Task Done</h6>
                <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM task WHERE comp_id = '$id' AND status = 'done' ";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo "<h5 class='f-bold'>$row</h5>"
                ?>
            </div>
        </div>
    </div>
    <div class="cards col-md-3">
        <div class="card-body cb-3 d-flex align-items-center">
            <div class="count">
                <h6 class="">Task Ongoing</h6>
                <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM task WHERE comp_id = '$id' AND status = 'ongoing' ";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo "<h5 class='f-bold'>$row</h5>"
                ?>
            </div>
        </div>
    </div>
    <hr>
</div>
<div class="recent-task">
    <div class="row comp-table">
        <div class="col-md-12">
            <div class="row">
                <h5 class="f-bold text-primary">Recent Task Updates</h5>
            </div>
            <hr>
            <table class="table table-hover table-sm">
                <thead class="text-dark">
                    <tr>
                    <th scope="col">Task Description</th>
                    <th scope="col">Intern</th>
                    <th scope="col">Progress</th>
                    <th scope="col">due date</th>
                    <th scope="col">Status</th>
                    </tr>
                </thead>
                <?php 
                    $id = $_SESSION['log'];
                    $select = "SELECT * FROM task INNER JOIN interns
                    ON task.intern_id = interns.id WHERE comp_id = '$id' ";
                    $result = mysqli_query($conn, $select);
                    
                    while($rows = mysqli_fetch_array($result)){?>
                    
                    <tbody>
                        <tr>
                        <td><?php echo $rows['task_description'] ?></td>
                        <td><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname'] ?></td>
                        <td><?php echo $rows['progress'] ?></td>
                        <td><?php echo $rows['due_date'] ?></td>
                        <td><?php echo $rows['status'] ?></td>
                        </tr>
                    </tbody>
                <?php
                    }
                ?>
            </table>
        </div>
    </div>
</div>
