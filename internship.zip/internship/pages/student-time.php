<div class="page-title">
    <h4>My Time Records</h4>
</div>

<div class="task-table">
    <form action="../php/time-in-out.php" method="post">
        <div class="row">
            <div class="col-md-4">
                <div class="punch-time">
                    <h5>Current Time: <span id="live_time"></span></h5>
                    <div class="background-avatar avatar">
                        <img src="../assets/avatar/<?php echo $rows['id'].$rows['firstname'].'.jpg' ?>" alt="">
                    </div>
                </div>
                <div class="upload-task mt-4">
                    <input type="hidden" class="btn btn-info" name="id" value="<?php echo $_SESSION['log']?>">
                    <input type="submit" class="btn btn-info w-100" name="time" value="Time In">
                </div>
            </div>
            <div class="col-md-8">
                <h5>Time in / Time out Records</h5>                
                <hr>
                <div class="overflow-4">
                    <table class="table table-hover table-sm">
                        <thead class="text-dark">
                            <tr>
                            <th scope="col">Date</th>
                            <th scope="col">In</th>
                            <th scope="col">Out</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php 
                                $id = $_SESSION['log'];
                                $select = "SELECT * FROM time_in WHERE intern_id = '$id' ";
                                $result = mysqli_query($conn, $select);
                                while($rows = mysqli_fetch_array($result)){?>
                                    <tr>
                                    <td><?php echo $rows['date'] ?></td>
                                    <td><?php echo $rows['timein'] ?></td>
                                    <td><?php echo $rows['timeout'] ?></td>
                                    </tr>
                            <?php
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </form>
</div>