<div class="page-title">
    <h4>Interns Students Progress</h4>
</div>
<div class="recent-registration">
    <div class="row">
        <div class="col-md-12 overflow-5 border">
            <div class="progress_name">
                <h5>
                <?php 
                    $log_id = $_SESSION['log'];
                    $id = $_POST['user'];
                    $select = "SELECT * FROM interns WHERE id = '$id' AND instructor = '$log_id' ";
                    $result = mysqli_query($conn, $select);
                    $rows = mysqli_fetch_array($result);
                    echo  $rows['firstname'] .' '. $rows['middlename'][0] .' '. $rows['lastname'];
                ?>
                </h5>
            </div>
            <table class="table table-hover table-sm">
                <thead class="text-secondary">
                    <tr>
                    <th scope="col">Tasks</th>
                    <th scope="col">Due Date</th>
                    <th scope="col">Company Name</th>
                    <th scope="col">Status</th>
                    <th scope="col"></th>
                    </tr>
                </thead>
                <?php 
                    $id = $_SESSION['log'];
                    $intern_id = $_POST['user'];
                    $select = "SELECT * FROM interns INNER JOIN task
                    ON interns.id = task.intern_id INNER JOIN company
                    ON task.comp_id = company.id WHERE instructor = '$id' AND task.intern_id = '$intern_id' ";
                    $result = mysqli_query($conn, $select);
                    while($rows = mysqli_fetch_array($result)){
                    ?>
                    <tbody>
                        <tr>
                        <td><?php echo $rows['task_description'] ?></td>
                        <td><?php echo $rows['due_date'] ?></td>
                        <td><?php echo $rows['companyname'] ?></td>
                        <td><?php echo $rows['status'] ?></td>
                        </tr>
                    </tbody>
                <?php
                    }
                ?>
            </table>
        </div>
    </div>
</div>
