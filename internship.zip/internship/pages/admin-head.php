<div class="page-title">
    <h4>Project Head</h4>
</div>
<div class="row total-count">
    <div class="cards col-md-3">
        <div class="card-body cb-3 d-flex align-items-center">
            <div class="count">
                <h6 class="">Project Head</h6>
                <?php 
                    $select = "SELECT * FROM instructor";
                    $result = mysqli_query($conn, $select);
                    $row = mysqli_num_rows($result);
                    echo "<h5 class='f-bold'>$row</h5>"
                ?>
            </div>
        </div>
    </div>
</div>
<div id="records" class="container-fluid">
    <h1 class="uppercase text-secondary">List Of Instructor</h1>
    <div class="row">
        <?php
            $select = mysqli_query($conn, "SELECT * FROM instructor");
            while($rows = mysqli_fetch_array($select)){?>
                <div class="col-md-4  mt-4">
                    <div class="content border">
                        <?php
                             $imglink = '../assets/avatar/'.$rows['id'].$rows['firstname'].'.jpg';
                             if(@getimagesize($imglink)){?>
                                <div class="avatar col-avatar">
                                    <img src="../assets/avatar/<?php echo $rows['id'].$rows['firstname'].'.jpg' ?>" alt="">
                                </div>
                        <?php
                            }else{?>
                                <div class="avatar">
                                    <img src="../assets/images/user2.png">
                                </div>
                        <?php
                            }
                        ?>
                        <div class="data">
                            <h5 class="text-primary f-bold"><?php echo $rows['firstname'].' '.$rows['middlename'][0].' '.$rows['lastname'] ?></h5>
                            <small><?php echo $rows['address']?></small>
                        </div>
                    <div class="show">
                    <!-- <a class="btn text-warning fa fa-archive" href="../php/archive.php?type=instructor&id=<?php echo $rows['id'] ?>">Archive</a> |  --><a class="btn text-success" href="?inc=head-info&id=<?php echo $rows['id'] ?>">Show more</a>
                    </div>
                    </div>
                </div>
               
        <?php
            }
        ?>
    </div>
</div>
