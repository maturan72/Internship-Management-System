<?php include "../includes/student/header.php" ?>

  <!-- Begin Page Content -->
  <div class="page-content container-fluid">
        <?php 
            if ($_GET['inc']){
                $inc = 'student-' . $_GET['inc'] . '.php';
                include $inc;
            }else{
                include "student-home.php";
            }
        ?>
  </div>

</div>

    
<?php include "../includes/student/footer.php" ?>