<div class="page-title">
    <h4>Student Information</h4>
    <hr>
    <form action="../php/accept-intern.php" method="post">
        <?php
            $id = $_GET['intern_id'];
            $intern_data = "SELECT * FROM interns WHERE id = '$id'";
            $ins_result = mysqli_query($conn, $intern_data);
            while($data = mysqli_fetch_array($ins_result)){
                ?>
        <div class="row information">
        <div class="col-md-4 background-avatar">
            <img src="../assets/avatar/<?php echo $data['id'].$data['firstname'].'.jpg' ?>" alt="">
        </div>
        <div class="col-md-8">
            <div class="">
                    <div class="Instructor info">
                        <h3 class="m-0 uppercase"><?php echo $data['firstname'].' '.$data['middlename'][0].' '.$data['lastname']?></h3>
                        <small class="text-secondary">Intern Name</small>
                    </div>  
                        <hr class="m-0"> 
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row  mt-4">
                                <div class="col-md-4">
                                    <div class="age">
                                        <h6 class="m-0"><?php echo $data['age']?></h6>
                                        <small class="text-secondary">Age</small>
                                    </div> 
                                </div>
                                <div class="col-md-4">
                                    <div class="gender">
                                        <h6 class="m-0"><?php echo $data['gender']?></h6>
                                        <small class="text-secondary">Gender</small>
                                    </div> 
                                </div>
                            </div>
                            <hr class="m-0">
                            <div class="course  mt-4">
                                <h6 class="m-0"><?php echo $data['course']?></h6>
                                <small class="text-secondary">course</small>
                            </div> 
                            <hr class="m-0">
                            <div class="row  mt-4" >
                                <div class="col-md-4">
                                    <div class="address">
                                        <h6 class="m-0"><?php echo $data['address']?></h6>
                                        <small class="text-secondary">Current Address</small>
                                    </div> 
                                </div>
                                <div class="col-md-4">
                                    <div class="email">
                                        <h6 class="m-0"><?php echo $data['email']?></h6>
                                        <small class="text-secondary">email Address</small>
                                    </div> 
                                </div>
                            </div>
                            <hr class="m-0">
                            <div class="datadocuments mt-4">
                                <?php
                                    $id = $_SESSION['log'];
                                    if ($handle = opendir('../assets/documents/'.$id.'/')) {

                                        while (false !== ($entry = readdir($handle))) {
                                    
                                            if ($entry != "." && $entry != "..") {
                                                echo "<h6><a href='' class=''>$entry</a></h6>";
                                            }
                                        }
                                    
                                        closedir($handle);
                                    }
                                ?>
                                <small class="text-secondary">Student Documents</small>
                            </div> 
                            <hr class="m-0">
                        </div>
                    </div> 
                    <div class="update text-end mt-4">
                        <input type="hidden" name="intern_id" value="<?php echo $_GET['intern_id']?>">
                        <input type="hidden" name="comp_id" value="<?php echo $_SESSION['log']?>">
                        <input type="submit" class="btn btn-info" name="accept_intern" value="Accept Intern">
                    </div>
                </div>
        </div>
        </div>
        <?php
            }
        ?>
    </form>
</div>