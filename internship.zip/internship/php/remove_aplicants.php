<?php

    session_start();
    include 'db_con.php';

    if(isset($_GET['remove_aplicants'])){
        $id = $_GET['remove_aplicants'];
        $comp_id = $_SESSION['log'];
        $delete = "DELETE FROM applicants WHERE intern_id = '$id' AND company_id = '$comp_id'";
        if(mysqli_query($conn, $delete)){
            $_SESSION['remove_applicants'] = "Deleted!";
            header('location: ../pages/company.php?inc=aplicants');
        }                
    }
?>


