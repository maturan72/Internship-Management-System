<?php

if(isset($_GET['file_name'])){
    // Folder path to be flushed
    $folder_path = "../assets/documents/";
    $file_name = $_GET['file_name'];
    // List of name of files inside
    // specified folder
    $files = glob($folder_path . $file_name);


    // Delete the files of the list
    foreach ($files as $file) {
        if (is_file($file)) {
            // Deleting the given file
            unlink($file);
            header("location: ../pages/student.php?inc=documents");
        }else{
            header("location: ../pages/student.php?inc=documents");
        }
    }
}

?>