<?php 
	session_start();
	include 'db_con.php';

	// initializing variables
	if (isset($_POST['intern'])) {
		$fname = $_POST['fname'];
        $mname = $_POST['mname'];
        $lname = $_POST['lname'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $instructor = $_POST['instructor'];
        $address = $_POST['address'];
        $course = $_POST['course'];
        $skill = $_POST['skills'];
        $email = $_POST['email'];
		$password = $_POST['password'];
        $confirm = $_POST['confirm'];
        $type = 'intern';

        $data = new stdClass();
        $data->type = $type;
        $data->firstname = $fname;
        $data->middlename = $mname;
        $data->lastname = $lname;
        $data->age = $age;
        $data->gender = $gender;
        $data->instructor = $instructor;
        $data->address = $address;
        $data->course = $course;
        $data->skill = $skill;
        $data->email = $email;
        $data->password = $password;

        $mydata = json_encode($data);
        

        $exist_email = mysqli_query($conn,"SELECT * FROM interns WHERE email = '$email'");

        if(mysqli_num_rows($exist_email) > 0){
            header ('location: ../login.php?inc=intern');
            $_SESSION['email_err'] = "Email Address is already taken"; 
        }else{
            if($password != $confirm){
                header ('location: ../index.php?inc=intern');
                $_SESSION['err'] = "Password Don't Match"; 
            }else {
                mysqli_query($conn, "INSERT INTO pending_registration VALUES(NULL,'$mydata')"); 
                $_SESSION['message'] = "Request Successfully Sent"; 
                unset($_SESSION['err']);
                $_SESSION['succ'] = "Succesfully Registered"; 
                header ('location: ../index.php?inc=login-acc');
            }
        }
    }
    elseif(isset($_POST['instructor'])){
        $fname = $_POST['fname'];
        $mname = $_POST['mname'];
        $lname = $_POST['lname'];
        $address = $_POST['address'];
        $email = $_POST['email'];
		$password = $_POST['password'];
        $confirm = $_POST['confirm'];
        $type = 'instructor';

        $data = new stdClass();
        $data->type = $type;
        $data->firstname = $fname;
        $data->middlename = $mname;
        $data->lastname = $lname;
        $data->address = $address;
        $data->email = $email;
        $data->password = $password;

        $mydata = json_encode($data);

        $exist_email = mysqli_query($conn,"SELECT * FROM instructor WHERE email = '$email'");

        if(mysqli_num_rows($exist_email) > 0){
            header ('location: ../index.php?inc=instructor');
            $_SESSION['email_err'] = "Email Address is already taken"; 
        }else{
            if($password != $confirm){
                header ('location: ../index.php?inc=instructor');
                $_SESSION['err'] = "Password Don't Match"; 
            }else {
                mysqli_query($conn, "INSERT INTO pending_registration VALUES(NULL,'$mydata')"); 
                $_SESSION['message'] = "Request Successfully Sent"; 
                unset($_SESSION['err']);
                $_SESSION['succ'] = "Succesfully Registered"; 
                header ('location: ../index.php?inc=login-acc');
                
            }
        }
    }
    elseif(isset($_POST['company'])){
        $fname = $_POST['fname'];
        $mname = $_POST['mname'];
        $lname = $_POST['lname'];
        $company = $_POST['companyname'];
        $address = $_POST['address'];
        $email = $_POST['email'];
		$password = $_POST['password'];
        $confirm = $_POST['confirm'];
        $position = $_POST['position'];
        $type = 'company';

        $data = new stdClass();
        $data->type = $type;
        $data->firstname = $fname;
        $data->middlename = $mname;
        $data->lastname = $lname;
        $data->company = $company;
        $data->address = $address;
        $data->email = $email;
        $data->password = $password;
        $data->position = $position;

        $mydata = json_encode($data);
        
        $exist_email = mysqli_query($conn,"SELECT * FROM company WHERE email = '$email'");
       
        if(mysqli_num_rows($exist_email) > 0){
            header ('location: ../index.php?inc=company');
            $_SESSION['email_err'] = "Email Address is already taken"; 
        }else{
            if($password != $confirm){
                header ('location: ../index.php?inc=company');
                $_SESSION['err'] = "Password Don't Match"; 
            }else {
                
                mysqli_query($conn, "INSERT INTO pending_registration VALUES(NULL,'$mydata')"); 
                $_SESSION['message'] = "Request Successfully Sent"; 
                unset($_SESSION['err']);
                $_SESSION['succ'] = "Succesfully Registered"; 
                header ('location: ../index.php?inc=login-acc');
            }
        }
        
    }
?>