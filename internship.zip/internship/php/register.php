<?php 
	session_start();
	include 'db_con.php';

	// initializing variables
	if (isset($_POST['intern'])) {
		$fname = $_POST['fname'];
        $mname = $_POST['mname'];
        $lname = $_POST['lname'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $instructor = $_POST['instructor'];
        $address = $_POST['address'];
        $contact = $_POST['contact'];
        $course = $_POST['course'];
        $section = $_POST['section'];
        $skill = $_POST['skills'];
        $email = $_POST['email'];
		$password = $_POST['password'];
        $confirm = $_POST['confirm'];
        $type = 'intern';

        $data = new stdClass();
        $data->type = $type;
        $data->firstname = $fname;
        $data->middlename = $mname;
        $data->lastname = $lname;
        $data->age = $age;
        $data->gender = $gender;
        $data->instructor = $instructor;
        $data->address = $address;
        $data->contact = $contact;
        $data->course = $course;
        $data->section = $section;
        $data->skill = $skill;
        $data->email = $email;
        $data->password = $password;

        $mydata = json_encode($data);
        

        $exist_email = mysqli_query($conn,"SELECT * FROM interns WHERE email = '$email'");

        if(mysqli_num_rows($exist_email) > 0){
            header ('location: ../login.php?inc=intern');
        }else{
            if($password != $confirm){
                header ('location: ../index.php?inc=intern');
            }else {
                mysqli_query($conn, "INSERT INTO pending_registration VALUES(NULL,'$mydata')"); 
                $_SESSION['succ'] = "Succesfully Registered"; 
                header ('location: ../index.php?inc=intern');
            }
        }
    }
    elseif(isset($_POST['instructor'])){
        $fname = $_POST['fname'];
        $mname = $_POST['mname'];
        $lname = $_POST['lname'];
        $address = $_POST['address'];
        $contact = $_POST['contact'];
        $email = $_POST['email'];
		$password = $_POST['password'];
        $confirm = $_POST['confirm'];
        $type = 'instructor';

        $data = new stdClass();
        $data->type = $type;
        $data->firstname = $fname;
        $data->middlename = $mname;
        $data->lastname = $lname;
        $data->address = $address;
        $data->contact = $contact;
        $data->email = $email;
        $data->password = $password;

        $mydata = json_encode($data);

        $exist_email = mysqli_query($conn,"SELECT * FROM instructor WHERE email = '$email'");

        if(mysqli_num_rows($exist_email) > 0){
            header ('location: ../index.php?inc=instructor');
        }else{
            if($password != $confirm){
                header ('location: ../index.php?inc=instructor');
            }else {
                mysqli_query($conn, "INSERT INTO pending_registration VALUES(NULL,'$mydata')"); 
                $_SESSION['succ'] = "Succesfully Registered"; 
                header ('location: ../index.php?inc=instructor');
            }
        }
    }
    elseif(isset($_POST['company'])){
        $fname = $_POST['fname'];
        $mname = $_POST['mname'];
        $lname = $_POST['lname'];
        $company = $_POST['companyname'];
        $address = $_POST['address'];
        $email = $_POST['email'];
		$password = $_POST['password'];
        $confirm = $_POST['confirm'];
        $contact = $_POST['contact'];
        $type = 'company';

        $data = new stdClass();
        $data->type = $type;
        $data->firstname = $fname;
        $data->middlename = $mname;
        $data->lastname = $lname;
        $data->company = $company;
        $data->address = $address;
        $data->email = $email;
        $data->password = $password;
        $data->contact = $contact;

        $mydata = json_encode($data);
        
        $exist_email = mysqli_query($conn,"SELECT * FROM company WHERE email = '$email'");
       
        if(mysqli_num_rows($exist_email) > 0){
            header ('location: ../index.php?inc=company');
        }else{
            if($password != $confirm){
                header ('location: ../index.php?inc=company');
            }else {
                
                mysqli_query($conn, "INSERT INTO pending_registration VALUES(NULL,'$mydata')"); 
                $_SESSION['succ'] = "Succesfully Registered"; 
                header ('location: ../index.php?inc=company');
            }
        }
        
    }
?>