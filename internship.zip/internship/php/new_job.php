<?php

    session_start();
    include 'db_con.php';

    if(isset($_POST['add_job'])){
        $id = $_SESSION['log'];
        // $companyname = mysqli_query($conn, "SELECT companyname FROM company WHERE id = '$id'");
        // $row = mysqli_fetch_array($companyname);
        // $comp_name = $row['companyname'];
        $title = $_POST['title'];
        $desc = $_POST['desc'];
        $position = $_POST['position'];
        
        $send = "INSERT INTO jobs VALUE(NULL, '$title', '$id', '$desc','$position','')";

        if(mysqli_query($conn, $send)){
            $_SESSION['job_suc'] = "suc";
            header('location: ../pages/company.php?inc=jobs');
        }

    }

?>