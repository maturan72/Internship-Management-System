<?php
    session_start();
    include 'db_con.php';

    if(isset($_POST['ins_upd'])){
        $id = $_POST['id'];
        $fname = $_POST['fname'];
        $mname = $_POST['mname'];
        $lname = $_POST['lname'];
        $address = $_POST['address'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $newpassword = $_POST['newpassword'];

        if($newpassword != ''){
            $update = "UPDATE `instructor` SET `firstname` = '$fname', `middlename` = '$mname', `lastname` = '$lname', `email` = '$email', `password` = '$newpassword', `address` = '$address' WHERE `id` = $id";
            if(mysqli_query($conn, $update)){
                echo "ASD";
                header ('location: ../pages/instructor.php?inc=information');
                $_SESSION['upd_succ'] = "updated succesfully"; 
            }
        }else {
            $update = "UPDATE `instructor` SET `firstname` = '$fname', `middlename` = '$mname', `lastname` = '$lname', `email` = '$email', `password` = '$password', `address` = '$address' WHERE `id` = $id";
            if(mysqli_query($conn, $update)){
                echo "ASD";
                header ('location: ../pages/instructor.php?inc=information');
                $_SESSION['upd_succ'] = "updated succesfully"; 
            }

        }
    }

?>