<?php
 session_start();
 include 'db_con.php';


if (isset($_POST['add_new'])) {
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];
   

    $exist_email = mysqli_query($conn,"SELECT * FROM `admin` WHERE email = '$email'");
    $exist_email1 = mysqli_query($conn,"SELECT * FROM `company` WHERE email = '$email'");
    $exist_email2 = mysqli_query($conn,"SELECT * FROM `instructor` WHERE email = '$email'");
    $exist_email3 = mysqli_query($conn,"SELECT * FROM `interns` WHERE email = '$email'");

    if(mysqli_num_rows($exist_email) > 0){
        header ('location: ../pages/admin.php?inc=add');
        $_SESSION['email_err'] = "Email Address is already taken"; 
    }elseif(mysqli_num_rows($exist_email1) > 0){
        header ('location: ../pages/admin.php?inc=add');
        $_SESSION['email_err'] = "Email Address is already taken"; 
    }elseif(mysqli_num_rows($exist_email2) > 0){
        header ('location: ../pages/admin.php?inc=add');
        $_SESSION['email_err'] = "Email Address is already taken"; 
    }elseif(mysqli_num_rows($exist_email3) > 0){
        header ('location: ../pages/admin.php?inc=add');
        $_SESSION['email_err'] = "Email Address is already taken"; 
    }else{
        
        if($password != $confirm){
            header ('location: ../pages/admin.php?inc=add');
            $_SESSION['pass_err'] = "Password Don't Match"; 
        }else {
            
           $add = "INSERT INTO `admin` VALUES(NULL,'$fname','$mname','$lname','$email','$password')"; 
            if(mysqli_query($conn, $add)){
                $_SESSION['message'] = "Request Successfully Sent"; 
                unset($_SESSION['pass_err']);
                header ('location: ../pages/admin.php?inc=add');
            }
        }
    }   
}

?>