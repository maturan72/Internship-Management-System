<?php
    session_start();
    unset($_SESSION['log']);
    unset($_SESSION['type']);
    header('location: ../index.php');

?>