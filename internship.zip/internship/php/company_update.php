<?php
    session_start();
    include 'db_con.php';

    if(isset($_POST['comp_upd'])){
        $comp_id = $_POST['id'];
        $comp_name = $_POST['company'];
        $address = $_POST['address'];
        $fname = $_POST['fname'];
        $mname = $_POST['mname'];
        $contact = $_POST['contact'];
        $lname = $_POST['lname'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $newpassword = $_POST['newpassword'];

        if($newpassword == ""){
            $update = "UPDATE `company` SET `firstname` = '$fname', `middlename` = '$mname', `lastname` = '$lname', `email` = '$email', `password` = '$password', `companyname` = '$comp_name',`contact` = '$contact', `address` = '$address' WHERE `company`.`id` = $comp_id";
            if(mysqli_query($conn, $update)){
                header ('location: ../pages/company.php?inc=information');
                $_SESSION['upd_succ'] = "updated succesfully"; 
            }
        }else {
            $update = "UPDATE `company` SET `firstname` = '$fname', `middlename` = '$mname', `lastname` = '$lname', `email` = '$email', `password` = '$newpassword', `companyname` = '$comp_name', `contact` = '$contact', `address` = '$address' WHERE `company`.`id` = $comp_id";
            if(mysqli_query($conn, $update)){
                header ('location: ../pages/company.php?inc=information');
                $_SESSION['upd_succ'] = "updated succesfully"; 
            }

        }
    }

?>