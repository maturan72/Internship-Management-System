<?php

    session_start();
    include 'db_con.php';

    if(isset($_GET['del'])){
        $id = $_GET['del'];
        $delete = "DELETE FROM pending_registration WHERE id = '$id'";
        if(mysqli_query($conn, $delete)){
            header('location: ../pages/admin.php');
        }                
    }
?>


