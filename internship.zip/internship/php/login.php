<?php

    session_start();
    include 'db_con.php';

    if (isset($_POST['login'])) {
		$email = $_POST['email'];
        $password = $_POST['password'];

        $select_admin = "SELECT * FROM admin WHERE email = '$email' AND password = '$password'"; 
        $result_admin = mysqli_query($conn, $select_admin);
        $admin_data = mysqli_fetch_array($result_admin);
        
        $select_company = "SELECT * FROM company WHERE email = '$email' AND password = '$password'"; 
        $result_company = mysqli_query($conn, $select_company);
        $compay_data = mysqli_fetch_array($result_company);
        
        $select_instructor = "SELECT * FROM instructor WHERE email = '$email' AND password = '$password'"; 
        $result_instructor = mysqli_query($conn, $select_instructor);
        $instructor_data = mysqli_fetch_array($result_instructor);

        $select_interns = "SELECT * FROM interns WHERE email = '$email' AND password = '$password'"; 
        $result_interns = mysqli_query($conn, $select_interns);
        $interns_data = mysqli_fetch_array($result_interns);
        
        
        if(mysqli_num_rows($result_admin) > 0){
            $_SESSION['log'] = $admin_data['id'];
            $_SESSION['type'] = "admin";
            header ('location: ../pages/admin.php');
        }
        elseif(mysqli_num_rows($result_company) > 0){
            $_SESSION['log'] = $compay_data['id'];
            $_SESSION['type'] = "company";
            header ('location: ../pages/company.php');
        }
        elseif(mysqli_num_rows($result_instructor) > 0){
            $_SESSION['log'] = $instructor_data['id'];
            $_SESSION['type'] = "instructor";
            header ('location: ../pages/instructor.php');
        }
        elseif(mysqli_num_rows($result_interns) > 0){
            $_SESSION['log'] = $interns_data['id'];
            $_SESSION['type'] = "student";
            header ('location: ../pages/student.php');
        }
        else{
            $_SESSION['pass_err'] = "Wrong Password";
            header ('location: ../index.php?inc=login-acc');
        }
    }
?>