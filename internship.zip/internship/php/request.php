<?php

    session_start();
    include 'db_con.php';

    if(isset($_GET['data'])){
        $id = $_GET['data'];
        $data = mysqli_query($conn, "SELECT * FROM pending_registration WHERE id = '$id'");
        while($rows = mysqli_fetch_array($data)){
            $mydata = json_decode($rows['data']);
            if($mydata->type == 'instructor'){
                $insert = "INSERT INTO instructor VALUES(NULL,'$mydata->firstname','$mydata->middlename','$mydata->lastname','$mydata->address','$mydata->email','$mydata->password','$mydata->contact')";
                if(mysqli_query($conn, $insert)){
                    $delete = "DELETE FROM pending_registration WHERE id = '$id'";
                    if(mysqli_query($conn, $delete)){
                        $_SESSION['approved'] = "success";
                        header('location: ../pages/admin.php');
                    }                
                }
            }elseif($mydata->type == 'company'){
                $insert = "INSERT INTO company VALUES(NULL,'$mydata->firstname','$mydata->middlename','$mydata->lastname','$mydata->email','$mydata->password','$mydata->company','$mydata->address','$mydata->contact')";
                if(mysqli_query($conn, $insert)){
                    $delete = "DELETE FROM pending_registration WHERE id = '$id'";
                    if(mysqli_query($conn, $delete)){
                        $_SESSION['approved'] = "success";
                        header('location: ../pages/admin.php');
                    }                
                }
            }else{
                $insert = "INSERT INTO interns VALUES(NULL,'$mydata->firstname','$mydata->middlename','$mydata->lastname','$mydata->age','$mydata->gender','$mydata->contact','$mydata->address','$mydata->course','$mydata->section','$mydata->skill',0,'','','$mydata->instructor','$mydata->email','$mydata->password')";
                if(mysqli_query($conn, $insert)){
                    $delete = "DELETE FROM pending_registration WHERE id = '$id'";
                    if(mysqli_query($conn, $delete)){
                        $_SESSION['approved'] = "success";
                        header('location: ../pages/admin.php');
                    }                
                }
            }
        }
    }

    if(isset($_GET['instructor_accept_req'])){
        $id = $_GET['instructor_accept_req'];
        $data = mysqli_query($conn, "SELECT * FROM pending_registration WHERE id = '$id'");
        while($rows = mysqli_fetch_array($data)){
            $mydata = json_decode($rows['data']);

            $insert = "INSERT INTO interns VALUES(NULL,'$mydata->firstname','$mydata->middlename','$mydata->lastname','$mydata->age','$mydata->gender','$mydata->contact','$mydata->address','$mydata->course','$mydata->section','$mydata->skill',0,'','','$mydata->instructor','$mydata->email','$mydata->password')";
            if(mysqli_query($conn, $insert)){
                $delete = "DELETE FROM pending_registration WHERE id = '$id'";
                if(mysqli_query($conn, $delete)){
                    $_SESSION['Accepted'] = "success";
                    header('location: ../pages/instructor.php');
                }                
            }
        }
    }
?>


