<?php
$email = isset($_GET['email']) ? $_GET['email'] : '';
$email = mysqli_real_escape_string($email);

$sql = "SELECT COUNT(*) > 0 AS email
        FROM interns
        WHERE email = '{$username}'";

$result = mysqli_query($sql);

$exists = false;
if ($row = mysqli_fetch_assoc($result)) {
    $exists = $row['user_found'] ? true : false;
}

echo json_encode(array('exists' => $exists));
?>