<?php

    session_start();
    include 'db_con.php';

    $id = $_SESSION['log'];

    $select = mysqli_query($conn, "SELECT * FROM interns WHERE id ='$id' ");

    $data = mysqli_fetch_array($select);
    $name = $data['firstname'];

    if (!file_exists('../assets/documents/'.$id.$name)) {
        mkdir('../assets/documents/'.$id.$name, 0777, true);
    }
    
    foreach ($_FILES['file']['name'] as $key=>$val) {
        $filename = $_FILES['file']['name'][$key];
        
        move_uploaded_file($_FILES['file']['tmp_name'][$key], '../assets/documents/'.$id.$name.'/'.$filename);
    }
    echo "Uploaded Successfully";
?>