<?php

    session_start();
    $id = $_SESSION['log'];

    if (!file_exists('../assets/documents/'.$id)) {
        mkdir('../assets/documents/'.$id, 0777, true);
    }
    
    foreach ($_FILES['file']['name'] as $key=>$val) {
        $filename = $_FILES['file']['name'][$key];
        
        move_uploaded_file($_FILES['file']['tmp_name'][$key], '../assets/documents/'.$id.'/'.$filename);
    }
    echo "Uploaded Successfully";
?>