<?php

session_start();
include 'db_con.php';

$user_id = $_SESSION['log'];
$select = mysqli_query($conn, "SELECT * FROM time_in WHERE intern_id = '$user_id' AND timeout != '' ");
while($row = mysqli_fetch_array($select)){
    $time_in = $row['timein'];
    $time_out = $row['timeout'];
   
    $time1 = new DateTime($time_in);
    $time2 = new DateTime($time_out);
    $interval = $time1->diff($time2);
    $all_time = $interval->format('%H:%M:%S');
    
    $total[] = $all_time;
    
}
$sum = strtotime('00:00:00');
$sum2=0;
foreach ($total as $v){
  $sum1=strtotime($v)-$sum;
  $sum2 = $sum2+$sum1;
}
$sum3=$sum+$sum2;
$total_hours = date("H:i:s",$sum3);
?>

