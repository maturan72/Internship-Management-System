<?php
    session_start();
    include 'db_con.php';

    if(isset($_POST['accept_intern'])){
        $intern_id = $_POST['intern_id'];
        $comp_id = $_POST['comp_id'];
        
        
        $update_data = "UPDATE `interns` SET `company` = '$comp_id'  WHERE id = '$intern_id'";
        if(mysqli_query($conn, $update_data)){
            $remove = "DELETE FROM applicants WHERE intern_id = '$intern_id'";
            echo $intern_id;
            if(mysqli_query($conn, $remove)){
                header ('location: ../pages/company.php?inc=interns');
                $_SESSION['accept_succ'] = "Accepted succesfully"; 
            }
        }
    }

?>