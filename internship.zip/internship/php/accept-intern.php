<?php
    session_start();
    include 'db_con.php';

    if(isset($_POST['accept_intern'])){
        $intern_id = $_POST['intern_id'];
        $comp_id = $_POST['comp_id'];
       
        $select = mysqli_query($conn,"SELECT * FROM applicants WHERE intern_id = '$intern_id' AND company_id = '$comp_id' ");
        $row = mysqli_fetch_assoc($select);
        $job_id = $row['job_id'];
        
        $selectjob = "SELECT * FROM jobs WHERE id = '$job_id'";
        $rowjob = mysqli_query($conn, $selectjob);
        $row_job_data = mysqli_fetch_array($rowjob);
        $total_intern = (int)$row_job_data['total_intern'] + 1;
        
        $update_job = "UPDATE jobs SET total_intern = '$total_intern' WHERE id = '$job_id'";

        if(mysqli_query($conn, $update_job)){
            $update_data = "UPDATE `interns` SET `company` = '$comp_id',`job_id` = '$job_id' WHERE id = '$intern_id'";
            if(mysqli_query($conn, $update_data)){
                $remove = "DELETE FROM applicants WHERE intern_id = '$intern_id'";
                echo $intern_id;
                if(mysqli_query($conn, $remove)){
                    
                    header ('location: ../pages/company.php?inc=interns');
                    $_SESSION['accept_succ'] = "Accepted succesfully"; 
                }
            }
        }
    }

?>