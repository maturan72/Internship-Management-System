<?php
    session_start();
    include 'db_con.php';

    if(isset($_POST['apply'])){
        $comp_id = $_POST['comp_id'];
        $int_id = $_SESSION['log'];

        $insert_data = "INSERT INTO applicants VALUE (NULL,'$int_id',$comp_id)";
        if(mysqli_query($conn, $insert_data)){
            $_SESSION['apply_succ'] = "Application Succesfully Sent";
            header('location: ../pages/student.php?inc=company');
        }
    }
?>