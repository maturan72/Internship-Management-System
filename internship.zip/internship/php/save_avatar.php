<?php
    session_start();
    include 'db_con.php';

    if(isset($_POST['admin_avatar'])){
        $data = $_POST['base64'];
        $tmpFile = $_FILES['file_avatar']['tmp_name'];

        list($type, $data) = explode(';', $data);
        list(, $data)      = explode(',', $data);
        $data = base64_decode($data);

        $id = $_SESSION['log'];
        $select = mysqli_query($conn, "SELECT * FROM admin WHERE id = '$id' ");
        $datarow = mysqli_fetch_assoc($select);
        $filename = $datarow['id'].$datarow['firstname'];

        if($tmpFile == ""){
            file_put_contents('../assets/avatar/'.$datarow['id'].$datarow['firstname'].'.jpg', $data);
            header('location: ../pages/admin.php');
        }else{
            $newFile = '../assets/avatar/'.$filename.'.jpg';
            $result = move_uploaded_file($tmpFile, $newFile);
            header('location: ../pages/admin.php');
        }
    }elseif(isset($_POST['company_avatar'])){
        $data = $_POST['base64'];
        $tmpFile = $_FILES['file_avatar']['tmp_name'];

        list($type, $data) = explode(';', $data);
        list(, $data)      = explode(',', $data);
        $data = base64_decode($data);

        $id = $_SESSION['log'];
        $select = mysqli_query($conn, "SELECT * FROM company WHERE id = '$id' ");
        $datarow = mysqli_fetch_assoc($select);
        $filename = $datarow['id'].$datarow['firstname'];

        if($tmpFile == ""){
            file_put_contents('../assets/avatar/'.$datarow['id'].$datarow['firstname'].'.jpg', $data);
            header('location: ../pages/company.php');
        }else{
            $newFile = '../assets/avatar/'.$filename.'.jpg';
            $result = move_uploaded_file($tmpFile, $newFile);
            header('location: ../pages/company.php');
        }
    }
    elseif(isset($_POST['instructor_avatar'])){
        $data = $_POST['base64'];
        $tmpFile = $_FILES['file_avatar']['tmp_name'];

        list($type, $data) = explode(';', $data);
        list(, $data)      = explode(',', $data);
        $data = base64_decode($data);

        $id = $_SESSION['log'];
        $select = mysqli_query($conn, "SELECT * FROM instructor WHERE id = '$id' ");
        $datarow = mysqli_fetch_assoc($select);
        $filename = $datarow['id'].$datarow['firstname'];

        if($tmpFile == ""){
            file_put_contents('../assets/avatar/'.$datarow['id'].$datarow['firstname'].'.jpg', $data);
            header('location: ../pages/instructor.php');
        }else{
            $newFile = '../assets/avatar/'.$filename.'.jpg';
            $result = move_uploaded_file($tmpFile, $newFile);
            header('location: ../pages/instructor.php');
        }
    }elseif(isset($_POST['interns_avatar'])){
        $data = $_POST['base64'];
        $tmpFile = $_FILES['file_avatar']['tmp_name'];

        list($type, $data) = explode(';', $data);
        list(, $data)      = explode(',', $data);
        $data = base64_decode($data);

        $id = $_SESSION['log'];
        $select = mysqli_query($conn, "SELECT * FROM interns WHERE id = '$id' ");
        $datarow = mysqli_fetch_assoc($select);
        $filename = $datarow['id'].$datarow['firstname'];

        if($tmpFile == ""){
            file_put_contents('../assets/avatar/'.$datarow['id'].$datarow['firstname'].'.jpg', $data);
            header('location: ../pages/student.php');
        }else{
            $newFile = '../assets/avatar/'.$filename.'.jpg';
            $result = move_uploaded_file($tmpFile, $newFile);
            header('location: ../pages/student.php');
        }
    }else{
        header('location: javascript://history.go(-1)');
    }
        
?>