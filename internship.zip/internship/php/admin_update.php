<?php
    session_start();
    include 'db_con.php';

    if(isset($_POST['admin_upd'])){
        $id = $_POST['id'];
        $fname = $_POST['fname'];
        $mname = $_POST['mname'];
        $lname = $_POST['lname'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $newpassword = $_POST['newpassword'];

        if($newpassword == ""){
            $update = "UPDATE `admin` SET `firstname` = '$fname', `middlename` = '$mname', `lastname` = '$lname', `email` = '$email', `lastname` = '$lname', `password` = '$password' WHERE `admin`.`id` = $id";;
            if(mysqli_query($conn, $update)){
                header ('location: ../pages/admin.php?inc=information');
                $_SESSION['upd_succ'] = "updated succesfully"; 
            }
        }else {
            $update = "UPDATE `admin` SET `firstname` = '$fname', `middlename` = '$mname', `lastname` = '$lname', `email` = '$email', `lastname` = '$lname', `password` = '$newpassword' WHERE `admin`.`id` = $id";;
            if(mysqli_query($conn, $update)){
                header ('location: ../pages/admin.php?inc=information');
                $_SESSION['upd_succ'] = "updated succesfully"; 
            }

        }
    }

?>