<?php 
session_start();
include "../php/db_con.php";
error_reporting(0);
$type = $_SESSION['type'];
if($type != "admin"){
  header("location: javascript://history.go(-1)");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Internship Management System</title>

    <link rel="stylesheet" href="../includes/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/pages.css">
</head>
<body>
<div class="page-wrapper chiller-theme toggled">
  <a id="show-sidebar" class="burger-button btn btn-dark" href="#">
    Show
  </a>
  <nav id="sidebar" class="sidebar-wrapper">
    <div class="sidebar-content">
      <div class="sidebar-brand">
        <a href="#">IM System</a>
        <div id="close-sidebar">
          <!-- <i class="fa fa-times">x</i> -->X
        </div>
      </div>
        <?php
            $id = $_SESSION['log'];
            $select = mysqli_query($conn,"SELECT * FROM admin WHERE id = '$id'");
            while($row = mysqli_fetch_array($select)){?>
            <div class="sidebar-header">
                <div class="user-pic nav-avatar">
                  <img class="img-responsive img-rounded" src="../assets/avatar/<?php echo $row['id'].$row['firstname'].'.jpg' ?>">
                    <span class="user-camera">
                      <i class="text-primary fa fa-camera" data-bs-toggle="modal" data-bs-target="#exampleModal"></i>
                    </span>
                </div>
                <div class="user-info">
                  <span class="user-name">
                    <strong class="uppercase"><?php echo $row['lastname'] ?></strong>
                  </span>
                  <span class="user-role">Administrator</span>
                  <span class="user-status">
                    <i class="fa fa-circle"></i>
                    <span>Online</span>
                  </span>
                </div>
            </div>
          <?php
            }
        ?>
      <div class="sidebar-menu">
        <ul>
          <li class="header-menu">
            <span>General</span>
          </li>
          <li class="sidebar-dropdown">
            <a href="?inc=dashboard">
              <i class="fa fa-home" aria-hidden="true"></i>
              <span>Dashboard</span>
            </a>
          </li>
          <li class="sidebar-dropdown">
            <a href="?inc=admin">
              <i class="fa fa-list"></i>
              <span>Administrator</span>
            </a>
          </li>
          <li class="sidebar-dropdown">
            <a href="?inc=company">
              <i class="fa fa-list"></i>
              <span>Company</span>
            </a>
          </li>
          <li class="sidebar-dropdown">
            <a href="?inc=head">
              <i class="fa fa-list"></i>
              <span>Project Head</span>
            </a>
          </li>
          <li class="sidebar-dropdown">
            <a href="?inc=interns">
              <i class="fa fa-list"></i>
              <span>Interns Student</span>
            </a>
          </li>
          <li class="sidebar-dropdown">
            <a href="?inc=information">
              <i class="fa fa-user"></i>
              <span>Admin Information</span>
            </a>
          </li>
          <li>
            <a href="../php/logout.php">
            <i class="fa fa-sign-out"></i>
              <span>Logout</span>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" onclick="vidOff()" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body d-flex align-items-center justify-content-center">
        <div class="avatar_update">
            <div class="text-center">
                <h3>Update Avatar</h3>
            </div>
            <div class="camera w-3-5">
                <video class="border" id="video" width="350" height="250" autoplay></video>
                <canvas class="border" id="canvas" width="350" height="250"></canvas>
                <div class="row">
                    <div class="col-md-6">
                        <button class="btn  btn-info w-100" id="start-camera">Start Camera</button>
                    </div>
                    <div class="col-md-6">
                        <button class="btn  btn-success w-100" id="click-photo">Capture</button>
                    </div>
                    <form class="mt-4" action="../php/save_avatar.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name='base64' id="data">
                        <div class="row">
                            <div class="col-md-6">
                                <a class="btn btn-secondary w-100" onclick="document.getElementById('getFile').click()">Choose Image</a>
                                <input type='file' id="getFile" name='file_avatar' style="display:none"> 
                            </div>
                            <div class="col-md-6">
                                <input class="btn btn-primary w-100" type="submit" name='admin_avatar' value="Save Avatar">
                            </div>
                        </div>
                        
                    </form>
                </div>
            </div>
            
        </div>
      </div>
      <div class="modal-footer">
        <button id="stop_button" onclick="vidOff()" type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
        <script>
            let camera_button = document.querySelector("#start-camera");
            let video = document.querySelector("#video");
            let click_button = document.querySelector("#click-photo");
            let canvas = document.querySelector("#canvas");
            let stop_button = document.querySelector("#stop_button");


            camera_button.addEventListener('click', async function() {
                let stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
                video.srcObject = stream;
                document.getElementById("video").style.display="block";
                document.getElementById("canvas").style.display="none";
            });
            
            click_button.addEventListener('click', function() {
                canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
                let image_data_url = canvas.toDataURL('image/jpeg');
                
                document.getElementById("data").value = image_data_url;
                document.getElementById("video").style.display="none";
                document.getElementById("canvas").style.display="block";

            });

            function vidOff() {
                var video = document.getElementById('video');
                video.srcObject = stop();
            };

            var input = document.getElementById('getFile');
            input.addEventListener('change', handleFiles);

            function handleFiles(e) {
                var ctx = document.getElementById('canvas').getContext('2d');
                var img = new Image;
                img.src = URL.createObjectURL(e.target.files[0]);
                img.onload = function() {
                    ctx.drawImage(img, 0, 0, 350, 250);
                }
            }

        </script>
    </div>
  </div>
</div>
