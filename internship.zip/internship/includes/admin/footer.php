<script src="../includes/bootstrap/js/jquery.min.js"></script>
<script src="../includes/bootstrap/js/bootstrap.min.js"></script>
<script src="../js/filter_table.js"></script>
<script src="../js/validate.js"></script>
<script src="../js/sweetalert.min.js"></script>
<script>
    jQuery(function ($) {

$(".sidebar-dropdown > a").click(function() {
$(".sidebar-submenu").slideUp(200);
if (
$(this)
  .parent()
  .hasClass("active")
) {
$(".sidebar-dropdown").removeClass("active");
$(this)
  .parent()
  .removeClass("active");
} else {
$(".sidebar-dropdown").removeClass("active");
$(this)
  .next(".sidebar-submenu")
  .slideDown(200);
$(this)
  .parent()
  .addClass("active");
}
});

$("#close-sidebar").click(function() {
$(".page-wrapper").removeClass("toggled");
});
$("#show-sidebar").click(function() {
$(".page-wrapper").addClass("toggled");
});

});

</script>

<?php
    if($_SESSION['approved']){?>
    <script>
      swal({
        title: "Successfully Approved!",
        icon: "success",
        button: "Ok",
      });
    </script>
  <?php
        unset($_SESSION['approved']);
    }elseif($_SESSION['upd_succ']){?>
      <script>
        swal({
          title: "Successfully Updated!",
          icon: "success",
          button: "Ok",
        });
      </script>
  <?php
    unset($_SESSION['upd_succ']);
    }elseif($_SESSION['del_request']){?>
      <script>
        swal({
          title: "Request Successfully Remove!",
          icon: "success",
          button: "Ok",
        });
      </script>
  <?php
    unset($_SESSION['del_request']);
    }
?>


</body>
</html>