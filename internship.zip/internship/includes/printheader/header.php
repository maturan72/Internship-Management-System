<?php 
session_start();
include "../php/db_con.php" ;
error_reporting(0);
$type = $_SESSION['type'];
if($type != "student"){
  header("location: javascript://history.go(-1)");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../includes/bootstrap/css/bootstrap.min.css">
    <style>
        img{
            width: 200px;
            height: 200px;
        }
        @page{
            size: auto;
        }
        
    </style>
</head>
<body>
