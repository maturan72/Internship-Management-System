<div class="container-fluid mt-4">
  <footer
          class="text-center text-lg-start text-white"
          style="background-color: #45526e"
          >
    <div class="container p-4 pb-0">
      <section class="">
        <div class="row">
          <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
            <h6 class="text-uppercase mb-4 font-weight-bold">
              OJT Management System
            </h6>
            <p>
            <i class="fa fa-map-marker"><span> Bulacan Main Campus</span></i>
            </p>
          </div>

          <hr class="w-100 clearfix d-md-none" />

          <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
            <h6 class="text-uppercase mb-4 font-weight-bold">
              Register
            </h6>
            <p>
              <a class="text-white" href="?inc=company">Company</a>
            </p>
            <p>
              <a class="text-white" href="?inc=instructor">Project head</a>
            </p>
            <p>
              <a class="text-white" href="?inc=intern">Interns</a>
            </p>
          </div>

          <hr class="w-100 clearfix d-md-none" />

          <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
            <h6 class="text-uppercase mb-4 font-weight-bold">Contact</h6>
            <p><i class="fa fa-home mr-3"></i> Bulacan polytechnic College</p>
            <p><i class="fa fa-envelope mr-3"></i> mygmail@gmail.com</p>
            <p><i class="fa fa-phone mr-3"></i> 09950080123</p>
          </div>
        </div>
      </section>

      <hr class="my-3">

      <section class="p-3 pt-0">
        <div class="row d-flex align-items-center">
          <div class="col-md-7 col-lg-8 text-center text-md-start">
            <div class="p-3">
              © 2020 Copyright:
              <a class="text-white" href=""
                 >OJT Management System</a
                >
            </div>
          </div>
      </section>
    </div>
  </footer>
</div>


<script src="includes/bootstrap/js/jquery.min.js"></script>
<script src="includes/bootstrap/js/bootstrap.min.js"></script>

<script src="js/validate.js"></script>

<!-- <script src="js/mutipleform_registration.js"></script> -->
<script src="js/sweetalert.min.js"></script>
<script>
var check = function() {
  if (document.getElementById('password').value ==
    document.getElementById('confirmpassword').value) {
    document.getElementById('submit').type = "submit";
    document.getElementById('submit').value = "Register Now..";
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'password match!';
  } else {
    document.getElementById('submit').type = "button";
    document.getElementById('submit').value = "Password Don't Match!";
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'password dont match';
  }
}

function showpass() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
function showpass2() {
  var x = document.getElementById("confirmpassword");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>

<?php
    if($_SESSION['pass_err']){?>
    <script>
      swal({
        title: "Invalid Account or Password",
        icon: "error",
        button: "Ok",
      });
    </script>
  <?php
        unset($_SESSION['pass_err']);
    }elseif($_SESSION['succ']){?>
      <script>
        swal({
          title: "Congrats! Successfully Registered",
          icon: "success",
          button: "Ok",
        });
      </script>
  <?php
    unset($_SESSION['succ']);
    }
?>
</body>
</html>