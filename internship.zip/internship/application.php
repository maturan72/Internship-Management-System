<div class="register">
    <div class="register-content">
        <div class="row">
            <div class="col-md-4 left-col">
                <div class="image text-center">
                    <img src="assets/images/bpclogo.png" alt="">
                    <h3>Bulacan</h3>
                    <h4>Polytechnic College</h4>
                </div>
                <div class="mission-vission text-center">
                    <h5>VISSION</h5>
                    <p>Bulacan Polytechnic College envisions to become a lead provider of the quality and affordable technical-vocational, entrepreneurial and technological education, and a producer of highly competent and productive human resource.
                    </p>
                </div>
            </div>
            <div class="col-md-8">
                <div class="right-col row">
                    <div class="col-md-12">
                        <div class="admin-info">
                            <div class=" mt-4">
                                <div class="box-header">
                                    <h4 class="text-primary f-bold">Company Information</h4>
                                </div>
                                <?php
                                    $com_id = $_GET['id'];
                                    $select_comp = mysqli_query($conn, "SELECT * FROM company WHERE id = '$com_id'");
                                    while($row = mysqli_fetch_array($select_comp)){?>
                                        <div class="box-content">
                                            <div class="row mt-4">
                                                <div class="email">
                                                    <label for=""><strong>Company Name:</strong></label>
                                                    <h4 class="text-secondary"><?php echo $row['companyname'] ?></h4>
                                                </div>
                                            </div>
                                            <div class="row mt-4">
                                                <div class="col-md-12">
                                                    <form action="php/apply.php" method="post">
                                                        <h5>Login <span class="text-secondary">for confirmation!</span></h5>
                                                        <hr>
                                                        <label for="">Email:</label>
                                                        <input class="form-control" type="email" name="email" required>
                                                        <label for="">password:</label>
                                                        <input class="form-control" type="text" name="password" required>
                                                        <input class="form-control" type="hidden" name="comp_id" value="<?php echo $com_id ?>">
                                                        <div class="button text-end mt-4">
                                                            <a class="btn btn-danger" href="login.php?inc=search-info&id=<?php echo $com_id ?>">Cancel</a>
                                                            <input type="submit" class="btn btn-info" name="apply" value="Submit Application">
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                <?php
                                    }
                                ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>