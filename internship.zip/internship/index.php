<?php include "includes/header.php" ?>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <a class="navbar-brand text-primary" href="index.php"><img src="assets/images/bpclogo.png" alt="" width="50" height="50"> Bulacan Polytechnic College</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      </ul>
      <form class="d-flex">
        <a href="?inc=login-acc" class="btn ms-2 login">Log In</a>
        <!-- <a href="?inc=search" class="btn ms-2 border border-dark">Find Company</a> -->
        <a href="?inc=main#services" class="btn ms-2 ">Services</a>
        <a href="?inc=main#about-us" class="btn ms-2">About Us</a>
        <a href="?inc=main#contact-us" class="btn ms-2">Contact Us</a>
        <div class="dropdown">
          <button type="button" class="btn text-white ms-2 bg-success dropdown-toggle" data-bs-toggle="dropdown">
            Get Started
          </button>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="?inc=company">Get Started as Company</a></li>
            <li><a class="dropdown-item" href="?inc=instructor">Get Started as Instructor</a></li>
            <li><a class="dropdown-item" href="?inc=intern">Get Started as Intern</a></li>
          </ul>
        </div>
      </form>
    </div>
  </div>
</nav>
<!-- Begin Page Content -->
<div class="page-content container-fluid">
    <?php 
        if ($_GET['inc']){
            $inc = $_GET['inc'] . '.php';
            include $inc;
        }else{
            include "main.php";
        }
    ?>
</div>

<?php include "includes/footer.php" ?>

