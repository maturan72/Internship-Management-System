<div class="container-fluid" id="banner">
    <div class="overlay">
        <div class="container">
            <div class="row">
                <div class="col-md-8 content flex-column  d-flex justify-content-center">
                    <h3 class="p2">Build a better employee with</h3>
                    <h1 class="p2"> <span class="first">I</span>nternship <span class="first">M</span>anagement <span class="first">S</span>ystem</h1>
                    <p class="p2">Connect with us to build a better and easier working space for our interns.</p>
                    <form class="d-flex">
                        <a href="?inc=company" class="btn text-white ms-2 bg-dark bg-gradient ">Get Company Started</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid" id="services">
    <div class="container">
        <div class="row">
            <div class="header-title text-center mt-4">
                <h2>OUR SERVICES</h2>
            </div>
            <div class="col-md-4 p-10">
                <div class="company bg-white text-center">
                    <h4 class="text-success p-20">COMPANY</h4>
                    <div class="image">
                        <img src="assets/images/company.jpg" alt="">
                    </div>
                    <div class="text-start p-10">
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit libero modi architecto, qui error eum suscipit cumque nostrum rem quos.</p>
                    </div>
                    <div class="text-end p-10">
                        <a class="btn btn-success" href="?inc=company">Register Now!</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 p-10">
                <div class="instructor bg-white text-center">
                    <h4 class="text-success  p-20">PROJECT HEAD</h4>
                    <div class="image">
                        <img src="assets/images/instructor.png" alt="">
                    </div>
                    <div class="text-start p-10">
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit libero modi architecto, qui error eum suscipit cumque nostrum rem quos.</p>
                    </div>
                    <div class="text-end p-10">
                        <a class="btn btn-success" href="?inc=instructor">Register Now!</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 p-10">
                <div class="instructor bg-white text-center">
                    <h4 class="text-success  p-20">STUDENTS</h4>
                    <div class="image">
                        <img src="assets/images/interns.jpg" alt="">
                    </div>
                    <div class="text-start p-10">
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugit libero modi architecto, qui error eum suscipit cumque nostrum rem quos.</p>
                    </div>
                    <div class="text-end p-10">
                        <a class="btn btn-success" href="?inc=intern">Register Now!</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="how-it-works">
    <div class="overlay4">
        <div class="container">
            <div class="how-it-works p-50">
                <div class="row mt-4">
                    <div class="col-md-6 mt-4">
                        <div class="title-header mt-4">
                            <h3 class="mt-4">HOW IT WORKS</h3>
                            <div class="content mt-4">
                                <h5>Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit repellat ex beatae totam ipsam, eligendi rem ut maxime voluptatem recusandae 
                                    exercitationem nesciunt nisi at, sit modi. Quae repudiandae ducimus nemo, maiores temporibus, nesciunt deserunt porro, recusandae libero reiciendis 
                                    deleniti! Esse sit ex facilis repellat? Quos quibusdam culpa minima eveniet velit.</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="work">
                            <img src="assets/images/bg2.jpeg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="mission-vission" class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-6 ">
                <div class="mission p-50">
                    <h3 class="text-center">
                        MISSION
                    </h3>
                    <p>Equip students with the necessary technological and intellectual capacity to face the fast changing demands of modern technology;</p>
                    <p>Develop the ideal working attitudes and values of the students;</p>
                    <p>Engage in research studies for innovative development of the school;</p>
                    <p>Provide industry-driven curricular programs;</p>
                    <p>Enhance the intellectual, moral and spiritual standard of the faculty and staff;</p>
                    <p>Maintain the quality of its learning facilities at par with that of industry;</p>
                    <p>Sustain efforts towards effective administration; and</p>
                    <p>Strengthen linkages with the private and public sectors.</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="p-50">
                    <img src="assets/images/bg1.jpg" alt="">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="p-50">
                <img src="assets/images/bg4.jpg" alt="">
                </div>
            </div>
            <div class="col-md-6">
                <div class="vission p-50">
                    <h3 class="text-center">
                        VISSION
                    </h3>
                    <p>The Bulacan Polytechnic College envisions to become a 
                        lead provider of quality and affordable technical-vocational,
                         entrepreneurial and technological education, and a producer 
                         of highly competent and productive human resource.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="about-us" class="container-fluid">
    <div class="overlay">
        <div class="container text-center d-flex justify-content-center flex-column align-items-center">
            <div class="header-name p-50">
                <h2>ABOUT US</h2>
            </div>
            <div class="about-content">
                <h5 class="text-center">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque consequuntur, amet quidem sint cumque officia dignissimos quae totam consectetur assumenda, labore consequatur expedita commodi praesentium voluptates! Distinctio maxime cum quibusdam! 
                </h5>
            </div>
        </div>
    </div>
</div>
<div id="contact-us" class="container-fluid">
    <div class="container">
        <div class="content">
            <div class="row">
                <div class="col-md-7">
                    <div class="row">
                        <div class="contactinfo col-md-4">
                            <h4 class="text-success">Contact Info</h4>
                            <div class="number">
                                <i class="fa fa-phone"><span> 09950080123</span></i>
                            </div>
                            <div class="contact-address">
                                <i class="fa fa-map-marker"><span> Bulacan Main Campus</span></i>
                            </div>
                            <h4 class="text-success mt-4">Social Info</h4>
                            <div class="facebook">
                                <i class="fa fa-facebook"><span> myfacebook.com</span></i>
                            </div>
                            <div class="facebook">
                                <i class="fa fa-twitter"><span> mytwitter.com.com</span></i>
                            </div>
                            <div class="facebook">
                                <i class="fa fa-linkedin"><span> mylinkedin.com</span></i>
                            </div>
                            <div class="email">
                                <i class="fa fa-envelope"><span> myemail@gmail.com</span></i>
                            </div>
                        </div>
                        <div class="col-md-8 message-content">
                            <h4 class="text-success">Message Us</h4>
                            <input class="form-control mt-4" type="text" placeholder="Full Name:">
                            <input class="form-control mt-4" type="email" placeholder="Email:">
                            <input class="form-control mt-4" type="text" placeholder=" Contact no:">
                            <textarea  class="form-control mt-4" name="" id="" placeholder="Enter Message here..:"></textarea>
                            <input class="btn btn-success mt-4" type="button" value="Send Message">
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class=""><div class="gmap_canvas"><iframe width="100%" height="400px" id="gmap_canvas" src="https://maps.google.com/maps?q=bulacan%20polytechnic%20college%20main%20campus&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://fmovies-online.net"></a><br><style>.mapouter{position:relative;text-align:right;height:500px;width:600px;}</style></div></div>
                </div>
            </div>
        </div>
    </div>                                   
</div>

