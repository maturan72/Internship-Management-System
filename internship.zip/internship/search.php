<div class="register">
    <div class="register-content">
        <div class="row">
            <div class="col-md-4 left-col">
                <div class="image text-center">
                    <img src="assets/images/bpclogo.png" alt="">
                    <h3>Bulacan</h3>
                    <h4>Polytechnic College</h4>
                </div>
                <div class="mission-vission text-center">
                    <h5>VISSION</h5>
                    <p>Bulacan Polytechnic College envisions to become a lead provider of the quality and affordable technical-vocational, entrepreneurial and technological education, and a producer of highly competent and productive human resource.
                    </p>
                </div>
            </div>
            <div class="col-md-8">
                
                <div class="right-col row">
                    
                    <div class="col-md-12">
                        <form action="php/login.php" method="post">
                            <h4>Find A Company </h4>
                            <hr>
                            <div class="recent-registration">
                                <div class="row notif-table">
                                    <div class="col-md-12">
                                        <table id="example" class="table table-hover table-sm">
                                            <thead class="text-dark">
                                                <tr>
                                                <th scope="col">Company Name</th>
                                                <th scope="col">Available Position</th>
                                                <th scope="col"></th>
                                                </tr>
                                            </thead>
                                            <?php 
                                                $select = "SELECT * FROM company";
                                                $result = mysqli_query($conn, $select);
                                                while($rows = mysqli_fetch_array($result)){?>
                                                <tbody>
                                                    <tr>
                                                    <td class="uppercase"><?php echo $rows['companyname']?></td>
                                                    <td class="uppercase"><?php echo $rows['position']?></td>
                                                    <td><a class="btn text-success" href="login.php?inc=search-info&id=<?php echo $rows['id'] ?>">Read More</a></td>
                                                    </tr>
                                                </tbody>
                                            <?php
                                                }
                                            ?>
                                        </table>
                                        <div class="button mt-4 text-end">
                                            <?php
                                                if($_SESSION['apply_succ']){
                                                    echo "<h6 class='text-success'>Application Successfully Sent</h6>";
                                                    unset($_SESSION['apply_succ']);
                                                }
                                            ?>
                                            <a class="btn btn-danger" href="index.php">Go Back</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>