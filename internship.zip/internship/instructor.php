<div class="register">
    <div class="register-content">
        <div class="row">
            <div class="col-md-4 left-col">
                <div class="image text-center">
                    <img src="assets/images/bpclogo.png" alt="">
                    <h3>Bulacan</h3>
                    <h4>Polytechnic College</h4>
                    <h5>Main Campus</h5>
                </div>
            </div>
            <div class="col-md-8">
                <form action="php/register.php" method="post">
                    <div class="right-col">
                        <!-- <div class="type-button text-end">
                            <div class="bacground-button text-center">
                                <a class="active"  href="?inc=instructor">Instructor</a>
                                <a href="?inc=intern">Interns</a>
                            </div>
                        </div> -->
                        <div class="text-center">
                            <h3>Instructor Registration Form</h3>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-4">
                                <label for="">First Name:</label>
                                <input name="fname" class="form-control" type="text" required>
                            </div>
                            <div class="col-md-4">
                                <label for="">Middle Name:</label>
                                <input name="mname" class="form-control" type="text" required>
                            </div>
                            <div class="col-md-4">
                                <label for="">Last Name:</label>
                                <input name="lname" class="form-control" type="text" required>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-12">
                                <label for="">Address:</label>
                                <input name="address" class="form-control" type="text" required>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-4">
                            <label for="email">Email: <span><small class="text-danger">
                                <?php 
                                    if($_SESSION['email_err']){
                                    echo"Email is already taken!";
                                    }
                                    unset($_SESSION['email_err']);
                                ?>
                                </small></span></label>
                                <input name="email" class="form-control" type="email" required>
                            </div>
                            <?php 
                                if($_SESSION['err']){?>
                                <div class="col-md-4">
                                    <label for="password">Password: <span class="message text-danger">Password dont match!</span></label>
                                    <input name="password" class="err form-control" type="password" required>
                                </div>
                                <div class="col-md-4">
                                    <label for="confirm">Confirm Password:</label>
                                    <input  name="confirm" class="err form-control" type="password" required>
                                </div>
                            <?php
                                }else {?>
                                <div class="col-md-4">
                                    <label for="password">Password:</label>
                                    <input name="password" class="form-control" type="password" required>
                                </div>
                                <div class="col-md-4">
                                    <label for="confirm">Confirm Password:</label>
                                    <input name="confirm" class="form-control" type="password" required>
                                </div>
                            <?php
                                }
                            ?>
                        </div>
                    
                        <div class="submit text-end mt-4">
                            <a href="index.php" class="btn btn-danger" type="submit">Cancel</a>
                            <input class="btn btn-info" type="submit" name="instructor" value="Register Now..">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>